package com.cg.medlifemvcjavaconfig.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifemvcjavaconfig.dao.ShopRepositoryImp;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotShowingException;
@Service
@Transactional
public class ShopServiceImp implements ShopService{

	@Autowired
	private ShopRepositoryImp shoprepository;
	

	public Shop addShop(Shop shop) throws ShopNotSaveIntoDatabase {

		Shop shop2=shoprepository.save(shop);
		if(shop2== null)
			throw new ShopNotSaveIntoDatabase("Shop not save in database");
		return shop2;
	}

	public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException {

		if(shoprepository.findByName(medicineName).isEmpty())
			throw new MedicineNotFoundException("Medicine not found");
		return shoprepository.findByName(medicineName);
	}

	@Override
	public List<Shop> showAllShop() throws ShopNotShowingException {
		// TODO Auto-generated method stub
		List<Shop> shop=shoprepository.showAllShop();
		if(shop==null)
			throw new ShopNotShowingException("Shops are not available..");
		return shop;
	}

	@Override
	public Shop findById(Integer shopId) {
		// TODO Auto-generated method stub
		
		
		return shoprepository.findById(shopId);
	}
}