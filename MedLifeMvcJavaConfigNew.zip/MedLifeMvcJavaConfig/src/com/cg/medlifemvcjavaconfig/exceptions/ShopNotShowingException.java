package com.cg.medlifemvcjavaconfig.exceptions;

public class ShopNotShowingException extends Exception {
	
	public ShopNotShowingException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public ShopNotShowingException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
