package com.cg.medlifemvcjavaconfig.dto;

import java.util.ArrayList;
import java.util.List;




import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="shop")
public class Shop 
{

	@Id
	@Column(name="shop_id")
	private Integer shopId;
	
	@Column(name="shop_name")
	private String shopName;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_id")
	private Address address;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="shop_id")
	private List<Medicine> medicines=new ArrayList<Medicine>();
	
	//default constructor
	public Shop()
	{	}

	public Integer getShopId() {
		return shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public Shop(Integer shopId, String shopName, Address address, List<Medicine> medicines) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.address = address;
		this.medicines = medicines;
	}

	public String getShopName() {
		return shopName;
	}

	@Override
	public String toString() {
		return "Shop [shopId=" + shopId + ", shopName=" + shopName + ", address=" + address + ", medicines=" + medicines
				+ "]";
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Medicine> getMedicines() {
		return medicines;
	}

	public void setMedicines(List<Medicine> medicines) {
		this.medicines = medicines;
	}

	

}