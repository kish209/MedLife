package com.cg.medlifespringboot.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifespringboot.dao.MedicineRepository;
import com.cg.medlifespringboot.dto.Medicine;

@Transactional
@Service
public class MedicineServiceImp implements MedicineService  {

	@Autowired
	MedicineRepository medicinerepository;
	@Override
	public Medicine searchByMedicineId(int id) {
	
		return medicinerepository.findBymedicineId(id);
	}

}
