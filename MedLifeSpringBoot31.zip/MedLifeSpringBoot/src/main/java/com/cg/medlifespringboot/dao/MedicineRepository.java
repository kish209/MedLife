package com.cg.medlifespringboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.medlifespringboot.dto.Medicine;
import com.cg.medlifespringboot.dto.Shop;
import com.cg.medlifespringboot.dto.Trade;

public interface MedicineRepository extends JpaRepository<Medicine, Integer> {

	public Medicine findBymedicineId(int id);
}
