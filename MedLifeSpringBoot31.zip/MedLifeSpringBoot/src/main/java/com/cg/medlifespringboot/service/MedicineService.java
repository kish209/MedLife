package com.cg.medlifespringboot.service;

import com.cg.medlifespringboot.dto.Medicine;

public interface MedicineService {

	public Medicine searchByMedicineId(int id);
}
