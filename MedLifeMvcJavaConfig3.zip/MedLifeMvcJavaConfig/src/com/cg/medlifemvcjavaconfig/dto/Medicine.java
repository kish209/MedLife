package com.cg.medlifemvcjavaconfig.dto;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="medicine")
public class Medicine{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="medicine_id")
	private int medicineId;
	
	@Column(name="medicine_name")
	private String medicineName;
	
	@Column(name="medicine_type")
	private String medicineType;
	
	@Column(name="medicine_price")
	private double medicinePrice;
	
	@ManyToOne
	@JoinColumn(name="trade_id")
	private Trade trade;
	
	@ManyToOne
	@JoinColumn(name="shop_id")
	private Shop shop;
	
	public Trade getTrade() {
		return trade;
	}

	public void setTrade(Trade trade) {
		this.trade = trade;
	}

	public Shop getShop() {
		return shop;
	}

	public void setShop(Shop shop) {
		this.shop = shop;
	}

	public Medicine() {
		// TODO Auto-generated constructor stub
	}

	public Medicine(int medicineId, String medicineName, String medicineType, double medicinePrice) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.medicineType = medicineType;
		this.medicinePrice = medicinePrice;
	}


	public int getMedicineId() {
		return medicineId;
	}


	public void setMedicineId(int medicineId) {
		this.medicineId = medicineId;
	}


	public String getMedicineName() {
		return medicineName;
	}


	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}


	public String getMedicineType() {
		return medicineType;
	}


	public void setMedicineType(String medicineType) {
		this.medicineType = medicineType;
	}


	public double getMedicinePrice() {
		return medicinePrice;
	}


	public void setMedicinePrice(double medicinePrice) {
		this.medicinePrice = medicinePrice;
	}


	@Override
	public String toString() {
		return "Medicine [medicineId=" + medicineId + ", medicineName=" + medicineName + ", medicineType="
				+ medicineType + ", medicinePrice=" + medicinePrice + "]";
	}



	
	

}