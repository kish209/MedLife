package com.cg.medlifemvcjavaconfig.exceptions;

public class DataNotFoundException extends Exception {
	public DataNotFoundException()
	{}
	public DataNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}
