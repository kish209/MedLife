package com.cg.medlifemvcjavaconfig.dao;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;


import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.dto.Medicine;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;

@Repository
public class ShopRepositoryImp implements ShopRepository{

	List<Medicine> medicineData;
	@PersistenceContext
	EntityManager em;
	

	//saving shop into database
	
	public Shop save(Shop shop) {
	
		Shop shopOne = findById(shop.getShopId());
	
			if(shopOne==null)
			{
				
		em.persist(shop);
		em.flush();
			}
			else
			{
				Medicine med= new Medicine();
				med.setMedicineId(shop.getMedicines().get(0).getMedicineId());
				med.setMedicineName(shop.getMedicines().get(0).getMedicineName());
				med.setMedicineType(shop.getMedicines().get(0).getMedicineType());
				med.setMedicinePrice(shop.getMedicines().get(0).getMedicinePrice());
				med.setShop(shopOne);
				em.merge(med);
				em.flush();
			}
		return  shop;
		}

	
	public Shop findById(Integer shopId)
	{
		Shop shopThree= null;
		try
		{
		Query query = em.createQuery("FROM Shop WHERE id=:shopId");
		query.setParameter("shopId", shopId);
		shopThree= (Shop) query.getSingleResult();
		}
		catch(NoResultException ex)
		{
			System.out.println("Id Not Found");
		}
		System.out.println("dao shp3"+shopThree);
		return shopThree;
		
	}

	
	//finding medicine name
	
	public List<Shop> findByName(String medicineNameOne) throws MedicineNotFoundException {
		List <Medicine> medicineList = new ArrayList<Medicine>();
		List <Shop> shopListOne = new ArrayList<Shop>();
		List <Shop> shopList = new ArrayList<Shop>();
		try	
		{		
		/*showing shops with using specific medicine name*/
		TypedQuery<Shop> query = em.createQuery("select c from Shop c", Shop.class);
		shopList = query.getResultList();
		
		for (Shop shop : shopList) {
			medicineList=shop.getMedicines();
			for (Medicine medicineOne : medicineList) {
				if(medicineNameOne.equals(medicineOne.getMedicineName())) {
					shopListOne.add(shop);
					
				}
			}
		}
		}
		
		/*Handling exception*/
		catch(Exception e)
		{
			throw new MedicineNotFoundException("Medicine not found");
			
		}
		
		
		return shopListOne;
	}


	@Override
	public List<Shop> showAllShop() {
		Query query= em.createQuery("select c from Shop c", Shop.class);
		List<Shop> myList = query.getResultList();
		return myList;
	}
}