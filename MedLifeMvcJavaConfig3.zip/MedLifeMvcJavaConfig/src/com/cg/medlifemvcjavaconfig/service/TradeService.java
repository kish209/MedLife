package com.cg.medlifemvcjavaconfig.service;
import java.util.Date;


import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Trade;
import com.cg.medlifemvcjavaconfig.exceptions.DataNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.DateNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeDataNotGettingException;

import com.cg.medlifemvcjavaconfig.exceptions.TradeNotSaveIntoDatabase;

public interface TradeService{
	public List <Trade> searchByDate(Date date) throws DateNotFoundException;
	public List <Trade> searchCustomerByDate(String custId, Date date) throws DateNotFoundException, DataNotFoundException;
	public List<Trade> showTrade() throws TradeDataNotGettingException;
	public Trade addTrade(Trade trade) throws TradeNotSaveIntoDatabase;
	public Trade updateTrade();
}
