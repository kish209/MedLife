package com.cg.medlifemvcjavaconfig.service;

import java.util.Date;


import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifemvcjavaconfig.dao.TradeRepository;
import com.cg.medlifemvcjavaconfig.dao.TradeRepositoryImp;
import com.cg.medlifemvcjavaconfig.dto.Trade;
import com.cg.medlifemvcjavaconfig.exceptions.DataNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.DateNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeDataNotGettingException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeNotSaveIntoDatabase;

@Service
@Transactional
public class TradeServiceImp implements TradeService {

	@Autowired
	TradeRepository repository=new TradeRepositoryImp();

	public List<Trade> searchByDate(Date date) throws DateNotFoundException {

		if(repository.findByDate(date).isEmpty())
			throw new DateNotFoundException("Date not found in transaction");
		return repository.findByDate(date);
	}

	public List<Trade> searchCustomerByDate(String custName, Date date) throws DateNotFoundException, DataNotFoundException {
		if(repository.findCustomerByDate(custName, date).isEmpty())
			throw new DateNotFoundException("Transaction not found");
		return repository.findCustomerByDate(custName, date);
	}


	public List<Trade> showTrade() throws TradeDataNotGettingException
	{
		if(repository.showAll().isEmpty())
			throw new TradeDataNotGettingException("trade data not getting");
		return repository.showAll();
	}


	public Trade addTrade(Trade trade) throws TradeNotSaveIntoDatabase {
		Random rand = new Random();
		int id = rand.nextInt(100);
		trade.setId(id);
		if(repository.saveTrade(trade)==null)
			throw new TradeNotSaveIntoDatabase("trade data not save in database");
		return repository.saveTrade(trade);
	}

	@Override
	public Trade updateTrade() {
		// TODO Auto-generated method stub
		return repository.updateTrade();
	}
}