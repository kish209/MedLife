package com.cg.medlifejdbc.service;

import java.util.Date;
import java.util.List;
import com.cg.medlifejdbc.dto.Trade;
import com.cg.medlifejdbc.exceptions.DateNotFoundException;
public interface TradeService{
	public List <Trade> searchByDate(Date date) throws DateNotFoundException;
	public List <Trade> searchCustomerByDate(String custId, Date date) throws DateNotFoundException;
	public List<Trade> showTrade();
	public Trade addTrade(Trade trade);
}
