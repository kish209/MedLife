package com.cg.medlifejdbc.dao;
import java.util.Date;
import java.util.List;

import com.cg.medlifejdbc.dto.Trade;

public interface TradeRepository {

	public List<Trade> findByDate(Date date);
	public List<Trade> findCustomerByDate(String custName, Date date);
	public Trade saveTrade(Trade trade);
	public  List<Trade> showAll();
}