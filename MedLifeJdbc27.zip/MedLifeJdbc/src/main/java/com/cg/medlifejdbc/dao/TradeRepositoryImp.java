package com.cg.medlifejdbc.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.medlifejdbc.dto.Medicine;
import com.cg.medlifejdbc.dto.Trade;
import com.cg.medlifejdbc.util.DBUtil;
public class TradeRepositoryImp implements TradeRepository{

	//static int trade_id;
	public List<Trade> findByDate(Date date) {/*
		List <Trade> trade1 = new ArrayList<Trade>();

		for (Trade trade : DBUtil.tradeData) {
			if(trade.getDate().equals(date))
				trade1.add(trade);
		}
		return trade1;*/
		return null;
	}

	public List<Trade> findCustomerByDate(String custId, Date date){/*
		List <Trade> trade2 = new ArrayList<Trade>();
		for (Trade tradeOne : DBUtil.tradeData) {
			if((tradeOne.getCustomer().getCustId().equals(custId)) && (tradeOne.getDate().equals(date)) )
				trade2.add(tradeOne);
		}
		return trade2;*/
		return null;
	}


	public Trade saveTrade(Trade trade) {
		Connection connection = DBUtil.getConnection();
		String query;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try
		
		{		
			int tradeId=0;
			
			query="insert into trade(total_price,trade_date,cust_id_f,shop_id_f) values(?,?,?,?)";
			pstmt=connection.prepareStatement(query);
			
			pstmt.setDouble(1, trade.getTotalPrice());
			pstmt.setString(2, trade.getDate().toString());
			pstmt.setString(3, trade.getCustomer().getCustId());
			pstmt.setInt(4, trade.getShop().getShopId());
			pstmt.executeUpdate();
			
			
			
			query="select max(trade_id) from trade";
			pstmt=connection.prepareStatement(query);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				tradeId=rs.getInt(1);
			}
		/*	
			query="select max(trade_id) from trade";
			pstmt=connection.prepareStatement(query);
			pstmt.setInt(1, trade.getId());
			rs=pstmt.executeQuery();
			while(rs.next())
				{trade_id=rs.getInt(1);
				}
			*/
	

			query="update medicine set trade_id_f= ? where medicine_name=?";
			for (Medicine medicine : trade.getMedicines()) {
				pstmt=connection.prepareStatement(query);
				pstmt.setInt(1, tradeId);
				pstmt.setString(2, medicine.getMedicineName());
				pstmt.executeUpdate();
			}
			
		
		
			return trade;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
		return  null;
	
	}


	public List<Trade> showAll() 
	{
		System.out.println("hiiiiiiiiiiiiiiiiiiiii");
		Trade trade= new Trade();
		List <Trade> tradeList = new ArrayList<Trade>();
		int tradeId=0;
		Connection connection = DBUtil.getConnection();
		String query;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try
		
		{		
			query="select * from trade where trade_id =?";
			pstmt=connection.prepareStatement(query);
			pstmt.setInt(1, tradeId );
			rs= pstmt.executeQuery();
			
		
			/*
			query="select max(trade_id) from trade";
			pstmt=connection.prepareStatement(query);
			
			rs=pstmt.executeQuery();
			while(rs.next()) {
				tradeId=rs.getInt(1);
				
			}
			query="select * from trade where trade_id =?";
			pstmt=connection.prepareStatement(query);
			pstmt.setInt(1, tradeId );
			rs= pstmt.executeQuery();
			while(rs.next()) {
				//tradeId=rs.getInt(1);
				trade.setId(rs.getInt(1));
				trade.setTotalPrice(rs.getDouble(1));
				//trade.setDate(rs.getString(1).toString());
				tradeList.add(trade);
				
			}*/
		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
		return tradeList;
	}
}