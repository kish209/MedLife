package com.cg.medlifejdbc.service;

import java.util.Date;

import java.util.List;
import com.cg.medlifejdbc.dao.TradeRepository;
import com.cg.medlifejdbc.dao.TradeRepositoryImp;
import com.cg.medlifejdbc.dto.Trade;
import com.cg.medlifejdbc.exceptions.DateNotFoundException;
public class TradeServiceImp implements TradeService {

	TradeRepository repository=new TradeRepositoryImp();

	public List<Trade> searchByDate(Date date) throws DateNotFoundException {

		if(repository.findByDate(date).isEmpty())
			throw new DateNotFoundException("Date not found in transaction");
		return repository.findByDate(date);
	}

	public List<Trade> searchCustomerByDate(String custName, Date date) throws DateNotFoundException {
		if(repository.findCustomerByDate(custName, date).isEmpty())
			throw new DateNotFoundException("Transaction not found");
		return repository.findCustomerByDate(custName, date);
	}


	public List<Trade> showTrade() {
		return repository.showAll();
	}


	public Trade addTrade(Trade trade) {
		return repository.saveTrade(trade);
	}
}