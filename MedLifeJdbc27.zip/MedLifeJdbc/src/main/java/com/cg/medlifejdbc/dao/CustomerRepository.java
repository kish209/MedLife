package com.cg.medlifejdbc.dao;

import com.cg.medlifejdbc.dto.Customer;
import com.cg.medlifejdbc.exceptions.DataNotSaveException;


public interface CustomerRepository {

	public Customer save(Customer customer);
	public Customer findById(String id);
}
