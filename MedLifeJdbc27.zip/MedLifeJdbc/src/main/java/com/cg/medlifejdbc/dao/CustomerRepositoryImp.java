package com.cg.medlifejdbc.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cg.medlifejdbc.dto.Customer;
import com.cg.medlifejdbc.exceptions.DataNotSaveException;
import com.cg.medlifejdbc.util.DBUtil;
public class CustomerRepositoryImp implements CustomerRepository 
{
List<Customer> customerData;
String query = null;
Connection connection =null;
PreparedStatement pstmt=null;
ResultSet result=null;
	public Customer save(Customer customer) {
		connection = DBUtil.getConnection();
		try
		
		{		
			query="insert into customer(cust_id,cust_name,contact) values(?,?,?)";
			pstmt=connection.prepareStatement(query);
			pstmt.setString(1, customer.getCustId());
			pstmt.setString(2, customer.getCustName());
			pstmt.setString(3, customer.getContact().toString());
			pstmt.executeUpdate();
	
			query="insert into address(house_no,house_area,city,pincode,cust_id_f) values(?,?,?,?,?)";
			pstmt=connection.prepareStatement(query);
			pstmt.setString(1, customer.getAddress().getHouseNo());
			pstmt.setString(2, customer.getAddress().getArea());
			pstmt.setString(3, customer.getAddress().getCity());
			pstmt.setLong(4, customer.getAddress().getPincode());
			pstmt.setString(5, customer.getCustId());
			pstmt.executeUpdate();
			
			
			return customer;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
		return  null;
	}


	public Customer findById(String id)
	{
		connection = DBUtil.getConnection();
		String query_select =null;
		try
		
		{		
			query_select="select * from customer where cust_id=?";
			pstmt=connection.prepareStatement(query_select);
			pstmt.setString(1, id);
			result = pstmt.executeQuery();
			
			while(result.next())
					{
				Customer customer= new Customer();
				customer.setCustId(result.getString(1));		
			return customer;
					}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
		return null;
		
	}	
	
}