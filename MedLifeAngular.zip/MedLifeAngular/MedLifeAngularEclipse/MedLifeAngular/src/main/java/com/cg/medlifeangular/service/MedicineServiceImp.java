package com.cg.medlifeangular.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifeangular.dao.MedicineRepository;
import com.cg.medlifeangular.dto.Medicine;

@Transactional
@Service
public class MedicineServiceImp implements MedicineService  {

	@Autowired
	MedicineRepository medicinerepository;
	@Override
	public Medicine searchByMedicineId(int id) {
	
		return medicinerepository.findBymedicineId(id);
	}

}
