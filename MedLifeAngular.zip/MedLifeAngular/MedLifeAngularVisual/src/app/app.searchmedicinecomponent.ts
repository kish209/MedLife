import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router'; 
import { Shop } from './app.shop';
import { MedlifeService } from './app.medlifeservice';
import { Medicine } from './app.medicine';



@Component({
selector:'searchmed-app',
templateUrl:'app.searchmedicine.html'



})


export class SearchMedicineComponent {


    constructor(private medlifeservice:MedlifeService){}
    medicines:Medicine[];
    shops:Shop[];
   medicine: string;
    searchMedicine()
    {
       this.medlifeservice.searchAllShop(this.medicine).subscribe((data:any)=>console.log(data));
    }

}

