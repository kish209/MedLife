import{Injectable} from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { Customer } from './app.customer';
import { Shop } from './app.shop';
import { Medicine } from './app.medicine';
import { AddShopComponent } from './app.addshopcomponent';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
    providedIn:'root'
})
export class MedlifeService{
constructor(private http:HttpClient){}

getAllProduct(){
   return this.http.get("http://localhost:9098/medlife/showcustomer")
}

addAllProduct(cust:any){

    console.log(cust);
    let input = new FormData();
    input.append("custId",cust.id);
    input.append("custName",cust.name);
    input.append("contact",cust.contact);
    input.append("address.houseNumber",cust.addresshousenumber);
    input.append("address.area",cust.addressarea);
    input.append("address.city",cust.addresscity);
    input.append("address.pincode",cust.addresspincode);
    return this.http.post("http://localhost:9098/medlife/addcustomer",input)
}



addAllShop(shop:any){
    let i:number=0;
    console.log("Shops ...."+shop.toString());
    let input = new FormData();
    input.append("shopId",shop.id);
    input.append("shopName",shop.name);
    input.append("address.houseNumber",shop.addresshousenumber);
    input.append("address.area",shop.addressarea);
    input.append("address.city",shop.addresscity);
    input.append("address.pincode",shop.addresspincode);
   

    while(i<shop.medicines.length)

    {
        console.log("Check"+i);
    input.append("medicines["+i+"].medicineName",shop.medicines[i].medicinename);
    input.append("medicines["+i+"].medicineType",shop.medicines[i].medicinetype);
    input.append("medicines["+i+"].medicinePrice",shop.medicines[i].medicineprice);
    i++;
    //console.log(fieldArray[i]);
    }
    
    return this.http.post("http://localhost:9098/medlife/addshop",input)
}



searchAllShop(medicinename:string)
{
    console.log(medicinename);
    //let httpParams = new HttpParams().set("medicine",medicinename);
    return this.http.get("http://localhost:9098/medlife/searchmedi?medicine="+medicinename)
}  


addGivenTrade(trade:any){

    let input = new FormData();

    input.append("medicine",trade.price);
    input.append("customer",trade.custId);
    input.append("shop",trade.shopId);
    input.append("medicineOne",trade.medicineId);
    return this.http.post("http://localhost:9098/medlife/trade",input)
}

}