import {Component} from '@angular/core';
import { MedlifeService } from "./app.medlifeservice";
import { Medicine } from "./app.medicine";
import { Customer } from "./app.customer";
import { Shop } from "./app.shop";


@Component({
selector:'buy-app',
templateUrl:'app.buymedicine.html'



})




export class BuyMedicineComponent{

    shops:Shop[];
    medicines:Medicine[]=[];
    model : any={};
    constructor(private medlifeservice:MedlifeService){}
        
    

    addTrade()
    {
    this.medlifeservice.addGivenTrade(this.model).subscribe((data:any)=>console.log(data));
    }

} 
 
