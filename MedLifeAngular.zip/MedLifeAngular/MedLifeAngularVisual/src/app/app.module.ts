﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { Customer }  from './app.customer';
import { ShowCustomer }  from './app.showcustomer';
import { BuyMedicineComponent }  from './app.buymedicinecomponent';
import { SearchMedicineComponent }  from './app.searchmedicinecomponent';
import {FormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
import { AddCustomerComponent } from './app.addcustomercomponent';
import {HttpClientModule} from '@angular/common/http';
import { AddShopComponent } from './app.addshopcomponent';


const route:Routes=[
 
    
{path:'addcust',component:AddCustomerComponent},
{path:'show',component:ShowCustomer},
{path:'addshop',component:AddShopComponent},
{path:'buy',component:BuyMedicineComponent},
{path:'searchmedicine',component:SearchMedicineComponent},


];

@NgModule({
    imports: [
        BrowserModule,RouterModule.forRoot(route),HttpClientModule,
        FormsModule
        
    ],
    declarations: [
        AppComponent,AddCustomerComponent,ShowCustomer,AddShopComponent,BuyMedicineComponent,SearchMedicineComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }