package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsystem.dao.Parktransdao;
import com.cg.parkingmanagementsystem.dto.Parktransaction;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.invaliddetailexcepion;

public class Parkingtransservice implements Parkingtransserivceinterface{
Parktransdao parktrans;
	
	public Parkingtransservice(){
		parktrans=new Parktransdao();
	}
	
	public void bookParking(Parktransaction parktrans1) throws invaliddetailexcepion, InvaliddetailId, SQLException{
		
		
		parktrans.book(parktrans1);
	}


}
