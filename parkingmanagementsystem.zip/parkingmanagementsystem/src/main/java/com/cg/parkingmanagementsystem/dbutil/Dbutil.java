package com.cg.parkingmanagementsystem.dbutil;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Dbutil {

	
	 public static EntityManager em=Persistence.createEntityManagerFactory("parkingmanagementsys").createEntityManager();

		
		

}