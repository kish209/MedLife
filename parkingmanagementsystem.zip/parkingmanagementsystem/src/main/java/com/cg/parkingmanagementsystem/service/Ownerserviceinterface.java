package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.exceptions.Duplicateaddressuserexception;

public interface Ownerserviceinterface {
public Owner add(Owner owe) throws Duplicateaddressuserexception, SQLException;
}
