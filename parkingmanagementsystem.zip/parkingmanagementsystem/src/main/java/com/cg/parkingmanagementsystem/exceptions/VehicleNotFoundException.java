package com.cg.parkingmanagementsystem.exceptions;

public class VehicleNotFoundException extends Exception {

	public VehicleNotFoundException(){}
	
	public VehicleNotFoundException(String exceptionMessage){
		super(exceptionMessage);
	}

	
}
