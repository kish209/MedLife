package com.cg.parkingmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.parkingmanagementsystem.dbutil.Dbutil;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Vehicle;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.ParkingNotFoundException;

public class Parkingslotdaoclass implements Parkingslotdao{

	EntityManager em;
	public Parkingslotdaoclass() {
		em=Dbutil.em;
	}
	
	
	
	public Parkingslot create(Parkingslot parkslot) throws InvaliddetailId, InvalidOwnerId {

	
		
		int owner_id=parkslot.getParking().getId();
		
		
		
		

		
		
		
		Query queryOne  = em.createQuery("Select a From Parking a where parking_id= :owner_id");
		List<Owner> owner=queryOne.setParameter("owner_id", owner_id).getResultList();
		
		if(!(owner.isEmpty())) {
			em.getTransaction().begin();
			em.persist(parkslot);
			//em.merge(vehicle);
			em.getTransaction().commit();
			em.close();
			
		}
		//em.persist(vehicle.getOwner());
		
		

		else{
			throw new InvalidOwnerId("OOPS..Parking ID Not found into the Database."
					+ " Please enter the valid Parking number and try again!!");
		}
		 
		
		
		/*em.getTransaction().begin();
		em.persist(parkslot);

		em.getTransaction().commit();
		em.close();*/
		
		/*
		con=DButil.getConnection();

		String query_insert="Insert into parkingslot(id,startdate,enddate,starttime,endtime,parkid) values(?,?,?,?,?,?)";
		String query="Select id from parking where id=?";
		String queryOne="Select id from parkingslot where id=?";
		PreparedStatement pstmone=null;
		PreparedStatement pstm=null;
		PreparedStatement pstmOne=null;
		try {
	
			
			
			pstm=con.prepareStatement(query);
			pstm.setInt(1, parkslot.getParking().getId());
			ResultSet rs1=pstm.executeQuery();
			
			pstmOne=con.prepareStatement(queryOne);
			pstmOne.setInt(1, parkslot.getId());
			ResultSet rs=pstmOne.executeQuery();
			
		if(rs1.next()==true) {	
		if(rs.next()==false){
			pstmone=con.prepareStatement(query_insert);
			pstmone.setInt(1, parkslot.getId());
			
			java.sql.Date sd=java.sql.Date.valueOf(parkslot.getStartDate());
			pstmone.setDate(2,sd);
			java.sql.Date ed=java.sql.Date.valueOf(parkslot.getStartDate());
			pstmone.setDate(3,ed);
			
			Time st=Time.valueOf(parkslot.getStartTime());
			pstmone.setTime(4, st);
			
			Time et=Time.valueOf(parkslot.getEndTime());
			pstmone.setTime(5, et);
		
			pstmone.setInt(6, parkslot.getParking().getId());
			pstmone.executeUpdate();
			

			
			}else {
				throw new InvaliddetailId("OOPs, this ParkingSlotID already used. Kindly enter the another Parkingslot id!!");
				
			}
		
		
		
		}
		
			
			else {
				throw new InvaliddetailId("OOPs, You have entered the wrong ParkingID. Kindly enter the correct Parking id!!");
			}
		
		}
	catch(SQLException e) {
		e.printStackTrace();
			
		}
	*/

		return parkslot;
	}






public List<Parkingslot> findByid(int id) throws ParkingNotFoundException, SQLException{
	
	Query query  = em.createQuery("Select a From Parkingslot a where parkingslot_id= :id");
	 
	
	 List<Parkingslot> depts=query.setParameter("parkingslot_id", id).getResultList();
/*	

PreparedStatement pstm=null;	

Parkingslot psk=new Parkingslot();
	List<Parkingslot> pki=new ArrayList<Parkingslot>();	
try {
	
	
	
	
	
	con=DButil.getConnection();
	String query_Show="Select p.id from parkingslot p where p.id=?";
	
	
	
			
			
	
			pstm=con.prepareStatement(query_Show);
			pstm.setInt(1, id);
			ResultSet result=pstm.executeQuery();
			
			
			
			while(result.next()) {
				
				Parkingslot powe=new Parkingslot();
			
			powe.setId(result.getInt(1));
				
				
				
				
				
				pki.add(powe);

				
			}
		
		
		
			
		
		
	}
catch(SQLException e) {
	e.printStackTrace();
		
	}
finally {
if(pki.isEmpty()){
	throw new ParkingNotFoundException("OOPS..Parkingslot Not found into the Database."
			+ " Please enter the valid Parkingslot number and try again!!");

}
	


}
*/
return depts;


}}
