import {Component} from '@angular/core';
import {Address } from './app.address';
import {Medicine} from './app.medicine';
import { Customer } from './app.customer';


export class Trade{

    id:number;
   price:number;
   customer:Customer;
    address:Address;
    medicines:Medicine;
} 
 
