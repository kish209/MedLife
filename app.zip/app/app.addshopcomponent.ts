import { Component,OnInit} from "@angular/core";
import { MedlifeService } from "./app.medlifeservice";
import { Shop } from "./app.shop";
import { FormsModule }  from '@angular/forms';
import { Medicine } from "./app.medicine";



@Component({
selector:'shop-app',
templateUrl:'app.addshop.html'

})
export class AddShopComponent {

    shops:Shop[];

model : any={};
constructor(private medlifeservice:MedlifeService){}
    




medicinesdata=false;

medicines:Medicine[]=[];

medicine={ medicinename:'',   medicinetype:'', medicineprice:0  };


 addMedicine()
 {
    console.log(this.model);
    this.medicinesdata=true;
 }

addMedicines()
{
this.medicines.push(this.medicine);
console.log(this.medicines);
   this.medicine={
    medicinename:'',   medicinetype:'', medicineprice:0
   }
}

 addShop()
 {  this.medicines.push(this.medicine);
     this.model['medicines']=this.medicines;
    console.log(this.model);
    this.medlifeservice.addAllShop(this.model).subscribe((data:any)=>console.log(data));
 }





}