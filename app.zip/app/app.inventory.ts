export class Inventory{
    id:number;
    name:string;
    
}