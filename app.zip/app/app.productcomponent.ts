import { Component,OnInit} from "@angular/core";
import { ProductService } from "./app.productservice";
import { Product } from "./app.product";
import { FormsModule }  from '@angular/forms';



@Component({
selector:'prod-app',
templateUrl:'app.product.html'

})
export class ProductComponent implements OnInit{

    products:Product[];

model : any={};
constructor(private proservice:ProductService){}
    

ngOnInit(){
    this.proservice.getAllProduct().subscribe((data:Product[])=>this.products=data);
}

addProduct(){
    //console.log(this.model);
    this.proservice.addAllProduct(this.model).subscribe((data:any)=>console.log(data));
}


}