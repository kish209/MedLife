package com.cg.medlifespringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.medlifespringboot")
public class MedLifeSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedLifeSpringBootApplication.class, args);
		System.out.println("Welcome to MedLife");
	}

}
