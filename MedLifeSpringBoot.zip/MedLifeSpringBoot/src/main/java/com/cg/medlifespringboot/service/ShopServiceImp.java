package com.cg.medlifespringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifespringboot.dto.Shop;

import com.cg.medlifespringboot.dao.ShopRepository;

@Service
public class ShopServiceImp implements ShopService{

	//static int countShop=100;
//	static int countAddress=200;
	@Autowired
	ShopRepository shoprepository;
	
	public ShopServiceImp(){

	}

	public Shop addShop(Shop shop){

		//shop.setShopId(countShop);
		//countShop++;
		
		//shop.getAddress().setAddressId(countAddress);
		//countAddress++;
		return shoprepository.save(shop);
	}

	public List<Shop> searchByMedicine(String medicineName){
		return shoprepository.findBymedicineName(medicineName);
	}

	@Override
	public List<Shop> searchById(int id) {
		// TODO Auto-generated method stub
		return shoprepository.findByshopId(id);
	}

	@Override
	public List<Shop> showAll() {
		// TODO Auto-generated method stub
		return shoprepository.findAll();
	}
}