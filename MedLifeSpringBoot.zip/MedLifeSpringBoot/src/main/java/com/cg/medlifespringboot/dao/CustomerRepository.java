package com.cg.medlifespringboot.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.medlifespringboot.dto.Customer;



public interface CustomerRepository extends JpaRepository<Customer, Integer>{

	public Customer findBycustId(String id);
	

}
