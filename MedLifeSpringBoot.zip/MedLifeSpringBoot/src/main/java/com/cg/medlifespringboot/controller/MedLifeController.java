package com.cg.medlifespringboot.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.medlifespringboot.dto.Customer;
import com.cg.medlifespringboot.dto.Shop;
import com.cg.medlifespringboot.service.CustomerService;
import com.cg.medlifespringboot.service.ShopService;
import com.cg.medlifespringboot.service.TradeService;


@RestController
@RequestMapping("/medlife")
public class MedLifeController {
	@Autowired
	CustomerService customerservice;
	@Autowired
	ShopService shopservice;
	@Autowired
	TradeService tradeservice;

	

	@RequestMapping(value="/addcustomer",method=RequestMethod.POST)
	public ResponseEntity<Customer> addProduct(@ModelAttribute("customer") Customer cust) {
        System.out.println(cust);
        Customer customer = null;
        Customer custOne = customerservice.searchById(cust.getCustId());
        
        if(custOne!=null)
        {
        	return new ResponseEntity("Customer Already Exist..", HttpStatus.NOT_FOUND);
        }
        else
        {
        	customer=customerservice.addCustomer(cust);
        	if(customer==null)
        	{
        		return new ResponseEntity("Customer not added", HttpStatus.NOT_FOUND);
        	}
        	
        }
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}

	
	@RequestMapping(value="/showcustomer",method=RequestMethod.GET)

	public ResponseEntity<List<Customer>> showAllCustomer(){

		List<Customer> myList=customerservice.showAll();
		if(myList.isEmpty())
		{
			return new ResponseEntity("No Customer to show", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>> (myList, HttpStatus.OK);
	}
	
	
	
	@RequestMapping(value="/addshop",method=RequestMethod.POST)
	public ResponseEntity<Shop> addShop(@ModelAttribute("shop") Shop sh) {
        System.out.println(sh);
        Shop shop = null;
        List<Shop> shOne = shopservice.searchById(sh.getShopId());   
        if(!shOne.isEmpty())
        {
        	return new ResponseEntity("Shop Already Exist..", HttpStatus.NOT_FOUND);
        }
        else
        {
        	shop=shopservice.addShop(sh);
        	if(shop==null)
        	{
        		return new ResponseEntity("Customer not added", HttpStatus.NOT_FOUND);
        	}
        	
        }
		return new ResponseEntity<Shop>(shop, HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/showshop",method=RequestMethod.GET)

	public ResponseEntity<List<Shop>> showAllShop(){

		List<Shop> myList=shopservice.showAll();
		if(myList.isEmpty())
		{
			return new ResponseEntity("No Shop to show..", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Shop>> (myList, HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/searchcust",method=RequestMethod.GET)

	public ResponseEntity<Customer> searchcust(@ModelAttribute("customer") Customer custId){

		Customer myList=customerservice.searchById(custId.getCustId());
		System.out.println(myList);
		if(myList==null)
		{
			return new ResponseEntity("No search to show..", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Customer> (myList, HttpStatus.OK);
	}
	
	

/*
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ResponseEntity<Product> addProduct(@RequestBody Product pro) {
        System.out.println(pro);
		Product prod=productservice.addProduct(pro);
		if(prod==null)
		{
			return new ResponseEntity("Product Not added", HttpStatus.NOT_FOUND);
		}
		//System.out.println(pro);
		return new ResponseEntity<Product>(prod, HttpStatus.OK);
	}

	
	
	@RequestMapping(value="/show",method=RequestMethod.GET)

	public ResponseEntity<List<Product>> showAllProduct(){

		List<Product> myList=productservice.showAll();
		if(myList.isEmpty())
		{
			return new ResponseEntity("No Product to show", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>> (myList, HttpStatus.OK);
	}
	

	@RequestMapping(value="/search",method=RequestMethod.GET)

	public ResponseEntity<List<Product>> searchProduct(@RequestParam("pname") String name){

		List<Product> myList=productservice.search(name);
		if(myList.isEmpty())
		{
			return new ResponseEntity("No Product to show", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>> (myList, HttpStatus.OK);
	}
	*/
	
	/*	@RequestMapping(value="/addall",method=RequestMethod.GET)

	public ResponseEntity<Product> addAll(@ModelAttribute("product") Product prod)
	{
			

			public ResponseEntity<Product> addAll(
					@RequestParam("id") int pid,
					@RequestParam("name") String pname,
					@RequestParam("price") double price,
					@RequestParam("description") String desc,
					@RequestParam("inid") int inid,
					@RequestParam("iname") String inname		
					){

					Inventory inventory = new Inventory();
					inventory.setId(inid);
					inventory.setName(inname);
					
					Product prod = new Product();
					prod.setId(pid);
					prod.setName(pname);
					prod.setPrice(price);
					prod.setDescription(desc);
					prod.setInventory(inventory);
			
			Product pro = productservice.addProduct(prod);
			
			
		if(pro==null)
		{
			return new ResponseEntity("No Product to show", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity <Product> (pro, HttpStatus.OK);
	}
	*/
	
	
/*	@RequestMapping(value="/search",method=RequestMethod.GET)
	public Product getProduct2(@RequestParam("id") int id){
		return productservice.getProduct(id);
	}*/
}
