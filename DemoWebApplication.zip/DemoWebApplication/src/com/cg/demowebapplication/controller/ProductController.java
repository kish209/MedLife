package com.cg.demowebapplication.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.demowebapplication.dto.Product;
import com.cg.demowebapplication.service.ProductServiceImp;


/**
 * Servlet implementation class ProductController
 */
@WebServlet(urlPatterns= {"/add","/show","/addproduct"},loadOnStartup=1)
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

ProductServiceImp service = new ProductServiceImp();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//System.out.println("check......");
		
		doPost(request,response);
		
		
		//response.setContentType("application/vnd.ms-excel");
		/*		out.println("No\tName\tMaths\tComp\tTotal");
		out.println("1\tkishor\t65\t70\tSUM(B2:D2)");
		out.println("2\tManthan\t60\t80\tSUM(B2:D2)");*/
		
		
		
/*		response.setContentType("text/html");
		response.setIntHeader("Refresh", 3);
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		String dateOne= df.format(date);
		
		PrintWriter out = response.getWriter();
		out.println("<!Doctype HTML>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title> Auto Page Refresh </title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<p>Page Last Refreshed at : "+dateOne+"</p>");
		out.println("</body>");
		out.println("</html>");
		*/
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub 
		//doGet(request, response);
		String url = request.getServletPath();
		
		if(url.equals("/add"))
		{
			//AddProduct.jsp
			RequestDispatcher req = request.getRequestDispatcher("AddProduct.jsp");
			req.forward(request, response);
		}
		
		if(url.equals("/show"))
		{
			//ShowProduct.jsp
			List<Product> mylist=service.showProduct();
			request.setAttribute("myproduct", mylist);
			RequestDispatcher req = request.getRequestDispatcher("ShowProduct.jsp");
			req.forward(request, response);
		}
		
		if(url.equals("/addproduct"))
		{
		//fetch the data from AddProduct.jsp
			
		String productId=request.getParameter("prodid");
		String productName=request.getParameter("prodname");
		String productPrice=request.getParameter("prodprice");
		String productOnline=request.getParameter("prodonline");
		String productcata=request.getParameter("cata");
		
		Product product = new Product();
		product.setId(Integer.parseInt(productId));
		product.setName(productName);
		product.setPrice(Double.parseDouble(productPrice));
		product.setOnline(productOnline);
		product.setCategory(productcata);
		
		service.addProduct(product);
		//request.setAttribute("myproduct", product);
		PrintWriter out = response.getWriter();
		out.println("Product Id is "+productId+"");
		out.println("Product name is "+productName+"");
		out.println("Product price is "+productPrice+"");
		out.println("Product online is "+productOnline+"");
		out.println("Product category is "+productcata+"");
		
		
		RequestDispatcher res = request.getRequestDispatcher("productlist.jsp");
		
		
		res.forward(request, response);
	/*	
		//response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//out.println("<html><head>My Output</head><body>");
		out.println(" Product Id is "+productId+"");
		out.println(" Product Name is "+productName);
		out.println(" Product Price is "+productPrice);
		out.println(" Product Online is "+productOnline);
		
		//out.println("</body></html>");
		*/
		}
		
		//System.out.println("Product Id: "+productId +"\n"+"Product Name: "+productName+"\n"+"Product Price: "+productPrice+" \n"+ "Product Online: "+productOnline+"\n"+"Product catagories: "+" "+productcata);
	}

}
