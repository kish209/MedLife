package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dao.ProductRepository;
import com.cg.demowebapplication.dao.ProductRepositoryImp;
import com.cg.demowebapplication.dto.Product;

public class ProductServiceImp implements ProductService {

	
	public ProductServiceImp() {
		repository= new ProductRepositoryImp();
	}
	ProductRepository repository;
	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		
		repository.save(product);
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		return repository.showAll();
	}

}
