package com.cg.demowebapplication.dao;

import java.util.List;
import com.cg.demowebapplication.dto.Product;

public interface ProductRepository 
{
public void save(Product product);
public List<Product> showAll();
}
