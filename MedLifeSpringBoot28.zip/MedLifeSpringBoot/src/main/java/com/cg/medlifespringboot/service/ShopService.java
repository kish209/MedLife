package com.cg.medlifespringboot.service;

import java.util.List;

import com.cg.medlifespringboot.dto.Shop;

public interface ShopService {
public Shop addShop(Shop shop) ;
public Shop searchById(int id);
public List<Shop> searchByMedicine(String medicineName);
public List<Shop> showAll();
}