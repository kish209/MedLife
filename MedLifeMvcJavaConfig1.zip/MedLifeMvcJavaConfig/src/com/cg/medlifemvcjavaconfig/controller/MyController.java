package com.cg.medlifemvcjavaconfig.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.medlifemvcjavaconfig.dto.Address;
import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.dto.Medicine;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.dto.Trade;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineIdAlreadyExistException;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.exceptions.TradeDataNotGettingException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.service.CustomerService;
import com.cg.medlifemvcjavaconfig.service.ShopService;
import com.cg.medlifemvcjavaconfig.service.TradeService;


@Controller
public class MyController {

	@Autowired
	CustomerService customerService;
	@Autowired
	ShopService shopService;
	@Autowired
	TradeService tradeService;
	Shop shopOne;
	Trade t = new Trade() ;
	double totalPrice=0.0;
	Customer customer;
	
	
	@GetMapping("login")
	public String loginPage()
	{
		return "listpage";
	}
	
	
	

	 @PostMapping("checkLogin")
     public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
		// System.out.println("check login");
		 if(user.equals("admin") && pass.equals("123")) {
			 return "listpage";
		 }else {
			 return "error";
		 }
		// return null;
	 }
	 
	 @GetMapping("custadd")
	 public ModelAndView getAddCustomer(@ModelAttribute("customer") Customer cust) throws CustomerNotSaveIntoDatabase {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addcustomer", "details", myMap);
	 }
	 
	 @PostMapping("addcustomer")
	 public ModelAndView addCustomer(@ModelAttribute("customer") Customer cust) throws CustomerNotSaveIntoDatabase{
//		 System.out.println(pro);
		 this.customer=cust;
		 Customer customer= customerService.addCustomer(cust);
		 return new ModelAndView("success","key",customer);
	 }
	 
	 @GetMapping("showcust")
	 public ModelAndView showCustomer() throws CustomerDetailsNotFoundException {
		 List<Customer> myCustomer = customerService.showAllCustomers();
		 return new ModelAndView("showAllCustomer", "customershow", myCustomer);
	 }
	
	 
	 
	 @GetMapping("shopadd")
	 public ModelAndView getAddShop(@ModelAttribute("shop") Shop shopOne) {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addshop", "details", myMap);
	 }
	 
	 @PostMapping("addshop")
	 public ModelAndView addShop(@ModelAttribute("shop") Shop shopOne) throws ShopNotSaveIntoDatabase {
//		 System.out.println(pro);
		 //Shop shop= shopService.addShop(shopOne);
		 this.shopOne=shopOne;
		 return new ModelAndView("medicine");
	 }
	 
	 
	 /*@GetMapping("showshop")
	 public ModelAndView showShop()  {
		 List<Shop> myShop = shopService.showAllShop();
		 return new ModelAndView("showAllShop", "shopshow", myShop);
	 }
	 */
/*	 @GetMapping("addmed")
	 public ModelAndView addMed() throws CustomerDetailsNotFoundException {
		 List<Shop> myMedicine = shopService.showAllShop();
		 return new ModelAndView("showAllShop", "customershow", myMedicine);
	 }*/
	 
	 @GetMapping("addmed")
		 public ModelAndView addMed(@ModelAttribute("medicine") Medicine med) {
		
			 return new ModelAndView("medicine", "key", med);
		 
	 }
	
	 @PostMapping("datamedicine")
	 public ModelAndView addMed(@RequestParam("medicineName") String medicineName,
			 @RequestParam("medicineType") String medicineType,@RequestParam("medicinePrice") double medicinePrice) throws MedicineIdAlreadyExistException, ShopNotSaveIntoDatabase{
//		 System.out.println(pro);
		// System.out.println(shopId);
		 Medicine med = new Medicine();
		 //med.setMedicineId(medicineId);;
		 med.setMedicineName(medicineName);
		 med.setMedicineType(medicineType);
		 med.setMedicinePrice(medicinePrice);
		 
		 List<Medicine> medicineList = new ArrayList<Medicine>();
		 medicineList.add(med);
		 
		 Shop shopTwo = new Shop();
		 Address add = new Address();
		 
		 shopTwo.setShopId(shopOne.getShopId());
		 shopTwo.setShopName(shopOne.getShopName());
		// shopTwo.setAddress(shopOne.getAddress());
		 add.setAddressId(shopOne.getAddress().getAddressId());
		 add.setHouseNumber(shopOne.getAddress().getHouseNumber());
		 add.setArea(shopOne.getAddress().getArea());
		 add.setCity(shopOne.getAddress().getCity());
		 add.setPincode(shopOne.getAddress().getPincode());
		 shopTwo.setAddress(add);
		 
		 shopTwo.setMedicines(medicineList);
		 System.out.println("controller"+shopTwo);
		 Shop shop= shopService.addShop(shopTwo);
		 
		 return new ModelAndView("successmed","key",shop);
	 }
	 
	 @GetMapping("success")
	 public String homePage()
	 {
		return "listpage";
		 
	 }
	 
	 
	 @GetMapping("search")
	 public ModelAndView searchCust(@ModelAttribute("customer") Customer cust) throws  CustomerDetailsNotFoundException {

		// Customer customer= customerService.searchById(cust.getCustId());
		 return new ModelAndView("findcust","key",cust);
	 }
	 
	 @PostMapping("findcust")
	 public ModelAndView searchCustOne(@ModelAttribute("customer") Customer cust) throws CustomerDetailsNotFoundException
	 {

		 customer= customerService.searchById(cust.getCustId());
		 return new ModelAndView("searchmed","key",customer);
	 }
	 
	 @GetMapping("searchmed")
	 public ModelAndView searchMed(@ModelAttribute("medicine") Medicine med) throws MedicineNotFoundException
	 {
		// Customer customer= customerService.searchById(cust.getCustId());
		 return new ModelAndView("searchmed","comm",med);
	 }
	 
	 @PostMapping("searchmed")
	 public ModelAndView searchMedOne(@ModelAttribute("medicine") Medicine med) throws MedicineNotFoundException
	 {

		List<Shop> shopOne = shopService.searchByMedicine(med.getMedicineName());
		 return new ModelAndView("showshopmed","comm",shopOne);
	 }
	
 @PostMapping("tran")
	 public ModelAndView tran(@ModelAttribute("shop") Shop shop) throws TradeNotSaveIntoDatabase, ParseException, CustomerDetailsNotFoundException
	 {
	
	 SimpleDateFormat formatDate=  new SimpleDateFormat("dd-MM-yyyy");
		String strDate= formatDate.format(new Date());
		Date currentDate= formatDate.parse(strDate);
	 
		//customer= customerService.searchById(customer.getCustId());
		
		 System.out.println(shop.getShopId());
		 Shop shop1= shopService.findById(shop.getShopId());
		 System.out.println(shop1);
		
		 Trade t1 = new Trade();
		 Customer c = new Customer();
		 Address add= new Address();
		 Medicine med = new Medicine();
	/*	 String cust1 ="kish";
		 System.out.println(cust1);*/
		
	
		 System.out.println("before "+t);
		 
		 
		 t.setTotalPrice(shop1.getMedicines().get(0).getMedicinePrice());
		
		 System.out.println("after price"+t);
		 t.setDate(currentDate);
		
		 c.setCustId(customer.getCustId());
		 c.setCustName(customer.getCustName());
		 c.setContact(customer.getContact());
		 add.setHouseNumber(customer.getAddress().getHouseNumber());
		 add.setArea(customer.getAddress().getArea());
		 add.setCity(customer.getAddress().getCity());
		 add.setPincode(customer.getAddress().getPincode());
		 
		 c.setAddress(add);
		 t.setCustomer(customer);
		// t.setCustomer(c);
		 t.setShop(shop1);
		 System.out.println("t..."+t);
		 t1=tradeService.addTrade(t);
		// t1= tradeService.addTrade(t);
		 return new ModelAndView("addtrade","msg",t1);
	 }
 
 
// @GetMapping("showtrade")
// public ModelAndView getTran(@ModelAttribute("trade") Trade trade)
// {
//	// Customer customer= customerService.searchById(cust.getCustId());
//	 return new ModelAndView("searchmed","comm",trade);
// }
 
 @PostMapping("showtrade")
 public ModelAndView showTrade(@ModelAttribute("trade") Trade trade) throws TradeDataNotGettingException
 {

	List<Trade> tradeOne = tradeService.showTrade();
	
	 return new ModelAndView("showtrade","comm",tradeOne);
 }
 
/* 
 @GetMapping("addtrade")
 public ModelAndView transactionOne()
 {
	 return new ModelAndView("showtrade","show",t1)
 }
 
	 
	 @PostMapping("addtrade")
	 public ModelAndView transaction(@ModelAttribute("trade") Trade trade) throws TradeNotSaveIntoDatabase
	 {
		 System.out.println("In add trade");
		 Shop shop1= shopService.findById(trade.getShop().getShopId());
		 Trade t = new Trade();
		 Trade t1 = new Trade();
		 t.setShop(shop1);
		 t1= tradeService.addTrade(t);
		 return new ModelAndView("showtrade","show",t1);
	 }
	 */
	 
	 

 @ExceptionHandler(CustomerNotSaveIntoDatabase.class)
	public ModelAndView CustomerNotSaveIntoDatabase(CustomerNotSaveIntoDatabase u) {

		ModelAndView model = new ModelAndView("error/errorc");

		
		model.addObject("errmsgkey", u.getMessage());

		return model;

	} 
 
 @ExceptionHandler(CustomerDetailsNotFoundException.class)
	public ModelAndView CustomerDetailsNotFoundException(CustomerDetailsNotFoundException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey1", u.getMessage());

		return model;

	} 
 
 @ExceptionHandler(MedicineNotFoundException.class)
	public ModelAndView MedicineNotFoundException(MedicineNotFoundException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey2", u.getMessage());

		return model;

	} 
 
 
 @ExceptionHandler(MedicineIdAlreadyExistException.class)
	public ModelAndView MedicineIdAlreadyExistException(MedicineIdAlreadyExistException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey3", u.getMessage());

		return model;

	} 
 
 @ExceptionHandler(ShopNotSaveIntoDatabase.class)
	public ModelAndView ShopNotSaveIntoDatabase(ShopNotSaveIntoDatabase u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey4", u.getMessage());

		return model;

	} 
 
 @ExceptionHandler(TradeDataNotGettingException.class)
	public ModelAndView TradeDataNotGettingException(TradeDataNotGettingException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey5", u.getMessage());

		return model;

	} 
  
 

}
