package com.cg.medlifemvcjavaconfig.exceptions;

public class CustomerNotSaveIntoDatabase extends Exception {
	public CustomerNotSaveIntoDatabase()
	{
		
	}
	
	public CustomerNotSaveIntoDatabase(String exceptionMessage) {
		super(exceptionMessage);
	}
}
