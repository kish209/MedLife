package com.cg.medlifemvcjavaconfig.exceptions;

public class DataNotSaveException extends Exception {
	public DataNotSaveException()
	{
		
	}
	
	public DataNotSaveException(String exceptionMessage)
	{
		super(exceptionMessage);
	}

}
