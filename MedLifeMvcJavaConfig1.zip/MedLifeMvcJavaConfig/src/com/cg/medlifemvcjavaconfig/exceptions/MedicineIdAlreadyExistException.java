package com.cg.medlifemvcjavaconfig.exceptions;

public class MedicineIdAlreadyExistException extends Exception
{
	public MedicineIdAlreadyExistException() {
		
	}
	
	public MedicineIdAlreadyExistException(String exceptionMessage) {
		
		super(exceptionMessage);
	}
	

}
