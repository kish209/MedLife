package com.cg.medlifemvcjavaconfig.dao;


import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;


public interface CustomerRepository {

	public Customer save(Customer customer) throws CustomerNotSaveIntoDatabase;
	public Customer findById(String id) throws CustomerDetailsNotFoundException;
	public List<Customer> showAllCustomers();
}
