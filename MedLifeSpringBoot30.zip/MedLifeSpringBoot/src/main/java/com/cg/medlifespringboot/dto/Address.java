package com.cg.medlifespringboot.dto;

import javax.persistence.CascadeType;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="address")
public class Address {
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="address_id")
	private int addressId;
	
	@Column(name="house_number")
	private String houseNumber;
	
	@Column(name="house_area")
	private String area;
	
	@Column(name="city")
	private String city;
	
	@Column(name="pincode")
	private long pincode; 
	

	@OneToOne(mappedBy="address",cascade=CascadeType.ALL)
	@JoinColumn(name="cust_id")
	private Customer customer;



	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", houseNumber=" + houseNumber + ", area=" + area + ", city=" + city
				+ ", pincode=" + pincode + "]";
	}





	public int getAddressId() {
		return addressId;
	}





	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}





	public String getHouseNumber() {
		return houseNumber;
	}





	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}





	public String getArea() {
		return area;
	}





	public void setArea(String area) {
		this.area = area;
	}





	public String getCity() {
		return city;
	}





	public void setCity(String city) {
		this.city = city;
	}





	public long getPincode() {
		return pincode;
	}





	public void setPincode(long pincode) {
		this.pincode = pincode;
	}





	public Address(int addressId, String houseNumber, String area, String city, long pincode) {
		super();
		this.addressId = addressId;
		this.houseNumber = houseNumber;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
	}





	//default constructor
	public Address()
	{
		
	}
	

}