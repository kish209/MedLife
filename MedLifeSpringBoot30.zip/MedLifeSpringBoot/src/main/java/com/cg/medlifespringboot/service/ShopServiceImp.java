package com.cg.medlifespringboot.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifespringboot.dto.Shop;

import com.cg.medlifespringboot.dao.ShopRepository;

@Service
public class ShopServiceImp implements ShopService {

	// static int countShop=100;
//	static int countAddress=200;
	@Autowired
	ShopRepository shoprepository;
	
	static final Logger logger = Logger.getLogger(ShopServiceImp.class); 

	public ShopServiceImp() {

	}

	public Shop addShop(Shop shop){
		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");

		return shoprepository.save(shop);
	}
	
	  public List<Shop> searchByMedicine(String medicineName){ 
		  
		  return shoprepository.findBymedicineName(medicineName); }
	 

	@Override
	public Shop searchById(int id) {
		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");
		
		// TODO Auto-generated method stub
		return shoprepository.findByshopId(id);
	}

	@Override
	public List<Shop> showAll() {
		
		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");
		
		// TODO Auto-generated method stub
		return shoprepository.findAll();
	}
}