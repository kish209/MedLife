package com.cg.medlifespringboot.dto;

import java.util.ArrayList;

import java.util.Date;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name="trade")
public class Trade {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="trade_id")
	private int id;
	
	@Column(name="total_price")
	private double totalPrice;
	
	@Column(name="trade_date")
	@Temporal(TemporalType.DATE)
	private Date date;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="cust_id")
	@JsonIgnore
	private Customer customer;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="shop_id")
	@JsonIgnore
	private Shop shop;
	
	@OneToMany(mappedBy="trade")
	//@JoinColumn(name="trade_id")
	private List <Medicine> medicines;
     
	
	



	//default constructor
	public Trade() {
	}




	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}




	public double getTotalPrice() {
		return totalPrice;
	}




	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}




	public Date getDate() {
		return date;
	}




	public void setDate(Date date) {
		this.date = date;
	}




	public Customer getCustomer() {
		return customer;
	}




	public void setCustomer(Customer customer) {
		this.customer = customer;
	}




	public Shop getShop() {
		return shop;
	}




	public void setShop(Shop shop) {
		this.shop = shop;
	}




	@Override
	public String toString() {
		return "Trade [id=" + id + ", totalPrice=" + totalPrice + ", date=" + date + ", customer=" + customer
				+ ", shop=" + shop + "]";
	}




	public Trade(int id, double totalPrice, Date date, Customer customer, Shop shop) {
		super();
		this.id = id;
		this.totalPrice = totalPrice;
		this.date = date;
		this.customer = customer;
		this.shop = shop;
	}
	

	
}
