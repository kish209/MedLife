package com.cg.medlifespringboot.dto;
import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="customer")
public class Customer
{
	
	@Id
	@Column(name="cust_id")
	private String custId;
	
	@Column(name="cust_name")
	private String custName;
	
	@Column(name="contact")
	private BigInteger contact;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_id")
	private Address address;
	
/*    @OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="trade_id")
    @JsonIgnore
	private List<Trade> trade;*/

	//default constructor
	public  Customer() {}
	
	//parameterized constructor
	public Customer(String custId, String custName, BigInteger contact, Address address) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.contact = contact;
		this.address = address;
	}
	
	public String toString() {
		return "[Customer Id=" + custId + ", Customer Name=" + custName + ", Contact=" + contact + ", Address=" + address
				+ "]";
	}

	//getter setter
	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public BigInteger getContact() {
		return contact;
	}

	public void setContact(BigInteger contact) {
		this.contact = contact;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	/*public List<Trade> getTrade() {
		return trade;
	}

	public void setTrade(List<Trade> trade) {
		this.trade = trade;
	}

	*/
	
	
}