package com.cg.medlifespringboot.dao;

import com.cg.medlifespringboot.dto.Medicine;

public interface MedicineRepository {

	public Medicine findBymemedicineId(int id);
}
