package com.cg.medlife.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.cg.medlife.dto.Address;
import com.cg.medlife.dto.Customer;
import com.cg.medlife.dto.Medicine;
import com.cg.medlife.dto.Shop;
import com.cg.medlife.dto.Trade;
import com.cg.medlife.service.CustomerService;
import com.cg.medlife.service.CustomerServiceImp;

import java.util.List.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.medlife.dto.Customer;
import com.cg.medlife.dto.Medicine;
import com.cg.medlife.dto.Shop;
import com.cg.medlife.service.CustomerService;
import com.cg.medlife.service.CustomerServiceImp;
import com.cg.medlife.service.ShopService;
import com.cg.medlife.service.ShopServiceImp;
import com.cg.medlife.dto.Address;

public class DButil {
	
	public static List<Shop> shopData = new ArrayList<Shop>();
	public static List<Trade> tradeData = new ArrayList<Trade>();
	public static List <Customer> customerData = new ArrayList<Customer>();
	
	static {
		CustomerService customerservice=new CustomerServiceImp();

		Customer customer1 = new Customer("cust1","kishor",new BigInteger("8805072549"),new Address("11","Talwade","Pune",411062));
		Customer customer2 = new Customer("cust2","manthan",new BigInteger("7020231164"),new Address("12","Akurdi","Pune",411044));

		customer1=customerservice.addCustomer(customer1);
		customer2=customerservice.addCustomer(customer2);
		}
}