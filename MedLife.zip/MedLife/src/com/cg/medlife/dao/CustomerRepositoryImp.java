package com.cg.medlife.dao;

import com.cg.medlife.dto.Customer;
import com.cg.medlife.util.DButil;
public class CustomerRepositoryImp implements CustomerRepository {
	public CustomerRepositoryImp()
	{}

	public Customer save(Customer customer) {
		DButil.customerData.add(customer);
		return  customer;
	}


	public Customer findById(String id) {
		for (Customer customer : DButil.customerData) {
			if(customer.getCustId().equalsIgnoreCase(id))
				return customer;
		}
		return null;
	}	
}