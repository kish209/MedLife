package com.cg.medlife.dao;

import java.util.List;

import com.cg.medlife.dto.Customer;
import com.cg.medlife.dto.Shop;

public interface CustomerRepository {

	public Customer save(Customer customer);
	public Customer findById(String id);
}
