package com.cg.medlife.dao;


import com.cg.medlife.dto.Customer;


public interface CustomerRepository {

	public Customer save(Customer customer);
	public Customer findById(String id);
}
