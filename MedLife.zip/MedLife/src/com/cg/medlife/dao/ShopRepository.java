package com.cg.medlife.dao;

import java.util.List;

import com.cg.medlife.dto.Shop;

public interface ShopRepository {

	public Shop save(Shop shop);
	public List<Shop> findByName(String medicineName);

}
