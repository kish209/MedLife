package com.cg.medlife.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.medlife.dto.Customer;
import com.cg.medlife.dto.Medicine;
import com.cg.medlife.dto.Shop;
import com.cg.medlife.util.DButil;

public class ShopRepositoryImp implements ShopRepository{

	List<Medicine> medicineData;
	public ShopRepositoryImp()
	{

		medicineData = new ArrayList<Medicine>();
	}

	public Shop save(Shop shop) {
		DButil.shopData.add(shop);
		return shop;
	}

	public List<Shop> findByName(String medicineNameOne) {
		List<Shop> shop1=new ArrayList <Shop>();
		for(Shop shop : DButil.shopData) 
		{
			if( (!shop1.contains(shop)))
				for (Medicine medicine : shop.getMedicines()) {
					if(medicine.getMedicineName().toLowerCase().equals(medicineNameOne.toLowerCase()))
					{
						shop1.add(shop);
					}
				}
		}
		return shop1;
	}
}