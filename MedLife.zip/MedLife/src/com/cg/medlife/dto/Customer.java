package com.cg.medlife.dto;

import java.math.BigInteger;

public class Customer{
	
	private String custId;
	private String custName;
	private BigInteger contact;
	private Address address;
	public  Customer() {}

	public Customer(String custId, String custName, BigInteger contact, Address address) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.contact = contact;
		this.address = address;
	}
	
	public String toString() {
		return "[Customer Id=" + custId + ", Customer Name=" + custName + ", Contact=" + contact + ", Address=" + address
				+ "]";
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public BigInteger getContact() {
		return contact;
	}

	public void setContact(BigInteger contact) {
		this.contact = contact;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}	
}