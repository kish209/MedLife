package com.cg.medlife.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.cg.medlife.dto.Customer;
import com.cg.medlife.dto.Medicine;
import com.cg.medlife.dto.Shop;
import com.cg.medlife.dto.Trade;
import com.cg.medlife.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlife.exceptions.DateNotFoundException;
import com.cg.medlife.exceptions.MedicineNotFoundException;
import com.cg.medlife.service.CustomerService;
import com.cg.medlife.service.CustomerServiceImp;
import com.cg.medlife.service.ShopService;
import com.cg.medlife.service.ShopServiceImp;
import com.cg.medlife.service.TradeService;
import com.cg.medlife.service.TradeServiceImp;
import com.cg.medlife.dto.Address;
public class MedLife{

	public MedLife()
	{}

	public static void main(String[] args) throws ParseException 
	{
		CustomerService customerservice=new CustomerServiceImp();
		ShopService shopservice=new ShopServiceImp();
		TradeService tradeservice=new TradeServiceImp();

		Scanner scan = new Scanner(System.in);
		int choice = 0;
		int shopChoice=0;
		char ch='Y';
		//Address address = new Address() ;
		int countOne =1; 

		do
		{
			printMenu();
			System.out.println("Enter Choice : ");
			choice =scan.nextInt();
			switch(choice)
			{
			case 1:

				List <Medicine> medicines = new ArrayList<Medicine>();

				Medicine medicines1 = new Medicine("Crocin","Tablet",5.00);
				Medicine medicines2 = new Medicine("TiscofD","Syrup",50.00);
				Medicine medicines3 = new Medicine("Omi","Tablet",6.00);
				Medicine medicines4 = new Medicine("paracetamol","Tablet",10.00);

				medicines.add(medicines1);
				medicines.add(medicines2);
				medicines.add(medicines3);
				medicines.add(medicines4);

				List <Medicine> medicinesOne = new ArrayList<Medicine>();

				Medicine medicinesOne1 = new Medicine("Crocin","Tablet",5.00);
				Medicine medicinesOne2 = new Medicine("Omi","Tablet",6.00);
				Medicine medicinesOne3 = new Medicine("paracetamol","Tablet",10.00);
				Medicine medicinesOne4 = new Medicine("combiflam","Tablet",12.00);

				medicinesOne.add(medicinesOne1);
				medicinesOne.add(medicinesOne2);
				medicinesOne.add(medicinesOne3);
				medicinesOne.add(medicinesOne4);


				Shop shop1 = new Shop(1,"Mauli",new Address("101","Talwade","Pune",411062),medicines);
				Shop shop2 = new Shop(2,"Om",new Address("102","Nigdi","Pune",411044),medicinesOne);

				shop1 = shopservice.addShop(shop1);
				shop2 = shopservice.addShop(shop2);
				System.out.println(shop1.getShopName()+" , "+shop2.getShopName()+" Shops are added successfully.. \n");

				break;


			case 2:

				double totalPrice=0.0;
				List <Medicine> med= new ArrayList<>();
				Shop shopOne=null;

				SimpleDateFormat formatDate=  new SimpleDateFormat("dd-MM-yyyy");
				String strDate= formatDate.format(new Date());
				Date currentDate= formatDate.parse(strDate);

				System.out.println("Enter Customer ID: ");
				String custId=scan.next();
				Customer customer;
				try {
					customer = customerservice.searchById(custId);
					try {
						do {
							shopChoice=0;
							System.out.println("Enter Medicine name : ");
							String medicineNameOne = scan.next();
							int count=0;
							List<Shop> shops;

							shops = shopservice.searchByMedicine(medicineNameOne);
							System.out.println("\n**********************************");
							if(shopChoice==0) 
							{
								for(Shop shoplist : shops)
								{	
									count++;			
									System.out.print(count+".\nShop ID: "+shoplist.getShopId()+"\nShop Name: "+shoplist.getShopName()+"\nShop Address: "+shoplist.getAddress());
									for(Medicine medRef:shoplist.getMedicines())
									{
										if(medRef.getMedicineName().equalsIgnoreCase(medicineNameOne))
											System.out.print("\nMedicine Name: "+medRef.getMedicineName()+"\nMedicine Price: "+medRef.getMedicinePrice()+"Rs"+"\nMedicine Type: "+medRef.getMedicineType());
										System.out.println();
									}
								}
								System.out.println("**********************************\n");

								System.out.println("Select shop: ");
								shopChoice=scan.nextInt();
							}

							Medicine myMed= new Medicine();
							for(int i=0;i<count;i++)
							{
								if(i==shopChoice-1)
								{

									System.out.println(shopOne=shops.get(i));

									for (Medicine medicine : shopOne.getMedicines()) 
									{
										if(medicine.getMedicineName().toLowerCase().equals(medicineNameOne.toLowerCase()))
											myMed=medicine;

									}

									break;
								}
							}

							med.add(myMed);
				
							totalPrice+=myMed.getMedicinePrice();
							System.out.println(shopChoice);
							System.out.println("Buy more medicines? (Y/N): ");
							ch=scan.next().charAt(0);
							System.out.println();
						} while(ch=='Y'||ch=='y');

						System.out.println("\n**********************************");
						Trade trade=new Trade(countOne, totalPrice, currentDate, customer, shopOne, med);
						tradeservice.addTrade(trade);
						System.out.println(tradeservice.showTrade());
						System.out.println("\n");
						countOne++;
						System.out.println("**********************************\n");
					}
					catch (MedicineNotFoundException e) {
						System.out.println(e.getMessage());

					}
				}
				catch (CustomerDetailsNotFoundException e1) {
					System.out.println(e1.getMessage());
				}

				break;


			case 3:

				System.out.println("Enter Date : ");							
				String dateOne = scan.next();

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

				Date givendate;
				try {		
					givendate = dateFormat.parse(dateOne);
					List<Trade> tradeList = tradeservice.searchByDate(givendate);
					for(Trade tradeRef:tradeList)
					{
						System.out.println("\n"+tradeRef);
					}

				} catch (DateNotFoundException e) {

					System.out.println(e.getMessage());	
				}

				break;


			case 4:

				System.out.println("Enter Customer Id : ");
				String custIdOne = scan.next();

				System.out.println("Enter Date : ");
				String dateOneOne = scan.next();


				SimpleDateFormat dateFormatOne = new SimpleDateFormat("dd-MM-yyyy");

				Date givendateOne;
				try {

					givendateOne = dateFormatOne.parse(dateOneOne);
					List<Trade> tradeListOne = tradeservice.searchCustomerByDate(custIdOne, givendateOne);

					for(Trade tradeRefOne :tradeListOne)
					{
						System.out.println("\n**********************************");
						System.out.println(tradeRefOne);
						System.out.println("**********************************\n");
					}

				} catch (DateNotFoundException e) {

					System.out.println(e.getMessage());

				}

				break;


			case 5:

				System.exit(choice);
				break;


			default :
				System.out.println("Wrong choice ..!");
				break;
			}


		}while(choice!=6);
		scan.close();
	}
	
	
	private static void printMenu() 
	{
		System.out.println("\n\n\n**********************************");
		System.out.println("**********************************\n");
		System.out.println("    **************");
		System.out.println("    *  MedLife   *");
		System.out.println("    **************\n");
		System.out.println("1. Add new shop ");
		System.out.println("2. Search Medicines from shops");
		System.out.println("3. Search Transaction By date");
		System.out.println("4. Search Customer Transaction By Date");
		System.out.println("5. Exit\n");
		System.out.println("**********************************");
		System.out.println("**********************************\n");

	}
}