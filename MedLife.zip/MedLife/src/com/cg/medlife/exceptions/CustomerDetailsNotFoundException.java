package com.cg.medlife.exceptions;

public class CustomerDetailsNotFoundException extends Exception{
	public CustomerDetailsNotFoundException() 
	{}
	
	public CustomerDetailsNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}