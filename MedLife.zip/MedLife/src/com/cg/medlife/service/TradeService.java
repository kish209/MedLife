package com.cg.medlife.service;
import java.util.Date;
import java.util.List;
import com.cg.medlife.dto.Trade;
import com.cg.medlife.exceptions.DateNotFoundException;
public interface TradeService{
	public List <Trade> searchByDate(Date date) throws DateNotFoundException;
	public List <Trade> searchCustomerByDate(String custId, Date date) throws DateNotFoundException;
	public List<Trade> showTrade();
	public Trade addTrade(Trade trade);
}
