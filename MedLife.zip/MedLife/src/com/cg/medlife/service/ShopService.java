package com.cg.medlife.service;

import java.util.List;

import com.cg.medlife.dto.Medicine;
import com.cg.medlife.dto.Shop;
import com.cg.medlife.exceptions.MedicineNotFoundException;

public interface ShopService {
public Shop addShop(Shop shop);
public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException;
}