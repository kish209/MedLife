package com.cg.medlife.service;

import java.util.List;


import com.cg.medlife.dao.ShopRepository;
import com.cg.medlife.dao.ShopRepositoryImp;
import com.cg.medlife.dto.Shop;
import com.cg.medlife.exceptions.MedicineNotFoundException;

public class ShopServiceImp implements ShopService{

	private ShopRepository shoprepository;
	public ShopServiceImp(){
		shoprepository= new ShopRepositoryImp();
	}

	public Shop addShop(Shop shop) {

		return shoprepository.save(shop);
	}

	public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException {

		if(shoprepository.findByName(medicineName).isEmpty())
			throw new MedicineNotFoundException("Medicine not found");
		return shoprepository.findByName(medicineName);
	}
}