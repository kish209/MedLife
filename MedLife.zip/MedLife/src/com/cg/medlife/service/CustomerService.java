package com.cg.medlife.service;

import java.util.List;

import com.cg.medlife.dto.Customer;
import com.cg.medlife.exceptions.CustomerDetailsNotFoundException;

public interface CustomerService{

	public Customer addCustomer(Customer customer);
	public Customer searchById(String id) throws CustomerDetailsNotFoundException;
}