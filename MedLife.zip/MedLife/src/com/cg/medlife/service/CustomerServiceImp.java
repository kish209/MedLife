package com.cg.medlife.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.medlife.dao.CustomerRepositoryImp;
import com.cg.medlife.dto.Customer;
import com.cg.medlife.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlife.exceptions.MedicineNotFoundException;


public class CustomerServiceImp implements CustomerService{

	Customer customerData;
	CustomerRepositoryImp customerrepository;
	public CustomerServiceImp(){
		customerrepository = new CustomerRepositoryImp();
	}

	public Customer addCustomer(Customer customer) {
		return customerrepository.save(customer);
	}

	public Customer searchById(String id) throws CustomerDetailsNotFoundException {
		if(customerrepository.findById(id)==null)
			throw new CustomerDetailsNotFoundException("Customer not found");
		return customerrepository.findById(id);
	}
}