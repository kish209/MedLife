import { Component,OnInit} from "@angular/core";
import { MedlifeService } from "./app.medlifeservice";
import { Customer } from "./app.customer";
import { FormsModule }  from '@angular/forms';



@Component({
selector:'cust-app',
templateUrl:'app.addcustomer.html'

})
export class AddCustomerComponent implements OnInit{

    id: string;
    customers:Customer[];

model : any={};
constructor(private medlifeservice:MedlifeService){}
    

ngOnInit(){
    this.medlifeservice.getAllProduct().subscribe((data:Customer[])=>this.customers=data);
}

addProduct(){
    //console.log(this.model);
    this.medlifeservice.addAllProduct(this.model).subscribe((data:any)=>console.log(data));

    
    alert("Customer Added Successfully");

}





}