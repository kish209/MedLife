import {Component} from '@angular/core';


@Component({
selector:'update-prod',
templateUrl:'app.updateproduct.html'



})




export class UpdateProduct{
} 
 
