import{Injectable} from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from "rxjs"
import { Customer } from './app.customer';
import { Shop } from './app.shop';

@Injectable({
    providedIn:'root'
})
export class MedlifeService{
constructor(private http:HttpClient){}

getAllProduct(){
   return this.http.get("http://localhost:9098/medlife/showcustomer")
}

addAllProduct(cust:any){

    console.log(cust);
    let input = new FormData();
    input.append("custId",cust.id);
    input.append("custName",cust.name);
    input.append("contact",cust.contact);
    input.append("address.houseNumber",cust.addresshousenumber);
    input.append("address.area",cust.addressarea);
    input.append("address.city",cust.addresscity);
    input.append("address.pincode",cust.addresspincode);
    return this.http.post("http://localhost:9098/medlife/addcustomer",input)
}



addAllShop(shop:any){

    console.log("Shops ...."+shop);
    let input = new FormData();
    input.append("shopId",shop.id);
    input.append("shopName",shop.name);
    input.append("address.houseNumber",shop.addresshousenumber);
    input.append("address.area",shop.addressarea);
    input.append("address.city",shop.addresscity);
    input.append("address.pincode",shop.addresspincode);


    input.append("medicines[0].medicineName",shop.medicinesmedicinename);
    input.append("medicines[0].medicineType",shop.medicinesmedicinetype);
    input.append("medicines[0].medicinePrice",shop.medicinesmedicineprice);

    input.append("medicines[1].medicineName",shop.medicinesmedicinename);
    input.append("medicines[1].medicineType",shop.medicinesmedicinetype);
    input.append("medicines[1].medicinePrice",shop.medicinesmedicineprice);


    input.append("medicines[2].medicineName",shop.medicinesmedicinename);
    input.append("medicines[2].medicineType",shop.medicinesmedicinetype);
    input.append("medicines[2].medicinePrice",shop.medicinesmedicineprice);


    return this.http.post("http://localhost:9098/medlife/addshop",input)
}
}