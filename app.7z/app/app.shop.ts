import {Component} from '@angular/core';
import {Address } from './app.address';
import {Medicine} from './app.medicine';


export class Shop{

    id:number;
    name:string;
    address:Address;
    medicines:Medicine;
} 
 
