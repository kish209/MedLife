package com.cg.medlifemvcjavaconfig.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifemvcjavaconfig.dao.CustomerRepositoryImp;
import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;

@Service
@Transactional
public class CustomerServiceImp implements CustomerService{
	
	@Autowired
	CustomerRepositoryImp customerrepository;
	
	public CustomerServiceImp(){

	}

	public Customer addCustomer(Customer customer) throws CustomerNotSaveIntoDatabase {
		Customer cust =customerrepository.save(customer);
		if(cust==null)
			throw new CustomerNotSaveIntoDatabase("customer not save in database");
		return cust;
	}

	public Customer searchById(String id) throws CustomerDetailsNotFoundException {
		if(customerrepository.findById(id)==null)
			throw new CustomerDetailsNotFoundException("Customer not found");
		return customerrepository.findById(id);
	}
	public List <Customer> showAllCustomers() throws CustomerDetailsNotFoundException {
		if(customerrepository.showAllCustomers()==null)
			throw new CustomerDetailsNotFoundException("Customer nop");
		return customerrepository.showAllCustomers();
	}


}