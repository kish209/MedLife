package com.cg.medlifemvcjavaconfig.exceptions;

public class MedicineNotFoundException extends Exception {
	public MedicineNotFoundException() {
	}
	
	public MedicineNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}