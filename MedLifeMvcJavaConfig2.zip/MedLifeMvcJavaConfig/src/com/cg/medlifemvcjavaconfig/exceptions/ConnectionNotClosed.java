package com.cg.medlifemvcjavaconfig.exceptions;

public class ConnectionNotClosed extends Exception {
	
public ConnectionNotClosed()
{
	
}

public ConnectionNotClosed(String msg)
{
	super(msg);
}

}
