package com.cg.medlifemvcjavaconfig.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.medlifemvcjavaconfig.dto.Address;
import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.dto.Medicine;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.dto.Trade;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.exceptions.DataNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.DateNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineIdAlreadyExistException;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.exceptions.TradeDataNotGettingException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.service.CustomerService;
import com.cg.medlifemvcjavaconfig.service.ShopService;
import com.cg.medlifemvcjavaconfig.service.TradeService;

/*@author : kishor nivalkar
 * @since : 22 may 2019
 * @class: MyController
 * control all the functionality , handle the request
 * Mapping all things can be done in controller
*/
@Controller
public class MyController {

	@Autowired
	CustomerService customerService;
	@Autowired
	ShopService shopService;
	@Autowired
	TradeService tradeService;
	Shop shopOne;
	Trade t = new Trade() ;
	double totalPrice=0.0;
	Customer customer;
	static int id=0;
	static int gettranId(){
		return ++id;
		
	}
	
	
	/*@author : kishor nivalkar
	@since : 22 may 2019
	@return:  returning listpage
	Mapping login and return the list page
	*/
	@GetMapping("login")
	public String loginPage()
	{
		return "listpage";
	}
	

	/*
	 * get the list and store into addcustomer
	 * and adding customer details into database
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	 * @return:  addcustomer
	*/
	 @GetMapping("custadd")
	 public ModelAndView getAddCustomer(@ModelAttribute("customer") Customer cust) throws CustomerNotSaveIntoDatabase {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addcustomer", "details", myMap);
	 }
	 
		/*
		 * get the list and store into customer
		 * and adding customer details into database
		 * @author : kishor nivalkar
		 * @since : 22 may 2019
		 * @return:  customer
		*/
	 @PostMapping("addcustomer")
	 public ModelAndView addCustomer(@ModelAttribute("customer") Customer cust) throws CustomerNotSaveIntoDatabase{
//		 System.out.println(pro);
		 this.customer=cust;
		 Customer customer= customerService.addCustomer(cust);
		 return new ModelAndView("success","key",customer);
	 }
	 
		/*
		 * get the list and store into addcustomer
		 * and adding customer details into database
		 * @author : kishor nivalkar
		 * @since : 22 may 2019
		 * @return:  addcustomer
		*/
	 
	 @GetMapping("showcust")
	 public ModelAndView showCustomer() throws CustomerDetailsNotFoundException {
		 List<Customer> myCustomer = customerService.showAllCustomers();
		 return new ModelAndView("showAllCustomer", "customershow", myCustomer);
	 }
	
	 
	 
	 /*
		 * showing customer from the database
		 * @author : kishor nivalkar
		 * @since : 22 may 2019
		 * @return:  list
		*/
	 
	 @GetMapping("shopadd")
	 public ModelAndView getAddShop(@ModelAttribute("shop") Shop shopOne) {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addshop", "details", myMap);
	 }
	 
	 
	 /*
	 * adding shop into the database
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	 * @return:  shop
	*/
	 @PostMapping("addshop")
	 public ModelAndView addShop(@ModelAttribute("shop") Shop shopOne) throws ShopNotSaveIntoDatabase {

		 this.shopOne=shopOne;
		 return new ModelAndView("medicine");
	 }
	 
	 
	 @GetMapping("addmed")
		 public ModelAndView addMed(@ModelAttribute("medicine") Medicine med) {
		
			 return new ModelAndView("medicine", "key", med);
		 
	 }
	
	 /*
		 * adding medicines into selected shop
		 * @author : kishor nivalkar
		 * @since : 22 may 2019
		 * @return:  shop
		*/
	 @PostMapping("datamedicine")
	 public ModelAndView addMed(@RequestParam("medicineName") String medicineName,
			 @RequestParam("medicineType") String medicineType,@RequestParam("medicinePrice") double medicinePrice) throws MedicineIdAlreadyExistException, ShopNotSaveIntoDatabase{

		 Medicine med = new Medicine();
		 med.setMedicineName(medicineName);
		 med.setMedicineType(medicineType);
		 med.setMedicinePrice(medicinePrice);
		 
		 List<Medicine> medicineList = new ArrayList<Medicine>();
		 medicineList.add(med);
		 
		 Shop shopTwo = new Shop();
		 Address add = new Address();
		 
		 shopTwo.setShopId(shopOne.getShopId());
		 shopTwo.setShopName(shopOne.getShopName());
		// shopTwo.setAddress(shopOne.getAddress());
		 add.setAddressId(shopOne.getAddress().getAddressId());
		 add.setHouseNumber(shopOne.getAddress().getHouseNumber());
		 add.setArea(shopOne.getAddress().getArea());
		 add.setCity(shopOne.getAddress().getCity());
		 add.setPincode(shopOne.getAddress().getPincode());
		 shopTwo.setAddress(add);
		 
		 shopTwo.setMedicines(medicineList);
		 System.out.println("controller"+shopTwo);
		 Shop shop= shopService.addShop(shopTwo);
		 
		 return new ModelAndView("successmed","key",shop);
	 }
	 
	 /*
		 * showing listpage
		 * @author : kishor nivalkar
		 * @since : 22 may 2019
		 * @return:  listpage
		*/
	 @GetMapping("success")
	 public String homePage()
	 {
		return "listpage";
		 
	 }
	 
	 
	 @GetMapping("search")
	 public ModelAndView searchCust(@ModelAttribute("customer") Customer cust) throws  CustomerDetailsNotFoundException {

		// Customer customer= customerService.searchById(cust.getCustId());
		 return new ModelAndView("findcust","key",cust);
	 }
	 
	 @PostMapping("findcust")
	 public ModelAndView searchCustOne(@ModelAttribute("customer") Customer cust) throws CustomerDetailsNotFoundException
	 {

		 customer= customerService.searchById(cust.getCustId());
		 return new ModelAndView("searchmed","key",customer);
	 }
	 
	 @GetMapping("searchmed")
	 public ModelAndView searchMed(@ModelAttribute("medicine") Medicine med) throws MedicineNotFoundException
	 {
		// Customer customer= customerService.searchById(cust.getCustId());
		 return new ModelAndView("searchmed","comm",med);
	 }
	 
	 @PostMapping("searchmed")
	 public ModelAndView searchMedOne(@ModelAttribute("medicine") Medicine med) throws MedicineNotFoundException
	 {

		List<Shop> shopOne = shopService.searchByMedicine(med.getMedicineName());
		 return new ModelAndView("showshopmed","comm",shopOne);
	 }
	
 @PostMapping("tran")
	 public ModelAndView tran(@ModelAttribute("shop") Shop shop) throws TradeNotSaveIntoDatabase, ParseException, CustomerDetailsNotFoundException
	 {
	  int id=0;
	
	 SimpleDateFormat formatDate=  new SimpleDateFormat("dd-MM-yyyy");
		String strDate= formatDate.format(new Date());
		Date currentDate= formatDate.parse(strDate);
	 
	
		 System.out.println(shop.getShopId());
		 Shop shop1= shopService.findById(shop.getShopId());
		 System.out.println(shop1);
		
		 Trade t1 = new Trade();
		 
		 Customer c = new Customer();
		 Address add= new Address();
	
		 System.out.println("before "+t);
		 
		 
		 t.setTotalPrice(shop1.getMedicines().get(0).getMedicinePrice());
		
		 System.out.println("after price"+t);
		 t.setDate(currentDate);
		
		 c.setCustId(customer.getCustId());
		 c.setCustName(customer.getCustName());
		 c.setContact(customer.getContact());
		 add.setHouseNumber(customer.getAddress().getHouseNumber());
		 add.setArea(customer.getAddress().getArea());
		 add.setCity(customer.getAddress().getCity());
		 add.setPincode(customer.getAddress().getPincode());
		 
		 /* med.setMedicineName(medicine.getMedicineName());
		 med.setMedicineType(medicine.getMedicineType());
		 med.setMedicinePrice(medicine.getMedicinePrice()); 
		*/
		 c.setAddress(add);
		 t.setCustomer(customer);
	
		 t.setShop(shop1);
		 System.out.println("t..."+t);
	
		 t1= tradeService.addTrade(t);
		
		 return new ModelAndView("addtrade","msg",t1);
	 }
 
 
 /*
	 * showing all trade from database
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	 * @return:  tradelist
	*/
 @GetMapping("showtradeAll")
 public ModelAndView showTradeAll() throws TradeDataNotGettingException
 {

	List<Trade> tradeOne = tradeService.showTrade();
	 return new ModelAndView("showtrade","show",tradeOne);
 }
 

 @GetMapping("showtrade")
 public ModelAndView showTrade(@ModelAttribute("trade") Trade trade) throws TradeDataNotGettingException
 {

	List<Trade> tradeOne = tradeService.showTrade();
	 return new ModelAndView("searchtrade","comm",tradeOne);
 }
 
 
 /*
	 * searching date from trade
	 * and showing trade data of given trade date
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	 * @return:  trade
	*/
 @GetMapping("datesearch")
 public ModelAndView tradesearch()
 {
	 return new ModelAndView("searchtrade");
 }
 
 
 @PostMapping("searchtrade")
 public ModelAndView searchTrade(@RequestParam("date") String date) throws DateNotFoundException, ParseException
 {
	 System.out.println("in con"+date);
	
	 SimpleDateFormat formatDate=  new SimpleDateFormat("dd-MM-yyyy");
		Date currentDate= formatDate.parse(date);
		
	 List<Trade>tradeOne= tradeService.searchByDate(currentDate);
	 
	 return new ModelAndView("showtrade","show",tradeOne);
 }
 
 
 /*
	 * searching date and cust id from trade
	 * and showing trade data of given trade date and customer ID
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	 * @return:  trade
	*/
 @GetMapping("datesearchone")
 public ModelAndView tradesearchOne()
 {
	 return new ModelAndView("searchtradeu");
 }
 
 
 @PostMapping("searchtradeone")
 public ModelAndView searchTradeOne(@RequestParam("custId") String custId,@RequestParam("date") String date) throws DateNotFoundException, ParseException, DataNotFoundException
 {
	 System.out.println("in con"+date);
	
	 SimpleDateFormat formatDate=  new SimpleDateFormat("dd-MM-yyyy");
		Date currentDate= formatDate.parse(date);
		System.out.println("dat.."+date);
		System.out.println("customer id .."+custId);
		
	 List<Trade>tradeOne= tradeService.searchCustomerByDate(custId, currentDate);
	 
	 return new ModelAndView("showtrade","show",tradeOne);
 }
 
	 

 
 /*
	 *@exception : if customer not save in database with same customer id
	 * then it pass the exception id exist
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	 * 
	*/
 @ExceptionHandler(CustomerNotSaveIntoDatabase.class)
	public ModelAndView CustomerNotSaveIntoDatabase(CustomerNotSaveIntoDatabase u) {

		ModelAndView model = new ModelAndView("error/errorc");

		
		model.addObject("errmsgkey", u.getMessage());

		return model;

	} 
 
 
 /*
	 *@exception : if customer not found database with same customer id
	 * then it pass the exception customer not found
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	 *
	*/
 @ExceptionHandler(CustomerDetailsNotFoundException.class)
	public ModelAndView CustomerDetailsNotFoundException(CustomerDetailsNotFoundException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey1", u.getMessage());

		return model;

	} 
 
 
 /*
	 *@exception : if medicine not found from shop 
	 * then it pass the exception medicine not found exception
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	*/
 
 @ExceptionHandler(MedicineNotFoundException.class)
	public ModelAndView MedicineNotFoundException(MedicineNotFoundException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey2", u.getMessage());

		return model;

	} 
 
 
 
 /*
	 *@exception : if medicine nhave same id twice 
	 * then it pass the exception medicine already exist with same id
	 * @author : kishor nivalkar
	 * @since : 22 may 2019
	*/
 @ExceptionHandler(MedicineIdAlreadyExistException.class)
	public ModelAndView MedicineIdAlreadyExistException(MedicineIdAlreadyExistException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey3", u.getMessage());

		return model;

	} 
 
 
 
 @ExceptionHandler(ShopNotSaveIntoDatabase.class)
	public ModelAndView ShopNotSaveIntoDatabase(ShopNotSaveIntoDatabase u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey4", u.getMessage());

		return model;

	} 
 
 @ExceptionHandler(TradeDataNotGettingException.class)
	public ModelAndView TradeDataNotGettingException(TradeDataNotGettingException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey5", u.getMessage());

		return model;

	} 
 
 @ExceptionHandler(DateNotFoundException.class)
	public ModelAndView DateNotFoundException(DateNotFoundException u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey6", u.getMessage());

		return model;

	} 

 
 @ExceptionHandler( TradeNotSaveIntoDatabase.class)
	public ModelAndView  TradeNotSaveIntoDatabase( TradeNotSaveIntoDatabase u) {

		ModelAndView model = new ModelAndView("error/errorc");

		model.addObject("errmsgkey7", u.getMessage());

		return model;

	}
}
