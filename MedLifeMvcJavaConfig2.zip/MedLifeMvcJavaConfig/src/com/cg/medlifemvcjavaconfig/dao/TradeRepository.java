package com.cg.medlifemvcjavaconfig.dao;

import java.util.Date;

import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Trade;
import com.cg.medlifemvcjavaconfig.exceptions.DataNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.DateNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeDataNotGettingException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeNotSaveIntoDatabase;

public interface TradeRepository {

	public List<Trade> findByDate(Date date) throws DateNotFoundException;
	public List<Trade> findCustomerByDate(String custName, Date date) throws DataNotFoundException;
	public Trade saveTrade(Trade trade) throws TradeNotSaveIntoDatabase;
	public  List<Trade> showAll() throws TradeDataNotGettingException;
	public Trade updateTrade();
}