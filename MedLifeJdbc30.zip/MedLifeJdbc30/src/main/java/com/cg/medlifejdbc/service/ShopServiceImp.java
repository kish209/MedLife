package com.cg.medlifejdbc.service;

import java.util.List;


import com.cg.medlifejdbc.dao.ShopRepository;
import com.cg.medlifejdbc.dao.ShopRepositoryImp;
import com.cg.medlifejdbc.dto.Shop;
import com.cg.medlifejdbc.exceptions.MedicineNotFoundException;
import com.cg.medlifejdbc.exceptions.ShopNotSaveIntoDatabase;

public class ShopServiceImp implements ShopService{

	private ShopRepository shoprepository;
	public ShopServiceImp(){
		shoprepository= new ShopRepositoryImp();
	}

	public Shop addShop(Shop shop) throws ShopNotSaveIntoDatabase {

		return shoprepository.save(shop);
	}

	public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException {

		if(shoprepository.findByName(medicineName).isEmpty())
			throw new MedicineNotFoundException("Medicine not found");
		return shoprepository.findByName(medicineName);
	}
}