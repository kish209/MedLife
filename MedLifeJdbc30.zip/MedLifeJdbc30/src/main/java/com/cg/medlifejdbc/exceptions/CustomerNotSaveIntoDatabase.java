package com.cg.medlifejdbc.exceptions;

public class CustomerNotSaveIntoDatabase extends Exception {
	public CustomerNotSaveIntoDatabase()
	{
		
	}
	
	public CustomerNotSaveIntoDatabase(String exceptionMessage) {
		super(exceptionMessage);
	}
}
