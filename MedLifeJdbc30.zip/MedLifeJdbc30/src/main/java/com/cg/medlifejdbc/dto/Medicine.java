package com.cg.medlifejdbc.dto;


public class Medicine{

	private String medicineName;
	private String medicineType;
	private double medicinePrice;

	public Medicine(){
		this.medicineName=null;
		this.medicineType=null;
		this.medicinePrice=0;
	}
	public Medicine(String medicineName, String medicineType, double medicinePrice ){
		super();
		this.medicineName = medicineName;
		this.medicineType = medicineType;
		this.medicinePrice = medicinePrice;
	}
	
	public String toString() {
		return "Medicine Name=" + medicineName + ", Medicine Type=" + medicineType + ", Medicine Price="
				+ medicinePrice + "Rs";
	}

	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public String getMedicineType() {
		return medicineType;
	}
	public void setMedicineType(String medicineType) {
		this.medicineType = medicineType;
	}
	public double getMedicinePrice() {
		return medicinePrice;
	}
	public void setMedicinePrice(double medicinePrice) {
		this.medicinePrice = medicinePrice;
	}	
}