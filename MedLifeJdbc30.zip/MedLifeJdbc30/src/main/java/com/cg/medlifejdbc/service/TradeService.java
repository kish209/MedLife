package com.cg.medlifejdbc.service;

import java.util.Date;
import java.util.List;
import com.cg.medlifejdbc.dto.Trade;
import com.cg.medlifejdbc.exceptions.DataNotFoundException;
import com.cg.medlifejdbc.exceptions.DateNotFoundException;
import com.cg.medlifejdbc.exceptions.TradeDataNotGettingException;
import com.cg.medlifejdbc.exceptions.TradeNotSaveIntoDatabase;
public interface TradeService{
	public List <Trade> searchByDate(Date date) throws DateNotFoundException;
	public List <Trade> searchCustomerByDate(String custId, Date date) throws DateNotFoundException, DataNotFoundException;
	public List<Trade> showTrade() throws TradeDataNotGettingException;
	public Trade addTrade(Trade trade) throws TradeNotSaveIntoDatabase;
}
