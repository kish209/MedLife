package com.cg.medlifejdbc.dao;
import java.util.List;

import com.cg.medlifejdbc.dto.Shop;
import com.cg.medlifejdbc.exceptions.MedicineNotFoundException;
import com.cg.medlifejdbc.exceptions.ShopNotSaveIntoDatabase;

public interface ShopRepository {

	public Shop save(Shop shop) throws ShopNotSaveIntoDatabase;
	public List<Shop> findByName(String medicineName) throws MedicineNotFoundException;

}
