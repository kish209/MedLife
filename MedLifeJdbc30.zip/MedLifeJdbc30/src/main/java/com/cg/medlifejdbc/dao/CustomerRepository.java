package com.cg.medlifejdbc.dao;

import com.cg.medlifejdbc.dto.Customer;
import com.cg.medlifejdbc.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejdbc.exceptions.CustomerNotSaveIntoDatabase;



public interface CustomerRepository {

	public Customer save(Customer customer) throws CustomerNotSaveIntoDatabase;
	public Customer findById(String id) throws CustomerDetailsNotFoundException;
}
