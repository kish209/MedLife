package com.cg.medlifejdbc.ui;

import java.math.BigInteger;
import java.text.ParseException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.cg.medlifejdbc.dto.Customer;
import com.cg.medlifejdbc.dto.Medicine;
import com.cg.medlifejdbc.dto.Shop;
import com.cg.medlifejdbc.dto.Trade;
import com.cg.medlifejdbc.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejdbc.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifejdbc.exceptions.DataNotFoundException;
import com.cg.medlifejdbc.exceptions.DateNotFoundException;
import com.cg.medlifejdbc.exceptions.MedicineNotFoundException;
import com.cg.medlifejdbc.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifejdbc.exceptions.TradeDataNotGettingException;
import com.cg.medlifejdbc.exceptions.TradeNotSaveIntoDatabase;
import com.cg.medlifejdbc.service.CustomerService;
import com.cg.medlifejdbc.service.CustomerServiceImp;
import com.cg.medlifejdbc.service.ShopService;
import com.cg.medlifejdbc.service.ShopServiceImp;
import com.cg.medlifejdbc.service.TradeService;
import com.cg.medlifejdbc.service.TradeServiceImp;
import com.cg.medlifejdbc.dto.Address;
public class MedLife{

	public MedLife()
	{}

	public static void main(String[] args) throws ParseException 
	{
		CustomerService customerservice=new CustomerServiceImp();
		ShopService shopservice=new ShopServiceImp();
		TradeService tradeservice=new TradeServiceImp();

		Scanner scan = new Scanner(System.in);
		int choice = 0;
		int shopChoice=0;
		char ch='Y';
		int countOne=1 ; 

		do
		{
			printMenu();
			System.out.println("Enter Choice : ");
			choice =scan.nextInt();
			switch(choice)
			{
			
			//adding customer
			case 1:
				
				System.out.println("Enter customer Id : ");
				String customerId=scan.next();
				System.out.println("Enter customer Name : ");
				String custName=scan.next();
				System.out.println("Enter customer Contact : ");
				String contact=scan.next();
				System.out.println("Enter customer house number : ");
				String houseNo=scan.next();
				System.out.println("Enter customer area : ");
				String area=scan.next();
				System.out.println("Enter customer city : ");
				String city=scan.next();
				System.out.println("Enter customer pincode : ");
				Long pincode = scan.nextLong();
				
				Address add = new Address(houseNo,area,city,pincode);
				Customer customerOne = new Customer(customerId,custName, new BigInteger(contact),add);
				
				try {
					customerOne = customerservice.addCustomer(customerOne);
					System.out.println("Customer Added !  Your Id is "+customerOne.getCustId());
					
				} catch (CustomerNotSaveIntoDatabase e3) {
					System.out.println(e3.getMessage());
				}
					
				break;
				
				//adding shop
			case 2:

				System.out.println("Enter Shop Id: ");
				int shopId=scan.nextInt();
				System.out.println("Enter shop Name : ");
				String shopName=scan.next();
				System.out.println("Enter shop house number : ");
				String shopHouseNo=scan.next();
				System.out.println("Enter Shop area : ");
				String shopArea=scan.next();
				System.out.println("Enter Shop city : ");
				String shopCity=scan.next();
				System.out.println("Enter Shop pincode : ");
				Long shopPincode = scan.nextLong();
				System.out.println();
				Medicine medicineNew;
				List<Medicine> medicines = new ArrayList<Medicine>();
				do {
					System.out.println("Enter Medicine Name: ");
					String medicineName = scan.next();
					System.out.println("Enter Medicine Type: ");
					String medicineType = scan.next();
					System.out.println("Enter Medicine Price: ");
					double medicinePrice = scan.nextDouble();
					
					medicineNew = new Medicine (medicineName, medicineType, medicinePrice);
					medicines.add(medicineNew);
					System.out.println("Add new medicine ? y/n");
					ch=scan.next().charAt(0);
					System.out.println();
				}while(ch=='Y'||ch=='y');
				Address addr = new Address(shopHouseNo,shopArea,shopCity,shopPincode);
				Shop shopData = new Shop(shopId, shopName, addr, medicines);
				
				try {
					shopData = shopservice.addShop(shopData);
					System.out.println("Shop Added !  shop name is "+shopData.getShopName());
				} catch (ShopNotSaveIntoDatabase e2) {
					System.out.println(e2.getMessage());
				}
					
			
				break;

				
				
				//searching medicine from database
			case 3:

				double totalPrice=0.0;
				List <Medicine> med= new ArrayList<Medicine>();
				Shop shopOne=null;

				SimpleDateFormat formatDate=  new SimpleDateFormat("dd-MM-yyyy");
				String strDate= formatDate.format(new Date());
				Date currentDate= formatDate.parse(strDate);

				System.out.println("Enter Customer ID: ");
				String custId=scan.next();
				Customer customer;
				try {
					customer = customerservice.searchById(custId);
					try {
						do {
							shopChoice=0;
							System.out.println("Enter Medicine name : ");
							String medicineNameOne = scan.next();
							int count=0;
							List<Shop> shops;

							shops = shopservice.searchByMedicine(medicineNameOne);
							System.out.println("\n**********************************");
							if(shopChoice==0) 
							{
								for(Shop shoplist : shops)
								{	
									count++;			
									System.out.print(count+".\nShop ID: "+shoplist.getShopId()+"\nShop Name: "+shoplist.getShopName()+"\nShop Address: "+shoplist.getAddress());
									for(Medicine medRef:shoplist.getMedicines())
									{
										if(medRef.getMedicineName().equalsIgnoreCase(medicineNameOne))
											System.out.print("\nMedicine Name: "+medRef.getMedicineName()+"\nMedicine Price: "+medRef.getMedicinePrice()+"Rs"+"\nMedicine Type: "+medRef.getMedicineType());
										System.out.println();
									}
								}
								System.out.println("\n**********************************\n");

								System.out.println("Select shop: ");
								shopChoice=scan.nextInt();
							}

							Medicine myMed= new Medicine();
							for(int i=0;i<count;i++)
							{
								if(i==shopChoice-1)
								{

									System.out.println(shopOne=shops.get(i));

									for (Medicine medicine : shopOne.getMedicines()) 
									{
										if(medicine.getMedicineName().toLowerCase().equals(medicineNameOne.toLowerCase()))
											myMed=medicine;

									}

									break;
								}
							}

							med.add(myMed);
				
							totalPrice+=myMed.getMedicinePrice();
							System.out.println(shopChoice);
							System.out.println("Buy more medicines? (Y/N): ");
							ch=scan.next().charAt(0);
							System.out.println();
						} while(ch=='Y'||ch=='y');

						System.out.println("\n**********************************");
						Trade trade=new Trade(countOne, totalPrice, currentDate, customer, shopOne, med);
						tradeservice.addTrade(trade);
						try {
							tradeservice.showTrade();
							System.out.println("\n");
							countOne++;
							System.out.println("**********************************\n");
						} catch (TradeDataNotGettingException e) {
							System.out.println(e.getMessage());
						}
						
					}
					catch (MedicineNotFoundException e) {
						System.out.println(e.getMessage());

					} catch (TradeNotSaveIntoDatabase e) {
						System.out.println(e.getMessage());
					}
				}
				catch (CustomerDetailsNotFoundException e1) {
					System.out.println(e1.getMessage());
				}

				break;


			case 4:

				System.out.println("Enter Date : ");							
				String dateOne = scan.next();

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

				Date givendate;
				try {		
					givendate = dateFormat.parse(dateOne);
					List<Trade> tradeList = tradeservice.searchByDate(givendate);
				
						for(Trade trade:tradeList)
						{
							System.out.println();
						  System.out.println("Trade Id -> "+trade.getId());
						  System.out.println("Total Price -> "+trade.getTotalPrice());
						  System.out.println("Date -> "+trade.getDate());
						  System.out.println("Customer Id -> "+trade.getCustomer().getCustId());
						  System.out.println("Shop Id -> "+trade.getShop().getShopId());
						  System.out.println();
						
					}

				} catch (DateNotFoundException e) {

					System.out.println(e.getMessage());	
				}

				break;


			case 5:

				System.out.println("Enter Customer Id : ");
				String custIdOne = scan.next();

				System.out.println("Enter Date : ");
				String dateOneOne = scan.next();


				SimpleDateFormat dateFormatOne = new SimpleDateFormat("dd-MM-yyyy");

				Date givendateOne;
				try {

					givendateOne = dateFormatOne.parse(dateOneOne);
					List<Trade> tradeListOne;
					try {
						tradeListOne = tradeservice.searchCustomerByDate(custIdOne, givendateOne);
						for(Trade tradeOne:tradeListOne)
						{
							System.out.println();
						  System.out.println("Trade Id -> "+tradeOne.getId());
						  System.out.println("Total Price -> "+tradeOne.getTotalPrice());
						  System.out.println("Date -> "+tradeOne.getDate());
						  System.out.println("Customer Id -> "+tradeOne.getCustomer().getCustId());
						  System.out.println("Shop Id -> "+tradeOne.getShop().getShopId());
						  System.out.println();
						
					}
					} catch (DataNotFoundException e) {
						System.out.println(e.getMessage());
					}

					

				} catch (DateNotFoundException e) {

					System.out.println(e.getMessage());

				}

				break;


			case 6:

				System.exit(choice);
				break;


			default :
				System.out.println("Wrong choice ..!");
				break;
			}


		}while(choice!=6);
		scan.close();
	}
	
	
	private static void printMenu() 
	{
		System.out.println("\n\n\n**********************************");
		System.out.println("**********************************\n");
		System.out.println("    **************");
		System.out.println("    *  MedLife   *");
		System.out.println("    **************\n");
		System.out.println("1. Add new customer ");
		System.out.println("2. Add new shop ");
		System.out.println("3. Search Medicines from shops");
		System.out.println("4. Search Transaction By date");
		System.out.println("5. Search Customer Transaction By Date");
		System.out.println("6. Exit\n");
		System.out.println("**********************************");
		System.out.println("**********************************\n");

	}
}