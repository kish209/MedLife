package com.cg.medlifejdbc.dao;
import java.util.Date;
import java.util.List;

import com.cg.medlifejdbc.dto.Trade;
import com.cg.medlifejdbc.exceptions.DataNotFoundException;
import com.cg.medlifejdbc.exceptions.DateNotFoundException;
import com.cg.medlifejdbc.exceptions.TradeDataNotGettingException;
import com.cg.medlifejdbc.exceptions.TradeNotSaveIntoDatabase;

public interface TradeRepository {

	public List<Trade> findByDate(Date date) throws DateNotFoundException;
	public List<Trade> findCustomerByDate(String custName, Date date) throws DataNotFoundException;
	public Trade saveTrade(Trade trade) throws TradeNotSaveIntoDatabase;
	public  List<Trade> showAll() throws TradeDataNotGettingException;
}