package com.cg.medlifejdbc.dto;

import java.util.Date;
import java.util.List;

public class Trade {

	private int id;
	private double totalPrice;
	private Date date;
	private Customer customer;
	private Shop shop;
	private List <Medicine> medicines;

	public Trade(int id, double totalPrice, Date date, Customer customer, Shop shop, List<Medicine> medicines) {
		super();
		this.id = id;
		this.totalPrice = totalPrice;
		this.date = date;
		this.customer = customer;
		this.shop = shop;
		this.medicines = medicines;
	}
	public Trade() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Shop getShop() {
		return shop;
	}
	public void setShop(Shop shop) {
		this.shop = shop;
	}
	public List<Medicine> getMedicines() {
		return medicines;
	}
	public void setMedicines(List<Medicine> medicines) {
		this.medicines = medicines;
	}
	@Override
	public String toString() {
		return "Trade [id=" + id + ", totalPrice=" + totalPrice + ", date=" + date + ", customer=" + customer
				+ ", shop=" + shop + ", medicines=" + medicines + "]";
	}

	/*public String toString() {
		return "\nTrade Id => " + id + ",\nTotal Price => " + totalPrice + "Rs"+",\nDate => " + date + ",\nCustomer => " + customer
				+ ",\nShop => " + shop.getShopName()+" "+shop.getAddress() + ",\nMedicines => " + medicines + "\n";
	}*/
	
}
