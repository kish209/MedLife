package com.cg.medlifejdbc.exceptions;

public class TradeDataNotGettingException extends Exception {
	public TradeDataNotGettingException()
	{
		
	}
	
	public TradeDataNotGettingException(String exceptionMessage)
	{
		super(exceptionMessage);
		
	}

}
