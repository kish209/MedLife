package com.cg.testseriesapplicationspringmvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.exception.AssignerException;
import com.cg.testseriesapplicationspringmvc.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationspringmvc.exception.TestAssignedException;
import com.cg.testseriesapplicationspringmvc.exception.TestNotFoundException;

/*
 * This class implements the test assigner repository interface
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav 
 */
@Repository("AssignerRepository")
public class TestAssignerRepositoryImp implements TestAssignerRepository {

	@PersistenceContext
	EntityManager em;
	
/*saves the assigner  @param: assigner
	 * @return: assigner
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Assigner save(Assigner assigner) {
		// TODO Auto-generated method stub
		Test test;
		Candidate cand;
		//Assigner assign;
	  //Assigner assign=null;
		try {
	     test=em.find(Test.class, assigner.getTest().getId());
	     cand=em.find(Candidate.class, assigner.getCandidate().getId());
	    //assign=em.find(Assigner.class, assigner.getCandidate().getId() );
	      if(test==null) {
	    	  throw new TestNotFoundException("Test with this Id not created..!!");
	      }
		
		 
		 if(cand==null) {
			 throw new CandidateNotFoundException("Candidate with this Id not found..!!!");
		 }
		 
		
		  if(test!=null && cand!=null)
		    {
			em.persist(assigner);
			em.flush();}
	        }
		  
		finally {
			if(em!=null)
				em.close();
		    }
		return assigner;
}
}