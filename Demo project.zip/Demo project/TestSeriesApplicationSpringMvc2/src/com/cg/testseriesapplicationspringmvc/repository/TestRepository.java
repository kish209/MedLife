package com.cg.testseriesapplicationspringmvc.repository;
import com.cg.testseriesapplicationspringmvc.dto.Test;

/*
 * This is a test repository interface it includes save test and find by name methods
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav 
 * */
public interface TestRepository {
	public Test saveTest(Test test);//saves test
	public Test findByName(String testName);//finds test
	public Test findById(int id);//finds test
	
}
