package com.cg.testseriesapplicationspringmvc.exception;

public class AssignerException extends RuntimeException {

	public AssignerException() {
		// TODO Auto-generated constructor stub
	}

	public AssignerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
