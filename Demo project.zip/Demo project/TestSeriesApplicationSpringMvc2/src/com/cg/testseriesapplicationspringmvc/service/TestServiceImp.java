package com.cg.testseriesapplicationspringmvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesapplicationspringmvc.dto.Question;
import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.exception.TestNotFoundException;
import com.cg.testseriesapplicationspringmvc.repository.TestRepository;

/*This class is implementation of test service interface which implements create test ,search test 
 * by name  methods..!
 * last Modified 15/05/2019 Author:Tanaya Jadhav 
*/
@Transactional
@Service
public class TestServiceImp implements TestService{

	@Autowired
	TestRepository dao;
	static int questionId=1;
/*creates test
	 * @param: Test
	 * @return: test
	 last Modified 15/05/2019  Author:Tanaya Jadhav
*/
	public Test createMyTest(Test test) {
		// TODO Auto-generated method stub
		for(Question que : test.getQuestions()) {
		    que.setId(questionId);
			questionId++;
		}
		return dao.saveTest(test);
	}

/*searches test by name
	 * @param: testname
	 * @return: test with that name 
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Test searchTestByName(String testName) {
		// TODO Auto-generated method stub
		
		Test t=dao.findByName(testName);
		if(t==null)
		{
			throw new TestNotFoundException("Test not created");
		}
		return t;
	}

/*searches test by name
	 * @param: testname
	 * @return: test with that name 
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Test searchTestById(int id) {
		// TODO Auto-generated method stub
		Test t=dao.findById(id);
		if(t==null) {
			throw new TestNotFoundException("Test not created..!!");
		}
		return t;
	}

}
