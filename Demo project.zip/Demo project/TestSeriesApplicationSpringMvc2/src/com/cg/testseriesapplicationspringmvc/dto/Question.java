package com.cg.testseriesapplicationspringmvc.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
/*
 * This is bean class for Question it includes int number, String content ,String optionA ,
 * String optionB, String optionC,String correct option
 * Constructor,getter setter ,toString is defined
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */
@Entity
@Table(name="Question")
public class Question {
	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	private Integer id;//primary key
	@Column(name="Content")
	private String content;
	@Column(name="optionA")
	private String optionA;
	@Column(name="optionB")
	private String optionB;
	@Column(name="optionC")
	private String optionC;
	@Column(name="correct_option")
	private String correctOption;
	@ManyToOne
	@JoinColumn(name="test_Id")
	private Test test;
	public Question() {}

	public Question(Integer id, String content, String optionA, String optionB, String optionC, String correctOption,
			Test test) {
		super();
		this.id = id;
		this.content = content;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.correctOption = correctOption;
		this.test = test;
	}

	public Test getTest() {
		return test;
	}

	public void setTest(Test test) {
		this.test = test;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getOptionA() {
		return optionA;
	}

	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	public String getOptionB() {
		return optionB;
	}

	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	public String getOptionC() {
		return optionC;
	}

	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	public String getCorrectOption() {
		return correctOption;
	}

	public void setCorrectOption(String correctOption) {
		this.correctOption = correctOption;
	}



	@Override
	public String toString() {
		return "Question [id=" + id + ", content=" + content + ", optionA=" + optionA + ", optionB=" + optionB
				+ ", optionC=" + optionC + ", correctOption=" + correctOption + ", test=" + test + "]";
	}

	
	
	
	
	
	
}
