package com.cg.testseriesapplicationspringmvc.dto;

import java.sql.Timestamp;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/*
 * This a Assigner bean class with the attributes as date,test(Object of class Test),candidate(Object of
 *  class candidate).
 * Parameterized constructor , getter setters and toString methods..!
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */

@Entity
@Table(name="Assigner")
public class Assigner {

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	    private Integer id;//primary key
	@Column(name="Date")
	    private	Timestamp date;
	@OneToOne
	@JoinColumn(name="test_id")
		private Test test;
	@OneToOne
	@JoinColumn(name="candidate_id")
		private Candidate candidate;
		
		public Assigner() {
			// TODO Auto-generated constructor stub
		}


		public Assigner(Integer id, Timestamp date, Test test, Candidate candidate) {
			super();
			this.id = id;
			this.date = date;
			this.test = test;
			this.candidate = candidate;
		}

	



		public Integer getId() {
			return id;
		}


		public void setId(Integer id) {
			this.id = id;
		}


		public Timestamp getDate() {
			return date;
		}


		public void setDate(Timestamp date) {
			this.date = date;
		}


		public Test getTest() {
			return test;
		}


		public void setTest(Test test) {
			this.test = test;
		}


		public Candidate getCandidate() {
			return candidate;
		}


		public void setCandidate(Candidate candidate) {
			this.candidate = candidate;
		}


		@Override
		public String toString() {
			return "Assigner [id=" + id + ", date=" + date + ", test=" + test + ", candidate=" + candidate + "]";
		}


		

		
		
		
}
