package com.cg.medlifejpa.dao;
import java.sql.Connection;


import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.dto.Medicine;
import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.dto.Trade;
import com.cg.medlifejpa.exceptions.DataNotFoundException;
import com.cg.medlifejpa.exceptions.DateNotFoundException;
import com.cg.medlifejpa.exceptions.TradeDataNotGettingException;
import com.cg.medlifejpa.exceptions.TradeNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;

import javassist.expr.NewArray;
public class TradeRepositoryImp implements TradeRepository{


	EntityManager em;
	
	//saving transaction into database
	
	public Trade saveTrade(Trade trade) throws TradeNotSaveIntoDatabase {
		System.out.println(trade);
	
		em=DBUtil.em;
		em.getTransaction().begin();
		//System.out.println("before");
		
		em.persist(trade);
	
		
		
		//TypedQuery<Medicine> queryOne = em.createQuery("update Medicine SET id=? where medicineName=?",Medicine.class);
		
		TypedQuery<Trade> query = em.createQuery("select c id from trade c  where c.id=:?",Trade.class);
		query.setParameter(1, trade.getId());
		trade=query.getSingleResult();
	
		
		TypedQuery<Medicine> queryOne = em.createQuery("update Medicine c SET c.id=:? where c.medicineName=:?",Medicine.class);
		
		for (Medicine medicine : trade.getMedicines()) {
			queryOne.setParameter(1, medicine.getTrade().getId());
			queryOne.setParameter(2, medicine.getMedicineName());
			queryOne.setParameter(3, medicine.getShop().getShopId());
			queryOne.executeUpdate();
		}
		
		em.getTransaction().commit();
		return  trade;

	}


	//showing transaction
	
	public List<Trade> showAll() throws TradeDataNotGettingException 
	{
		List<Trade> tradeList = new ArrayList<Trade>();
		
		TypedQuery<Trade> query = em.createQuery("select c from Trade c",Trade.class);
		
		tradeList=query.getResultList();
		
		return tradeList;
		
	}
	private static java.sql.Date convertUtilToSql(java.util.Date uDate) {
		java.sql.Date sDate = new java.sql.Date(uDate.getTime());
		return sDate;
	}


	//finding transaction by input date
	
	public List<Trade> findByDate(java.util.Date date) throws DateNotFoundException
	{
		List<Trade> tradeList = new ArrayList<Trade>();
		
		Customer customer = new  Customer();
		TypedQuery<Trade> query = em.createQuery("select c from Customer where date=:?", Trade.class);
		query.setParameter(1, id);
		customer=query.getSingleResult();
		
		return tradeList;
	}


	//finding transaction by input date and customer
	
	public List<Trade> findCustomerByDate(String custName, java.util.Date date) throws DataNotFoundException
	{
		//Connection connection = DBUtil.getConnection();
		String query;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		List<Trade> tradeList=null;
		
		try
		{
	
		query="select * from trade where trade_date =? and cust_id_f=?";
		Date dateMy = convertUtilToSql(date);
		tradeList= new ArrayList<Trade>();
		//pstmt=connection.prepareStatement(query);
		pstmt.setDate(1,dateMy);
		pstmt.setString(2,custName);
		rs= pstmt.executeQuery();
		
		while(rs.next())
		{
			
		Trade trade = new Trade();
		Customer custOne=new Customer();
		Shop shopOne=new Shop();
	
		trade.setId(rs.getInt("trade_id"));
		trade.setTotalPrice(rs.getDouble("total_price"));
		trade.setDate(rs.getDate("trade_date"));
		custOne.setCustId(rs.getString("cust_id_f"));
		shopOne.setShopId(rs.getInt("shop_id_f"));
		trade.setCustomer(custOne);
		trade.setShop(shopOne);
		tradeList.add(trade);
		}
		
		}
		
		catch(SQLException e)
		{
			throw new DataNotFoundException("Data not found");
			
		}
		
		return tradeList;
	}

}