package com.cg.medlifejpa.service;

import java.util.List;

import com.cg.medlifejpa.dao.ShopRepository;
import com.cg.medlifejpa.dao.ShopRepositoryImp;
import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.exceptions.MedicineNotFoundException;
import com.cg.medlifejpa.exceptions.ShopNotSaveIntoDatabase;

public class ShopServiceImp implements ShopService{

	//static int countShop=100;
//	static int countAddress=200;
	private ShopRepository shoprepository;
	
	public ShopServiceImp(){
		shoprepository= new ShopRepositoryImp();
	}

	public Shop addShop(Shop shop) throws ShopNotSaveIntoDatabase {

		//shop.setShopId(countShop);
		//countShop++;
		
		//shop.getAddress().setAddressId(countAddress);
		//countAddress++;
		return shoprepository.save(shop);
	}

	public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException {

		if(shoprepository.findByName(medicineName).isEmpty())
			throw new MedicineNotFoundException("Medicine not found");
		return shoprepository.findByName(medicineName);
	}
}