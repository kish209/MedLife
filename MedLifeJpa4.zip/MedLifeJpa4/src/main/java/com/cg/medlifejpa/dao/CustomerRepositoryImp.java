package com.cg.medlifejpa.dao;
import java.sql.Connection;



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.medlifejpa.dto.Address;
import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejpa.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;
public class CustomerRepositoryImp implements CustomerRepository 
{
	EntityManager em;

	public CustomerRepositoryImp() {
		// TODO Auto-generated constructor stub
		em=DBUtil.em;
	}


	// saving customer into database

	public Customer save(Customer customer) throws CustomerNotSaveIntoDatabase {
		//System.out.println("begin "+customer);
		//Query query = em.createQuery(" update Address ");
		
		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
		return customer;
		
	}


	
	//finding customer Id
	
	public Customer findById(String id) throws CustomerDetailsNotFoundException
	{
		Customer customer = new  Customer();
		TypedQuery<Customer> query = em.createQuery("select c from Customer c where c.custId=? ", Customer.class);
		query.setParameter(1, id);
		customer=query.getSingleResult();
		return customer;
		
	}	
	
}