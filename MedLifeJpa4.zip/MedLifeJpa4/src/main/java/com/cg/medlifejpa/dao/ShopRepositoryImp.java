package com.cg.medlifejpa.dao;
import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.medlifejpa.dto.Address;
import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.dto.Medicine;
import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.exceptions.MedicineNotFoundException;
import com.cg.medlifejpa.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;

public class ShopRepositoryImp implements ShopRepository{

	List<Medicine> medicineData;
	
	EntityManager em;
	Medicine medicine;
	public ShopRepositoryImp()
	{
		em=DBUtil.em;
		medicineData = new ArrayList<Medicine>();
	}

	
	//saving shop into database
	
	public Shop save(Shop shop) throws ShopNotSaveIntoDatabase {
		
		em.getTransaction().begin();
		em.persist(shop);
		em.getTransaction().commit();
		return  shop;
	}

	
	//finding medicine name
	
	public List<Shop> findByName(String medicineNameOne) throws MedicineNotFoundException {

		List <Medicine> medicineList = new ArrayList<Medicine>();

		List <Shop> shopListOne = new ArrayList<Shop>();
		List <Shop> shopList = new ArrayList<Shop>();

		TypedQuery<Shop> query = em.createQuery("select c from Shop c", Shop.class);
		shopList = query.getResultList();
		
		for (Shop shop : shopList) {
			medicineList=shop.getMedicines();
			for (Medicine medicineOne : medicineList) {
				if(medicineNameOne.equals(medicineOne.getMedicineName())) {
					shopListOne.add(shop);
					
				}
			}
		}
		
		
		return shopListOne;
	}
}