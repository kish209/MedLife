package com.cg.medlifejpa.exceptions;

public class DataNotFoundException extends Exception {
	public DataNotFoundException()
	{}
	public DataNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}
