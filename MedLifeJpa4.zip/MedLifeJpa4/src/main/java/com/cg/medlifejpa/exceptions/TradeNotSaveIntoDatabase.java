package com.cg.medlifejpa.exceptions;

public class TradeNotSaveIntoDatabase extends Exception {
	
	public TradeNotSaveIntoDatabase()
	{
		
	}
	
	public TradeNotSaveIntoDatabase(String exceptionMessage)
	{
		super(exceptionMessage);
		
	}

}
