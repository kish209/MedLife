package com.cg.medlifespringcore.exceptions;

public class TradeNoSaveException extends Exception {
	public TradeNoSaveException()
	{
		
	}
	public TradeNoSaveException(String msg)
	{
		super(msg);
	}

}
