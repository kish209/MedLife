package com.cg.medlifespringcore.service;
import java.util.Date;

import java.util.List;
import com.cg.medlifespringcore.dto.Trade;
import com.cg.medlifespringcore.exceptions.DateNotFoundException;
import com.cg.medlifespringcore.exceptions.TradeNoSaveException;
import com.cg.medlifespringcore.exceptions.TradeNotShowingException;
public interface TradeService{
	public List <Trade> searchByDate(Date date) throws DateNotFoundException;
	public List <Trade> searchCustomerByDate(String custId, Date date) throws DateNotFoundException;
	public List<Trade> showTrade() throws TradeNotShowingException;
	public Trade addTrade(Trade trade) throws TradeNoSaveException;
}
