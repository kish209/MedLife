package com.cg.medlifespringcore.ui;

import java.math.BigInteger;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.medlifespringcore.dto.Customer;
import com.cg.medlifespringcore.dto.Medicine;
import com.cg.medlifespringcore.dto.Shop;
import com.cg.medlifespringcore.dto.Trade;
import com.cg.medlifespringcore.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifespringcore.exceptions.DateNotFoundException;
import com.cg.medlifespringcore.exceptions.MedicineNotFoundException;
import com.cg.medlifespringcore.service.CustomerService;
import com.cg.medlifespringcore.service.ShopService;
import com.cg.medlifespringcore.service.TradeService;
import com.cg.medlifespringcore.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifespringcore.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifespringcore.exceptions.TradeNoSaveException;
import com.cg.medlifespringcore.exceptions.TradeNotShowingException;
import com.cg.medlifespringcore.config.JavaConfig;
import com.cg.medlifespringcore.dto.Address;

@Component
public class MedLife{


	static CustomerService customerservice;
	static ShopService shopservice;
	static TradeService tradeservice;
	

	public MedLife()
	{}

	public static void main(String[] args) throws ParseException 
	{
		
		AnnotationConfigApplicationContext app= new AnnotationConfigApplicationContext(JavaConfig.class);

		customerservice= (CustomerService) app.getBean("customerService");
		shopservice= (ShopService) app.getBean("shopService");
		tradeservice=(TradeService) app.getBean("tradeService");

		Scanner scan = new Scanner(System.in);
		int choice = 0;
		int shopChoice=0;
		char ch='Y';
		int countOne =1; 

		do
		{
			printMenu();
			System.out.println("Enter Choice : ");
			choice =scan.nextInt();
			switch(choice)
			{
			
			case 1:

				/*Customer customerOne = new Customer("cust1","kishor",new BigInteger("8805072549"),new Address("11","Talwade","Pune",411062));
				Customer customerTwo = new Customer("cust2","manthan",new BigInteger("7020231164"),new Address("12","Akurdi","Pune",411044));
				Customer customerThree = new Customer("cust3","pradip",new BigInteger("1234567890"),new Address("12","Aalandi","Pune",411042));

				customerOne=customerservice.addCustomer(customerOne);
				customerTwo=customerservice.addCustomer(customerTwo);
				customerThree=customerservice.addCustomer(customerThree);
				
			
				System.out.println(customerOne.getCustName()+" , "+customerTwo.getCustName()+" , "+customerThree.getCustName()+" Customers are added successfully.. \n");
*/

				System.out.println("Enter customer Id : ");
				String customerId=scan.next();
				System.out.println("Enter customer Name : ");
				String custName=scan.next();
				System.out.println("Enter customer Contact : ");
				BigInteger contact=scan.nextBigInteger();
				System.out.println("Enter customer house number : ");
				String houseNumber=scan.next();
				System.out.println("Enter customer area : ");
				String area=scan.next();
				System.out.println("Enter customer city : ");
				String city=scan.next();
				System.out.println("Enter customer pincode : ");
				Long pincode = scan.nextLong();

				//Address add = new Address(houseNumber,area,city,pincode);
				Address add = (Address) app.getBean("address");
				add.setHouseNumber(houseNumber);
				add.setArea(area);
				add.setCity(city);
				add.setPincode(pincode);
				
				//Customer customerOne = new Customer(customerId,custName, new BigInteger(contact),add);
				Customer customerOne = (Customer) app.getBean("customer");
				customerOne.setCustId(customerId);
				customerOne.setCustName(custName);
				customerOne.setContact(contact);
				customerOne.setAddress(add);


				
				try {
					customerOne = customerservice.addCustomer(customerOne);
					System.out.println("Customer Added !  Your Id is "+customerOne.getCustId());

				} catch (CustomerNotSaveIntoDatabase e3) {
					System.out.println(e3.getMessage());
				}

			break;
			
			case 2:
/*
				List <Medicine> medicinesOne = new ArrayList<Medicine>();

				Medicine medicinesOneOne = new Medicine("Crocin","Tablet",5.00);
				Medicine medicinesOneTwo = new Medicine("TiscofD","Syrup",50.00);
				Medicine medicinesOneThree = new Medicine("Omi","Tablet",6.00);
				Medicine medicinesOneFour = new Medicine("paracetamol","Tablet",10.00);
				Medicine medicinesOneFive = new Medicine("Crocin","Tablet",5.00);
				Medicine medicinesOneSix = new Medicine("Crocin","Tablet",5.00);
				Medicine medicinesOneSeven = new Medicine("Crocin","Tablet",5.00);

				medicinesOne.add(medicinesOneOne);
				medicinesOne.add(medicinesOneTwo);
				medicinesOne.add(medicinesOneThree);
				medicinesOne.add(medicinesOneFour);
				medicinesOne.add(medicinesOneFive);
				medicinesOne.add(medicinesOneSix);
				medicinesOne.add(medicinesOneSeven);
				

				List <Medicine> medicinesTwo = new ArrayList<Medicine>();

				Medicine medicinesTwoOne = new Medicine("Crocin","Tablet",5.00);
				Medicine medicinesTwoTwo = new Medicine("Omi","Tablet",6.00);
				Medicine medicinesTwoThree = new Medicine("paracetamol","Tablet",10.00);
				Medicine medicinesOnefour = new Medicine("combiflam","Tablet",12.00);
				Medicine medicinesOnefive = new Medicine("a","etc",21.00);
				Medicine medicinesOnesix = new Medicine("b","etc",22.00);

				medicinesTwo.add(medicinesTwoOne);
				medicinesTwo.add(medicinesTwoTwo);
				medicinesTwo.add(medicinesTwoThree);
				medicinesTwo.add(medicinesOnefour);
				medicinesTwo.add(medicinesOnefive);
				medicinesTwo.add(medicinesOnesix);
				
				
				List <Medicine> medicinesThree = new ArrayList<Medicine>();

				Medicine medicinesThreeOne = new Medicine("Crocin","Tablet",5.00);
				Medicine medicinesThreeTwo = new Medicine("Omi","Tablet",6.00);
				Medicine medicinesThreeThree = new Medicine("paracetamol","Tablet",10.00);
				Medicine medicinesThreeFour = new Medicine("a","etc",21.00);
				Medicine medicinesThreeFive = new Medicine("b","etc",22.00);
				Medicine medicinesThreeSix = new Medicine("c","etc",23.00);
				Medicine medicinesThreeSeven = new Medicine("d","etc",24.00);

				medicinesThree.add(medicinesThreeOne);
				medicinesThree.add(medicinesThreeTwo);
				medicinesThree.add(medicinesThreeThree);
				medicinesThree.add(medicinesThreeFour);
				medicinesThree.add(medicinesThreeFive);
				medicinesThree.add(medicinesThreeSix);
				medicinesThree.add(medicinesThreeSeven);


				Shop shop1 = new Shop(1,"Mauli",new Address("101","Talwade","Pune",411062),medicinesOne);
				Shop shop2 = new Shop(2,"Om",new Address("102","Nigdi","Pune",411044),medicinesTwo);
				Shop shop3 = new Shop(2,"Health",new Address("103","pimpri","Pune",411033),medicinesThree);

				shop1 = shopservice.addShop(shop1);
				shop2 = shopservice.addShop(shop2);
				shop3 = shopservice.addShop(shop3);
				System.out.println(shop1.getShopName()+" , "+shop2.getShopName()+" , "+shop3.getShopName()+" Shops are added successfully.. \n");*/

				System.out.println("Enter Shop Id: ");
				int shopId=scan.nextInt();
				System.out.println("Enter shop Name : ");
				String shopName=scan.next();
				System.out.println("Enter shop house number : ");
				String shopHouseNo=scan.next();
				System.out.println("Enter Shop area : ");
				String shopArea=scan.next();
				System.out.println("Enter Shop city : ");
				String shopCity=scan.next();
				System.out.println("Enter Shop pincode : ");
				Long shopPincode = scan.nextLong();
				System.out.println();
				//Medicine medicineNew;
				List<Medicine> medicines = new ArrayList<Medicine>();
				do {
					System.out.println("Enter Medicine Name: ");
					String medicineName = scan.next();
					System.out.println("Enter Medicine Type: ");
					String medicineType = scan.next();
					System.out.println("Enter Medicine Price: ");
					double medicinePrice = scan.nextDouble();


					//medicineNew = new Medicine (medicineName, medicineType, medicinePrice);
					
					Medicine medicineNew = (Medicine) app.getBean("medicine");
					medicineNew.setMedicineName(medicineName);
					medicineNew.setMedicineType(medicineType);
					medicineNew.setMedicinePrice(medicinePrice);
					
					medicines.add(medicineNew);
					System.out.println("Add new medicine ? y/n");
					ch=scan.next().charAt(0);
					System.out.println();
				}while(ch=='Y'||ch=='y');
				
				
				//Address addr = new Address(shopHouseNo,shopArea,shopCity,shopPincode);
				
				Address addr = (Address) app.getBean("address");
				addr.setHouseNumber(shopHouseNo);
				addr.setArea(shopArea);
				addr.setCity(shopCity);
				addr.setPincode(shopPincode);
				
				//Shop shopData = new Shop(shopId, shopName, addr, medicines);
				Shop shopData = (Shop) app.getBean("shop");
				shopData.setShopId(shopId);
				shopData.setShopName(shopName);
				shopData.setAddress(addr);
				shopData.setMedicines(medicines);
				

				try {
					shopData = shopservice.addShop(shopData);
				} catch (ShopNotSaveIntoDatabase e2) {
					System.out.println(e2.getMessage());
				}
				System.out.println("Shop Added !  shop name is "+shopData.getShopName());

				
				break;

			case 3:

				double totalPrice=0.0;
				List <Medicine> med= new ArrayList<Medicine>();
				Shop shopOne=null;

				SimpleDateFormat formatDate=  new SimpleDateFormat("dd-MM-yyyy");
				String strDate= formatDate.format(new Date());
				Date currentDate= formatDate.parse(strDate);

				System.out.println("Enter Customer ID: ");
				String custId=scan.next();
				Customer customer;
				try {
					customer = customerservice.searchById(custId);
					try {
						do {
							shopChoice=0;
							System.out.println("Enter Medicine name : ");
							String medicineNameOne = scan.next();
							int count=0;
							List<Shop> shops;

							shops = shopservice.searchByMedicine(medicineNameOne);
							System.out.println("\n**********************************");
							if(shopChoice==0) 
							{
								for(Shop shoplist : shops)
								{	
									count++;			
									System.out.print(count+".\nShop ID: "+shoplist.getShopId()+"\nShop Name: "+shoplist.getShopName()+"\nShop Address: "+shoplist.getAddress());
									for(Medicine medRef:shoplist.getMedicines())
									{
										if(medRef.getMedicineName().equalsIgnoreCase(medicineNameOne))
											System.out.print("\nMedicine Name: "+medRef.getMedicineName()+"\nMedicine Price: "+medRef.getMedicinePrice()+"Rs"+"\nMedicine Type: "+medRef.getMedicineType());
										System.out.println();
									}
								}
								System.out.println("**********************************\n");

								System.out.println("Select shop: ");
								shopChoice=scan.nextInt();
							}

							//Medicine myMed= new Medicine();
							Medicine myMed= (Medicine) app.getBean("medicine");
							for(int i=0;i<count;i++)
							{
								if(i==shopChoice-1)
								{

									System.out.println(shopOne=shops.get(i));

									for (Medicine medicine : shopOne.getMedicines()) 
									{
										if(medicine.getMedicineName().toLowerCase().equals(medicineNameOne.toLowerCase()))
											myMed=medicine;

									}

									break;
								}
							}

							med.add(myMed);
				
							totalPrice+=myMed.getMedicinePrice();
							System.out.println(shopChoice);
							System.out.println("Buy more medicines? (Y/N): ");
							ch=scan.next().charAt(0);
							System.out.println();
						} while(ch=='Y'||ch=='y');

						System.out.println("\n**********************************");
						//Trade trade=new Trade(countOne, totalPrice, currentDate, customer, shopOne, med);
						Trade trade= (Trade) app.getBean("trade");
						trade.setId(countOne);
						trade.setTotalPrice(totalPrice);
						trade.setDate(currentDate);
						trade.setCustomer(customer);
						trade.setShop(shopOne);
						trade.setMedicines(med);
						//System.out.println("In ui"+trade);
						tradeservice.addTrade(trade);
						System.out.println(tradeservice.showTrade());
						System.out.println("\n");
						countOne++;
						System.out.println("**********************************\n");
					}
					catch (MedicineNotFoundException e) {
						System.out.println(e.getMessage());

					} catch (TradeNoSaveException e) {
						System.out.println(e.getMessage());
						
					} catch (TradeNotShowingException e) {
						System.out.println(e.getMessage());
					}
				}
				catch (CustomerDetailsNotFoundException e1) {
					System.out.println(e1.getMessage());
				}

				break;


			case 4:

				System.out.println("Enter Date : ");							
				String dateOne = scan.next();

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

				Date givendate;
				try {		
					givendate = dateFormat.parse(dateOne);
					List<Trade> tradeList = tradeservice.searchByDate(givendate);
					for(Trade tradeRef:tradeList)
					{
						System.out.println("\n"+tradeRef);
					}

				} catch (DateNotFoundException e) {

					System.out.println(e.getMessage());	
				}

				break;


			case 5:

				System.out.println("Enter Customer Id : ");
				String custIdOne = scan.next();

				System.out.println("Enter Date : ");
				String dateOneOne = scan.next();


				SimpleDateFormat dateFormatOne = new SimpleDateFormat("dd-MM-yyyy");

				Date givendateOne;
				try {

					givendateOne = dateFormatOne.parse(dateOneOne);
					List<Trade> tradeListOne = tradeservice.searchCustomerByDate(custIdOne, givendateOne);

					for(Trade tradeRefOne :tradeListOne)
					{
						System.out.println("\n**********************************");
						System.out.println(tradeRefOne);
						System.out.println("**********************************\n");
					}

				} catch (DateNotFoundException e) {

					System.out.println(e.getMessage());

				}

				break;


			case 6:

				System.exit(choice);
				break;


			default :
				System.out.println("Wrong choice ..!");
				break;
			}


		}while(choice!=7);
		scan.close();
		app.close();
	}
	
	
	private static void printMenu() 
	{
		System.out.println("\n\n\n**********************************");
		System.out.println("**********************************\n");
		System.out.println("    **************");
		System.out.println("    *  MedLife   *");
		System.out.println("    **************\n");
		System.out.println("1. Add new Customer ");
		System.out.println("2. Add new shop ");
		System.out.println("3. Search Medicines from shops");
		System.out.println("4. Search Transaction By date");
		System.out.println("5. Search Customer Transaction By Date");
		System.out.println("6. Exit\n");
		System.out.println("**********************************");
		System.out.println("**********************************\n");

	}
}