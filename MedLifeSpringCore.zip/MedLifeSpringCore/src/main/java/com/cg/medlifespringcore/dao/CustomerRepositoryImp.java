package com.cg.medlifespringcore.dao;



import org.springframework.stereotype.Repository;

import com.cg.medlifespringcore.dto.Customer;


import com.cg.medlifespringcore.util.DButil;
@Repository("customerRepository")
public class CustomerRepositoryImp implements CustomerRepository 
{
	public CustomerRepositoryImp()
	{}

	public Customer save(Customer customer){

		DButil.customerData.add(customer);
		return  customer;
	}
	

	public Customer findById(String id) {
		for (Customer customer : DButil.customerData) {
			if(customer.getCustId().equalsIgnoreCase(id))
				return customer;
		}
		return null;
	}	
}