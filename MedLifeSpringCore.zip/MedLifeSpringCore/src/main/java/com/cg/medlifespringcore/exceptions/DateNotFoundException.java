package com.cg.medlifespringcore.exceptions;

public class DateNotFoundException extends Exception {
	
	public DateNotFoundException()
	{}
	
	public DateNotFoundException(String exceptionMessage){
		super(exceptionMessage);
	}
}
