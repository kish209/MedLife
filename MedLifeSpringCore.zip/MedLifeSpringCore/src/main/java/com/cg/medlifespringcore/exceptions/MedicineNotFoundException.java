package com.cg.medlifespringcore.exceptions;

public class MedicineNotFoundException extends Exception {
	public MedicineNotFoundException() {
	}
	
	public MedicineNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}