package com.cg.medlifespringcore.util;

import java.util.ArrayList;
import java.util.List;
import com.cg.medlifespringcore.dto.Customer;
import com.cg.medlifespringcore.dto.Shop;
import com.cg.medlifespringcore.dto.Trade;


public class DButil {
	
	public static List<Shop> shopData = new ArrayList<Shop>();
	public static List<Trade> tradeData = new ArrayList<Trade>();
	public static List <Customer> customerData = new ArrayList<Customer>();
	

}