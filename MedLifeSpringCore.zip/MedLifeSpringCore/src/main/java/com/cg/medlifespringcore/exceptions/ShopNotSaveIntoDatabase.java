package com.cg.medlifespringcore.exceptions;

public class ShopNotSaveIntoDatabase extends Exception {
	public ShopNotSaveIntoDatabase()
	{
		
	}
	public ShopNotSaveIntoDatabase(String exceptionMessage) {
		super(exceptionMessage);
	}

}
