package com.cg.medlifespringcore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.medlifespringcore.dao.CustomerRepositoryImp;

import com.cg.medlifespringcore.dto.Customer;
import com.cg.medlifespringcore.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifespringcore.exceptions.CustomerNotSaveIntoDatabase;

@Service("customerService")
public class CustomerServiceImp implements CustomerService{
	
	@Autowired
	CustomerRepositoryImp customerrepository;
	public CustomerServiceImp(){

	}

	public Customer addCustomer(Customer customer) throws CustomerNotSaveIntoDatabase {
		if(customerrepository.save(customer)==null)
			throw new CustomerNotSaveIntoDatabase("customer not save in database");
		return customerrepository.save(customer);
	}

	public Customer searchById(String id) throws CustomerDetailsNotFoundException {
		if(customerrepository.findById(id)==null)
			throw new CustomerDetailsNotFoundException("Customer not found");
		return customerrepository.findById(id);
	}
}