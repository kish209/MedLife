package com.cg.medlifespringcore.service;

import java.util.List;


import com.cg.medlifespringcore.dto.Shop;
import com.cg.medlifespringcore.exceptions.MedicineNotFoundException;
import com.cg.medlifespringcore.exceptions.ShopNotSaveIntoDatabase;

public interface ShopService {
public Shop addShop(Shop shop) throws ShopNotSaveIntoDatabase;
public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException;
}