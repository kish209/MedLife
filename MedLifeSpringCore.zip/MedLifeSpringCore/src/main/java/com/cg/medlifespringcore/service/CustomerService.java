package com.cg.medlifespringcore.service;

import com.cg.medlifespringcore.dto.Customer;

import com.cg.medlifespringcore.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifespringcore.exceptions.CustomerNotSaveIntoDatabase;

public interface CustomerService{

	public Customer addCustomer(Customer customer) throws CustomerNotSaveIntoDatabase;
	public Customer searchById(String id) throws CustomerDetailsNotFoundException;
}