package com.cg.medlifespringcore.dao;


import com.cg.medlifespringcore.dto.Customer;


public interface CustomerRepository {

	public Customer save(Customer customer);
	public Customer findById(String id);
}
