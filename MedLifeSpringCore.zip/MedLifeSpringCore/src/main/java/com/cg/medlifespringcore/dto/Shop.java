package com.cg.medlifespringcore.dto;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("shop")
@Scope("prototype")
public class Shop 
{
	private int shopId;
	private String shopName;

	private Address address;
	
	private List<Medicine> medicines;

	public Shop()
	{	}

	public Shop(int shopId, String shopName, Address address, List<Medicine> medicines) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.address = address;
		this.medicines = medicines;
	}

	public String toString() {
		return "Shop [shopId=" + shopId + ", shopName=" + shopName + ", address=" + address + ", medicines=" + medicines+ "]";
	}

	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}					
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<Medicine> getMedicines() {
		return medicines;
	}
	public void setMedicines(List<Medicine> medicines) {
		this.medicines = medicines;
	}	
}