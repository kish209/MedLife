package com.cg.medlifespringcore.dao;

import java.util.List;


import com.cg.medlifespringcore.dto.Shop;
import com.cg.medlifespringcore.exceptions.ShopNotSaveIntoDatabase;

public interface ShopRepository {

	public Shop save(Shop shop) throws ShopNotSaveIntoDatabase;
	public List<Shop> findByName(String medicineName);

}
