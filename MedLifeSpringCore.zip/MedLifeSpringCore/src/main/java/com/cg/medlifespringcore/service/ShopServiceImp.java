package com.cg.medlifespringcore.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifespringcore.dao.ShopRepositoryImp;
import com.cg.medlifespringcore.dto.Shop;
import com.cg.medlifespringcore.exceptions.MedicineNotFoundException;
import com.cg.medlifespringcore.exceptions.ShopNotSaveIntoDatabase;
@Service("shopService")
public class ShopServiceImp implements ShopService{

	@Autowired
	private ShopRepositoryImp shoprepository;
	

	public Shop addShop(Shop shop) throws ShopNotSaveIntoDatabase {

		if(shoprepository.save(shop)== null)
			throw new ShopNotSaveIntoDatabase("Shop not save in database");
		return shoprepository.save(shop);
	}

	public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException {

		if(shoprepository.findByName(medicineName).isEmpty())
			throw new MedicineNotFoundException("Medicine not found");
		return shoprepository.findByName(medicineName);
	}
}