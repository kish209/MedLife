package com.cg.medlifespringcore.exceptions;

public class TradeNotShowingException extends Exception {

	public TradeNotShowingException ()
	{
		
	}
	
	public TradeNotShowingException (String msg)
	{
		super(msg);
	}
}
