package com.cg.medlifemvcjavaconfig.dao;

import java.util.ArrayList;




import java.util.List;


import org.springframework.stereotype.Repository;

import com.cg.medlifemvcjavaconfig.dto.Medicine;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.util.DButil;

@Repository("shopRepository")
public class ShopRepositoryImp implements ShopRepository{


	List<Medicine> medicineData;
	public ShopRepositoryImp()
	{

		medicineData = new ArrayList<Medicine>();
	}

	public Shop save(Shop shop)  {
			
		DButil.shopData.add(shop);
		return shop;
	
	
	}
	

	public List<Shop> findByName(String medicineNameOne) {
		List<Shop> shop1=new ArrayList <Shop>();
		for(Shop shop : DButil.shopData) 
		{
			if( (!shop1.contains(shop)))
				for (Medicine medicine : shop.getMedicines()) {
					if(medicine.getMedicineName().toLowerCase().equals(medicineNameOne.toLowerCase()))
					{
						shop1.add(shop);
					}
				}
		}
		return shop1;
	}

	@Override
	public List<Shop> showAllShop() {
		// TODO Auto-generated method stub
		return DButil.shopData;
	}
}