package com.cg.medlifemvcjavaconfig.dao;

import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;

public interface ShopRepository {

	public Shop save(Shop shop) throws ShopNotSaveIntoDatabase;
	public List<Shop> findByName(String medicineName);

}
