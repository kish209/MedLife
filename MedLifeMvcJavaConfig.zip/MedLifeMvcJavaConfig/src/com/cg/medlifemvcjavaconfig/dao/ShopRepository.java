package com.cg.medlifemvcjavaconfig.dao;

import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;

public interface ShopRepository {

	
	
	public Shop save(Shop shop);
	public List<Shop> findByName(String medicineName) throws MedicineNotFoundException;
	public List<Shop> showAllShop();

}
