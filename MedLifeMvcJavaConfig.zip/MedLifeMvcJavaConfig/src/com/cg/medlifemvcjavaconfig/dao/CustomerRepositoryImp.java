package com.cg.medlifemvcjavaconfig.dao;



import java.util.List;

import org.springframework.stereotype.Repository
;

import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.util.DButil;
@Repository("customerRepository")
public class CustomerRepositoryImp implements CustomerRepository 
{
	public CustomerRepositoryImp()
	{}

	public Customer save(Customer customer){

		DButil.customerData.add(customer);
		return  customer;
	}
	

	public Customer findById(String id) {
		for (Customer customer : DButil.customerData) {
			if(customer.getCustId().equalsIgnoreCase(id))
				return customer;
		}
		return null;
	}	
	
	public List<Customer> showAllCustomers() {
		return DButil.customerData;
	}



}