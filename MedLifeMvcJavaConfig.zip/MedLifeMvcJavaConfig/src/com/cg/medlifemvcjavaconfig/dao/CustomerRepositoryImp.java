package com.cg.medlifemvcjavaconfig.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.medlifemvcjavaconfig.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;


@Repository
public class CustomerRepositoryImp implements CustomerRepository 
{
	@PersistenceContext
	EntityManager em;

	public CustomerRepositoryImp() {
	}


	public Customer save(Customer customer) throws CustomerNotSaveIntoDatabase{

		try	
			{	
			em.persist(customer);
			return customer;
			}
		
		/*Handling exception*/
		catch(Exception e)
		{
			throw new CustomerNotSaveIntoDatabase("Customer information not save in database"); 
			
		}
		}
		

	public Customer findById(String id) throws CustomerDetailsNotFoundException
	{
		try
		
		{	
		Customer customer = new  Customer();
		/*accessing customer from customer using specific customer id */
		
		TypedQuery<Customer> query = em.createQuery("select c from Customer c where c.custId=? ", Customer.class);
		query.setParameter(1, id);
		customer=query.getSingleResult();
		return customer;
		}
		/*Handling exception*/
		catch(Exception e)
		{
			throw new CustomerDetailsNotFoundException("customer not found");
			
		}
	}	
	
	public List<Customer> showAllCustomers() {
		Query query= em.createQuery("FROM Customer");
		List<Customer> myList = query.getResultList();
		return myList;
	}

	


}