package com.cg.medlifemvcjavaconfig.dao;
import java.util.ArrayList;


import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.medlifemvcjavaconfig.dto.Trade;
import com.cg.medlifemvcjavaconfig.util.DButil;

@Repository("tradeRepository")
public class TradeRepositoryImp implements TradeRepository{

	public List<Trade> findByDate(Date date) {
		List <Trade> trade1 = new ArrayList<Trade>();

		for (Trade trade : DButil.tradeData) {
			if(trade.getDate().equals(date))
				trade1.add(trade);
		}
		return trade1;
	}

	public List<Trade> findCustomerByDate(String custId, Date date){
		List <Trade> trade2 = new ArrayList<Trade>();
		for (Trade tradeOne : DButil.tradeData) {
			if((tradeOne.getCustomer().getCustId().equals(custId)) && (tradeOne.getDate().equals(date)) )
				trade2.add(tradeOne);
		}
		return trade2;
	}


	public Trade saveTrade(Trade trade) {
		DButil.tradeData.add(trade);
		return trade;
	}


	public List<Trade> showAll() {
		return DButil.tradeData;
	}
}