package com.cg.medlifemvcjavaconfig.dao;


import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Customer;


public interface CustomerRepository {

	public Customer save(Customer customer);
	public Customer findById(String id);
	public List<Customer> showAllCustomers();
}
