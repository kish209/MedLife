package com.cg.medlifemvcjavaconfig.service;

import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;

public interface ShopService {
public Shop addShop(Shop shop) throws ShopNotSaveIntoDatabase;
public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException;
}