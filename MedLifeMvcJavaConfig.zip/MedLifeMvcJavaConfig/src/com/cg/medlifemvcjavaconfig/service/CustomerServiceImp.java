package com.cg.medlifemvcjavaconfig.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifemvcjavaconfig.dao.CustomerRepositoryImp;
import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;

@Service("customerService")
public class CustomerServiceImp implements CustomerService{
	
	@Autowired
	CustomerRepositoryImp customerrepository;
	public CustomerServiceImp(){

	}

	public Customer addCustomer(Customer customer) throws CustomerNotSaveIntoDatabase {
		if(customerrepository.save(customer)==null)
			throw new CustomerNotSaveIntoDatabase("customer not save in database");
		return customerrepository.save(customer);
	}

	public Customer searchById(String id) throws CustomerDetailsNotFoundException {
		if(customerrepository.findById(id)==null)
			throw new CustomerDetailsNotFoundException("Customer not found");
		return customerrepository.findById(id);
	}
	public List <Customer> showAllCustomers() {
		return customerrepository.showAllCustomers();
	}


}