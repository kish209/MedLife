package com.cg.medlifemvcjavaconfig.service;
import java.util.Date;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifemvcjavaconfig.dao.TradeRepositoryImp;
import com.cg.medlifemvcjavaconfig.dto.Trade;
import com.cg.medlifemvcjavaconfig.exceptions.DateNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeNoSaveException;
import com.cg.medlifemvcjavaconfig.exceptions.TradeNotShowingException;

@Service("tradeService")
public class TradeServiceImp implements TradeService {

	@Autowired
	TradeRepositoryImp repository;

	public List<Trade> searchByDate(Date date) throws DateNotFoundException {

		if(repository.findByDate(date).isEmpty())
			throw new DateNotFoundException("Date not found in transaction");
		return repository.findByDate(date);
	}

	public List<Trade> searchCustomerByDate(String custName, Date date) throws DateNotFoundException {
		if(repository.findCustomerByDate(custName, date).isEmpty())
			throw new DateNotFoundException("Transaction not found");
		return repository.findCustomerByDate(custName, date);
	}


	public List<Trade> showTrade() throws TradeNotShowingException {
		if(repository.showAll()==null)
			throw new TradeNotShowingException("Trade is not available ");
		return repository.showAll();
	}


	public Trade addTrade(Trade trade) throws TradeNoSaveException {
		Trade t=repository.saveTrade(trade);
		if(t==null)
			throw new TradeNoSaveException("Trade Not saved");
		return t;
	}
}