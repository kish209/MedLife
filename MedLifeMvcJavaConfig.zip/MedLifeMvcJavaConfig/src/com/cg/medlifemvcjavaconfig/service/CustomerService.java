package com.cg.medlifemvcjavaconfig.service;

import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;

public interface CustomerService{

	public Customer addCustomer(Customer customer) throws CustomerNotSaveIntoDatabase;
	public Customer searchById(String id) throws CustomerDetailsNotFoundException;
	public List<Customer> showAllCustomers();
}