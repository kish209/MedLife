package com.cg.medlifemvcjavaconfig.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifemvcjavaconfig.dao.ShopRepositoryImp;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.exceptions.MedicineNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;
@Service("shopService")
public class ShopServiceImp implements ShopService{

	@Autowired
	private ShopRepositoryImp shoprepository;
	

	public Shop addShop(Shop shop) throws ShopNotSaveIntoDatabase {

		if(shoprepository.save(shop)== null)
			throw new ShopNotSaveIntoDatabase("Shop not save in database");
		return shoprepository.save(shop);
	}

	public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException {

		if(shoprepository.findByName(medicineName).isEmpty())
			throw new MedicineNotFoundException("Medicine not found");
		return shoprepository.findByName(medicineName);
	}

	@Override
	public List<Shop> showAllShop() {
		// TODO Auto-generated method stub
		return shoprepository.showAllShop();
	}
}