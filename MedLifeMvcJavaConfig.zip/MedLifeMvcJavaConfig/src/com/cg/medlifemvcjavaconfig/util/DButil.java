package com.cg.medlifemvcjavaconfig.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.dto.Trade;


public class DButil {
	
	public static List<Shop> shopData = new ArrayList<Shop>();
	public static List<Trade> tradeData = new ArrayList<Trade>();
	public static List <Customer> customerData = new ArrayList<Customer>();
	

}