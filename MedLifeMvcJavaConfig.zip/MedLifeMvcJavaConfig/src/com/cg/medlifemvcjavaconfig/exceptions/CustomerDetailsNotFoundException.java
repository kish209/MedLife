package com.cg.medlifemvcjavaconfig.exceptions;


public class CustomerDetailsNotFoundException extends Exception{
	public CustomerDetailsNotFoundException() 
	{}
	
	public CustomerDetailsNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}