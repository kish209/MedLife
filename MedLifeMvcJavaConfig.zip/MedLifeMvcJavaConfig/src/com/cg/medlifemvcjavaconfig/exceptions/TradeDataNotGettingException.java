package com.cg.medlifemvcjavaconfig.exceptions;

public class TradeDataNotGettingException extends Exception {
	public TradeDataNotGettingException()
	{
		
	}
	
	public TradeDataNotGettingException(String exceptionMessage)
	{
		super(exceptionMessage);
		
	}

}
