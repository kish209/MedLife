package com.cg.medlifemvcjavaconfig.exceptions;

public class TradeNoSaveException extends Exception {
	public TradeNoSaveException()
	{
		
	}
	public TradeNoSaveException(String msg)
	{
		super(msg);
	}

}
