package com.cg.medlifemvcjavaconfig.dto;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("address")
@Scope("prototype")
public class Address {
	private String houseNumber;
	private String area;
	private String city;
	private long pincode; 
	
	public Address()
	{
		houseNumber=null;
		area=null;
		city=null;
		pincode=0;	
	}
	
	public Address(String houseNumber, String area, String city, long pincode) {
		super();
		this.houseNumber = houseNumber;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
	}
	
	public String toString() {
		return " [House Number=" + houseNumber + ", Area=" + area + ", City=" + city + ", Pincode=" + pincode + "]";
	}

	public String getHouseNumber() {
		return houseNumber;
	}
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

}