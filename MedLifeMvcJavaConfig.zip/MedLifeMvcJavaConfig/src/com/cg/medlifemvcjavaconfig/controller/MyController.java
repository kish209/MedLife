package com.cg.medlifemvcjavaconfig.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.dto.Medicine;
import com.cg.medlifemvcjavaconfig.dto.Shop;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.service.CustomerService;
import com.cg.medlifemvcjavaconfig.service.ShopService;
import com.cg.medlifemvcjavaconfig.service.TradeService;


@Controller
public class MyController {

	@Autowired
	CustomerService customerService;
	@Autowired
	ShopService shopService;
	@Autowired
	TradeService tradeService;
	
	@GetMapping("login")
	public String loginPage()
	{
		return "listpage";
	}
	
	
	

	 @PostMapping("checkLogin")
     public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
		// System.out.println("check login");
		 if(user.equals("admin") && pass.equals("123")) {
			 return "listpage";
		 }else {
			 return "error";
		 }
		// return null;
	 }
	 
	 @GetMapping("custadd")
	 public ModelAndView getAddCustomer(@ModelAttribute("customer") Customer cust) {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addcustomer", "details", myMap);
	 }
	 
	 @PostMapping("addcustomer")
	 public ModelAndView addCustomer(@ModelAttribute("customer") Customer cust) throws CustomerNotSaveIntoDatabase {
//		 System.out.println(pro);
		 Customer customer= customerService.addCustomer(cust);
		 return new ModelAndView("success","key",customer);
	 }
	 
	 @GetMapping("showcust")
	 public ModelAndView showCustomer() throws CustomerDetailsNotFoundException {
		 List<Customer> myCustomer = customerService.showAllCustomers();
		 return new ModelAndView("showAllCustomer", "customershow", myCustomer);
	 }
	
	 
	 
	 @GetMapping("shopadd")
	 public ModelAndView getAddShop(@ModelAttribute("shop") Shop shopOne) {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addshop", "details", myMap);
	 }
	 
	 @PostMapping("addshop")
	 public ModelAndView addShop(@ModelAttribute("shop") Shop shopOne) throws ShopNotSaveIntoDatabase {
//		 System.out.println(pro);
		 Shop shop= shopService.addShop(shopOne);
		 
		 return new ModelAndView("successShop","key",shop);
	 }
	 
	 
	 @GetMapping("showshop")
	 public ModelAndView showShop() throws CustomerDetailsNotFoundException {
		 List<Shop> myShop = shopService.showAllShop();
		 return new ModelAndView("showAllShop", "shopshow", myShop);
	 }
	 
/*	 @GetMapping("addmed")
	 public ModelAndView addMed() throws CustomerDetailsNotFoundException {
		 List<Shop> myMedicine = shopService.showAllShop();
		 return new ModelAndView("showAllShop", "customershow", myMedicine);
	 }*/
	 
	 @GetMapping("medadd")
	 public ModelAndView addShopId(@ModelAttribute("shop") Shop shopId) throws ShopNotSaveIntoDatabase {
//		 System.out.println(pro);
		 Shop shop= shopService.addShop(shopId);
		 
		 return new ModelAndView("addmed","key",shop);
	 }
	 
	 @PostMapping("addmed")
	 public ModelAndView addMed(@ModelAttribute("medicine") Shop medicineOne) throws ShopNotSaveIntoDatabase {
//		 System.out.println(pro);
		 Shop shop= shopService.addShop(medicineOne);
		 
		 return new ModelAndView("successShop","key",shop);
	 }
	 
	
}
