package com.cg.medlifemvcjavaconfig.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.medlifemvcjavaconfig.dto.Customer;
import com.cg.medlifemvcjavaconfig.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifemvcjavaconfig.service.CustomerService;


@Controller
public class MyController {

	@Autowired
	CustomerService customerService;
	
	@GetMapping("login")
	public String loginPage()
	{
		return "mylogin";
	}
	
	
	

	 @PostMapping("checkLogin")
     public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
		// System.out.println("check login");
		 if(user.equals("admin") && pass.equals("123")) {
			 return "listpage";
		 }else {
			 return "error";
		 }
		// return null;
	 }
	 
	 @GetMapping("custadd")
	 public ModelAndView getAddCustomer(@ModelAttribute("customer") Customer cust) {
		 Map<String, Object> myMap = new HashMap<>();
		 
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Katraj");
		 listOfArea.add("Pimpri");
		 listOfArea.add("Akurdi");
		 listOfArea.add("Pune");
		 listOfArea.add("Hinjawadi");
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Pimpri-Chinchwad");
		 listOfCity.add("Khed");
		 listOfCity.add("Katraj");
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addcustomer", "details", myMap);
	 }
	 
	 @GetMapping("showcust")
	 public ModelAndView showCustomer() {
		 List<Customer> myCustomer = customerService.showAllCustomers();
		 return new ModelAndView("showAll", "showcustomer", myCustomer);
	 }
	 
	 
	 @PostMapping("addcustomer")
	 public ModelAndView addproduct(@ModelAttribute("customer") Customer cust) throws CustomerNotSaveIntoDatabase {
//		 System.out.println(pro);
		 Customer customer= customerService.addCustomer(cust);
		 return new ModelAndView("success","key",customer);
	 }
	
}
