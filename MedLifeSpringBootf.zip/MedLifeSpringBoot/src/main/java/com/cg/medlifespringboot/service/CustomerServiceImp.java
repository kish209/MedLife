package com.cg.medlifespringboot.service;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifespringboot.dao.CustomerRepository;
import com.cg.medlifespringboot.dto.Customer;

@Transactional
@Service
public class CustomerServiceImp implements CustomerService{

	@Autowired
	CustomerRepository customerrepository;
	
	//static int countAddress=200;
	public CustomerServiceImp(){
	
	}

	public Customer addCustomer(Customer customer) {

	/*	customer.getAddress().setAddressId(countAddress);
		countAddress++;*/
		return customerrepository.save(customer);
	}

	public Customer searchById(String id) {

		return customerrepository.findBycustId(id);
	}

	@Override
	public List<Customer> showAll() {
		// TODO Auto-generated method stub
		return customerrepository.findAll();
	}


}