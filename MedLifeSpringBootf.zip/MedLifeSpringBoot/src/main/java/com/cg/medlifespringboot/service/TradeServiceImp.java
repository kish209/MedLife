package com.cg.medlifespringboot.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifespringboot.dao.TradeRepository;
import com.cg.medlifespringboot.dto.Trade;
@Service
public class TradeServiceImp implements TradeService {

	public TradeServiceImp() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	TradeRepository repository;

/*	public List<Trade> searchByDate(Date date) {

		return repository.findByDate(date);
	}

	public List<Trade> searchCustomerByDate(String custName, Date date) {

		return repository.findCustomerByDate(custName, date);
	}
*/

	public List<Trade> showTrade()
	{

		return repository.findAll();
	}


	public Trade addTrade(Trade trade){
	
		return repository.save(trade);
	}


	@Override
	public Trade searchById(int id) {
		// TODO Auto-generated method stub
		return repository.findByid(id);
	}
}