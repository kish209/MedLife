package com.cg.medlifespringboot.dao;
import java.util.Date;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.medlifespringboot.dto.Trade;


public interface TradeRepository  extends JpaRepository<Trade, Integer>{

	/*public List<Trade> findByDate(Date date) ;
	public List<Trade> findCustomerByDate(String custName, Date date) ;*/
	public Trade findByid(int id);
}