package com.cg.medlifespringboot.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.medlifespringboot.dto.Customer;
import com.cg.medlifespringboot.dto.Shop;

public interface ShopRepository  extends JpaRepository<Shop, Integer> {

	
	  @Query("FROM Shop s, IN (s.medicines) m WHERE m.medicineName=:name") public
	  List<Shop> findBymedicineName(@Param("name")String name);
	 
	public Shop findByshopId(int id);

}
