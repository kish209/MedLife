package com.cg.medlifespringboot.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.medlifespringboot.dto.Address;
import com.cg.medlifespringboot.dto.Customer;
import com.cg.medlifespringboot.dto.Medicine;
import com.cg.medlifespringboot.dto.Shop;
import com.cg.medlifespringboot.dto.Trade;
import com.cg.medlifespringboot.service.CustomerService;
import com.cg.medlifespringboot.service.ShopService;
import com.cg.medlifespringboot.service.TradeService;


@RestController
@RequestMapping("/medlife")
public class MedLifeController {
	@Autowired
	CustomerService customerservice;
	@Autowired
	ShopService shopservice;
	@Autowired
	TradeService tradeservice;
	Date date1= new Date();
	Customer customer;

	

	@RequestMapping(value="/addcustomer",method=RequestMethod.POST)
	public ResponseEntity<Customer> addCustomer(@ModelAttribute Customer cust) {
        System.out.println(cust);
        //Customer customer = null;
        Customer custOne = customerservice.searchById(cust.getCustId());
        
        if(custOne!=null)
        {
        	return new ResponseEntity("Customer Already Exist..", HttpStatus.NOT_FOUND);
        }
        else
        {
        	customer=customerservice.addCustomer(cust);
        	if(customer==null)
        	{
        		return new ResponseEntity("Customer not added", HttpStatus.NOT_FOUND);
        	}
        	
        }
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}

	
	@RequestMapping(value="/showcustomer",method=RequestMethod.GET)

	public ResponseEntity<List<Customer>> showAllCustomer(){

		List<Customer> myList=customerservice.showAll();
		if(myList.isEmpty())
		{
			return new ResponseEntity("No Customer to show", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Customer>> (myList, HttpStatus.OK);
	}
	
	
	
	@RequestMapping(value="/addshop",method=RequestMethod.POST)
	public ResponseEntity<Shop> addShop(@ModelAttribute("shop") Shop sh) {
        System.out.println(sh);
        Shop shop = null;
        Shop shOne = shopservice.searchById(sh.getShopId());   
        if(shOne!=null)
        {
        	return new ResponseEntity("Shop Already Exist..", HttpStatus.NOT_FOUND);
        }
        else
        {
        	shop=shopservice.addShop(sh);
        	if(shop==null)
        	{
        		return new ResponseEntity("shop not added", HttpStatus.NOT_FOUND);
        	}
        	
        }
		return new ResponseEntity<Shop>(shop, HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/showshop",method=RequestMethod.GET)

	public ResponseEntity<List<Shop>> showAllShop(){

		List<Shop> myList=shopservice.showAll();
		if(myList.isEmpty())
		{
			return new ResponseEntity("No Shop to show..", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Shop>> (myList, HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/searchcust",method=RequestMethod.GET)

	public ResponseEntity<Customer> searchcust(@ModelAttribute("customer") Customer custId){

		Customer myList=customerservice.searchById(custId.getCustId());
		System.out.println(myList);
		if(myList==null)
		{
			return new ResponseEntity("No customer search to show..", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Customer> (myList, HttpStatus.OK);
	}
	
	@RequestMapping(value="/searchcust/searchmed",method=RequestMethod.GET)

	public ResponseEntity<List<Shop>> searchMed(@ModelAttribute("medicine") Medicine med){
		Shop shop = new Shop();
		List<Shop> myList;
		List<Medicine> myListM= new ArrayList<Medicine>(); 
		Medicine medi = new Medicine();
		
		myList=shopservice.searchByMedicine(med.getMedicineName());
		
		/*
		 * med.setMedicineId(medi.getMedicineId());
		 * med.setMedicineName(medi.getMedicineName());
		 * med.setMedicineType(medi.getMedicineType());
		 * med.setMedicinePrice(medi.getMedicinePrice());
		 * 
		 * shop.setMedicines(myListM);
		 */
		
		if(myList.isEmpty())
		{
			return new ResponseEntity("No medicine to show", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Shop>> (myList, HttpStatus.OK);
	}


	@RequestMapping(value="/searchcust/searchmed/addtrade",method=RequestMethod.POST)
	public ResponseEntity<Trade>
			addTrade(@ModelAttribute Trade tr ) throws ParseException {

			
        System.out.println(tr);
        Trade trade = null;
        Customer c = new Customer();
        Address add  = new Address();
        Shop shop= new Shop();
        Trade tradeOne = tradeservice.searchById(tr.getId());
        if(tradeOne!=null)
        {
        	return new ResponseEntity("Trade Already Exist..", HttpStatus.NOT_FOUND);
        }
        else
        {
        	Shop shop1 = shopservice.searchById(shop.getShopId());
        	
        	
        	
        	SimpleDateFormat formatDate = new SimpleDateFormat("dd-MM-yyyy");
    		String strDate= formatDate.format(date1);
    		Date currentDate= formatDate.parse(strDate);
        	//Date date1 = null;
        	//date1=(Date) dateFormat.parse(date);
        	tr.setDate(currentDate);
        	c.setCustId(customer.getCustId());
        	c.setCustName(customer.getCustName());
        	c.setContact(customer.getContact());
        	 c.setContact(customer.getContact());
    		 add.setHouseNumber(customer.getAddress().getHouseNumber());
    		 add.setArea(customer.getAddress().getArea());
    		 add.setCity(customer.getAddress().getCity());
    		 add.setPincode(customer.getAddress().getPincode());
    		 c.setAddress(add);
    		 tr.setCustomer(c);
    		 tr.setTotalPrice(shop1.getMedicines().get(0).getMedicinePrice());
    			
    		 tr.setShop(shop1);
    		 
        	tr.setCustomer(customer);
        	trade=tradeservice.addTrade(tr);
        	if(trade==null)
        	{
        		return new ResponseEntity("Trade not added", HttpStatus.NOT_FOUND);
        	}
        	
        }
		return new ResponseEntity<Trade>(trade, HttpStatus.OK);
	}


}
