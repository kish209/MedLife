package com.cg.medlifespringboot.service;


import java.util.List;

import com.cg.medlifespringboot.dto.Customer;


public interface CustomerService{

	public Customer addCustomer(Customer customer);
	public Customer searchById(String id);
	public List<Customer> showAll();
}