package com.cg.medlifejpa.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Address {
	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="house_id")
	private int houseId;
	
	@Column(name="house_number")
	private String houseNumber;
	
	@Column(name="house_area")
	private String area;
	
	@Column(name="city")
	private String city;
	
	@Column(name="pincode")
	private long pincode; 
	

	public Address(int houseId, String houseNumber, String area, String city, long pincode) {
		super();
		this.houseId = houseId;
		this.houseNumber = houseNumber;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
	}

	public int getHouseId() {
		return houseId;
	}

	public void setHouseId(int houseId) {
		this.houseId = houseId;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [houseId=" + houseId + ", houseNumber=" + houseNumber + ", area=" + area + ", city=" + city
				+ ", pincode=" + pincode + "]";
	}


	
	//default constructor
	public Address()
	{
		houseId=0;
		houseNumber=null;
		area=null;
		city=null;
		pincode=0;	
	}
	

}