package com.cg.medlifejpa.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="trade")
public class Trade {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="trade_id")
	private int id;
	
	@Column(name="total_price")
	private double totalPrice;
	
	@Column(name="trade_date")
	private Date date;
	
	@ManyToOne(cascade=CascadeType.ALL,targetEntity=Customer.class)
	@JoinColumn(name="cust_id")
	private Customer customer;
	
	@ManyToOne(cascade=CascadeType.ALL,targetEntity=Shop.class)
	@JoinColumn(name="shop_id")
	private Shop shop;
	
	@OneToMany(cascade=CascadeType.ALL,targetEntity=Medicine.class)
	@JoinColumn(name="medicine_id")
	private List <Medicine> medicines;

	//parameterized constructor
	public Trade(int id, double totalPrice, Date date, Customer customer, Shop shop, List<Medicine> medicines) {
		super();
		this.id = id;
		this.totalPrice = totalPrice;
		this.date = date;
		this.customer = customer;
		this.shop = shop;
		this.medicines = medicines;
	}
	
	//default constructor
	public Trade() {
	}
	
	//getter setter
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Shop getShop() {
		return shop;
	}
	public void setShop(Shop shop) {
		this.shop = shop;
	}
	public List<Medicine> getMedicines() {
		return medicines;
	}
	public void setMedicines(List<Medicine> medicines) {
		this.medicines = medicines;
	}
	@Override
	public String toString() {
		return "Trade [id=" + id + ", totalPrice=" + totalPrice + ", date=" + date + ", customer=" + customer
				+ ", shop=" + shop + ", medicines=" + medicines + "]";
	}

	/*public String toString() {
		return "\nTrade Id => " + id + ",\nTotal Price => " + totalPrice + "Rs"+",\nDate => " + date + ",\nCustomer => " + customer
				+ ",\nShop => " + shop.getShopName()+" "+shop.getAddress() + ",\nMedicines => " + medicines + "\n";
	}*/
	
}
