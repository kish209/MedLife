package com.cg.medlifejpa.exceptions;

public class DateNotFoundException extends Exception {
	
	public DateNotFoundException()
	{}
	
	public DateNotFoundException(String exceptionMessage){
		super(exceptionMessage);
	}
}
