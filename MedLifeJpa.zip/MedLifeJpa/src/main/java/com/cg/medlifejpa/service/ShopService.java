package com.cg.medlifejpa.service;

import java.util.List;

import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.exceptions.MedicineNotFoundException;
import com.cg.medlifejpa.exceptions.ShopNotSaveIntoDatabase;

public interface ShopService {
public Shop addShop(Shop shop) throws ShopNotSaveIntoDatabase;
public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException;
}