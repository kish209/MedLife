package com.cg.medlifejpa.dao;
import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;

import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejpa.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;
public class CustomerRepositoryImp implements CustomerRepository 
{
	EntityManager em;

	public CustomerRepositoryImp() {
		// TODO Auto-generated constructor stub
		em=DBUtil.em;
	}


	// saving customer into database

	public Customer save(Customer customer) throws CustomerNotSaveIntoDatabase {
		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
		
		return null;
		
	}


	
	//finding customer Id
	
	public Customer findById(String id) throws CustomerDetailsNotFoundException
	{
		
		
		return null;
		
	}	
	
}