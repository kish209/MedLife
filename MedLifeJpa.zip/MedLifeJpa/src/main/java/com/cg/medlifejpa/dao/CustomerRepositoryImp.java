package com.cg.medlifejpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejpa.exceptions.CustomerNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;
public class CustomerRepositoryImp implements CustomerRepository 
{
	EntityManager em;

	public CustomerRepositoryImp() {
		/*connection established*/
		em=DBUtil.em;
	}


	// saving customer into database

	public Customer save(Customer customer) throws CustomerNotSaveIntoDatabase {

	try	
		{	
		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
		return customer;
		}
	
	/*Handling exception*/
	catch(Exception e)
	{
		throw new CustomerNotSaveIntoDatabase("Customer information not save in database"); 
		
	}
	}
	


	
	//finding customer Id
	
	public Customer findById(String id) throws CustomerDetailsNotFoundException
	{
		try
		
		{	
		Customer customer = new  Customer();
		/*accessing customer from customer using specific customer id */
		
		TypedQuery<Customer> query = em.createQuery("select c from Customer c where c.custId=? ", Customer.class);
		query.setParameter(1, id);
		customer=query.getSingleResult();
		return customer;
		}
		/*Handling exception*/
		catch(Exception e)
		{
			throw new CustomerDetailsNotFoundException("customer not found");
			
		}
	}	
	
}