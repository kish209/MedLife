package com.cg.medlifejpa.dao;
import java.util.List;


import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.exceptions.MedicineNotFoundException;
import com.cg.medlifejpa.exceptions.ShopNotSaveIntoDatabase;

public interface ShopRepository {

	public Shop save(Shop shop) throws ShopNotSaveIntoDatabase;
	public List<Shop> findByName(String medicineName) throws MedicineNotFoundException;

}
