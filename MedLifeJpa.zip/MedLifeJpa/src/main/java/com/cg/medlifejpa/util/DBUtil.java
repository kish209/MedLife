package com.cg.medlifejpa.util;

/*
import java.math.BigInteger;

import java.util.ArrayList;
import java.util.List;

import com.cg.medlifejdbc.dto.Address;
import com.cg.medlifejdbc.dto.Customer;
import com.cg.medlifejdbc.dto.Shop;
import com.cg.medlifejdbc.dto.Trade;
import com.cg.medlifejdbc.service.CustomerService;
import com.cg.medlifejdbc.service.CustomerServiceImp;

public class DBUtil {
	
	public static List<Shop> shopData = new ArrayList<Shop>();
	public static List<Trade> tradeData = new ArrayList<Trade>();
	public static List <Customer> customerData = new ArrayList<Customer>();
	
	static {
		CustomerService customerservice=new CustomerServiceImp();

		Customer customer1 = new Customer("cust1","kishor",new BigInteger("8805072549"),new Address("11","Talwade","Pune",411062));
		Customer customer2 = new Customer("cust2","manthan",new BigInteger("7020231164"),new Address("12","Akurdi","Pune",411044));

		customer1=customerservice.addCustomer(customer1);
		customer2=customerservice.addCustomer(customer2);
		}
}*/

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;


public class DBUtil 
{	
	public static EntityManager em =Persistence.createEntityManagerFactory("medlife").createEntityManager();
	
}
