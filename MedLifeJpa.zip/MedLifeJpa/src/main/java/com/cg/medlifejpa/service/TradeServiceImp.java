package com.cg.medlifejpa.service;

import java.util.Date;

import java.util.List;

import com.cg.medlifejpa.dao.TradeRepository;
import com.cg.medlifejpa.dao.TradeRepositoryImp;
import com.cg.medlifejpa.dto.Trade;
import com.cg.medlifejpa.exceptions.DataNotFoundException;
import com.cg.medlifejpa.exceptions.DateNotFoundException;
import com.cg.medlifejpa.exceptions.TradeDataNotGettingException;
import com.cg.medlifejpa.exceptions.TradeNotSaveIntoDatabase;
public class TradeServiceImp implements TradeService {

	TradeRepository repository=new TradeRepositoryImp();

	public List<Trade> searchByDate(Date date) throws DateNotFoundException {

		if(repository.findByDate(date).isEmpty())
			throw new DateNotFoundException("Date not found in transaction");
		return repository.findByDate(date);
	}

	public List<Trade> searchCustomerByDate(String custName, Date date) throws DateNotFoundException, DataNotFoundException {
		if(repository.findCustomerByDate(custName, date).isEmpty())
			throw new DateNotFoundException("Transaction not found");
		return repository.findCustomerByDate(custName, date);
	}


	public List<Trade> showTrade() throws TradeDataNotGettingException
	{
		if(repository.showAll().isEmpty())
			throw new TradeDataNotGettingException("trade data not getting");
		return repository.showAll();
	}


	public Trade addTrade(Trade trade) throws TradeNotSaveIntoDatabase {
		
		if(repository.saveTrade(trade)==null)
			throw new TradeNotSaveIntoDatabase("trade data not save in database");
		return repository.saveTrade(trade);
	}
}