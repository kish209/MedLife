package com.cg.medlifejpa.exceptions;

public class MedicineNotFoundException extends Exception {
	public MedicineNotFoundException() {
	}
	
	public MedicineNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}