package com.cg.medlifejpa.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.dto.Medicine;

import com.cg.medlifejpa.dto.Trade;
import com.cg.medlifejpa.exceptions.DataNotFoundException;
import com.cg.medlifejpa.exceptions.DateNotFoundException;
import com.cg.medlifejpa.exceptions.TradeDataNotGettingException;
import com.cg.medlifejpa.exceptions.TradeNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;

public class TradeRepositoryImp implements TradeRepository{

	/*connection established*/
	EntityManager em;

	/*saving transaction into database*/

	public Trade saveTrade(Trade trade) throws TradeNotSaveIntoDatabase
	{
	try	
		{
			/*System.out.println(trade.getMedicines().get(0).getMedicineName());
			System.out.println(trade.getShop().getShopId());
			System.out.println(trade.getId());*/
			em=DBUtil.em;
			em.getTransaction().begin();
			em.persist(trade);	
			
			
			for (Medicine medicineL : trade.getMedicines()) 
			{
			Query queryOne = em.createQuery("update Medicine c SET c.trade.id=:tid where c.medicineName=:mn and c.shop.shopId=:sid");
			
			queryOne.setParameter("tid", trade.getId());
			queryOne.setParameter("mn", medicineL.getMedicineName());
			queryOne.setParameter("sid", trade.getShop().getShopId());
			queryOne.executeUpdate();
			em.merge(medicineL);
			}
			
			/*data adding into trade table*/
			em.getTransaction().commit();
			return  trade;
		}
		
		/*Handling exception*/
		catch(Exception e)
		{
			throw new TradeNotSaveIntoDatabase("Enter Information is not save in trade");

		}

	}


	//showing transaction
	public List<Trade> showAll() throws TradeDataNotGettingException 
	{
		List<Trade> tradeList = new ArrayList<Trade>();
		try
		{	
			/*showing trade from trade*/
			TypedQuery<Trade> query = em.createQuery("select c from Trade c",Trade.class);
			tradeList=query.getResultList();		
		}
		
		/*Handling exception*/
		catch(Exception e)
		{
			throw new TradeDataNotGettingException("Trade Information is not getting from database");
		}
		return tradeList;		

	}
	


	//finding transaction by input date

	public List<Trade> findByDate(java.util.Date date) throws DateNotFoundException
	{
		List<Trade> tradeList = new ArrayList<Trade>();

		try
		{
			/*showing transaction from specific date*/
			
			TypedQuery<Trade> query = em.createQuery("select t from Trade t where date=?", Trade.class);
			query.setParameter(1, date);
			tradeList=query.getResultList();
		}
		/*Handling exception*/
		catch(Exception e)
		{
			throw new DateNotFoundException("Date Not found exception");	
		}
		return tradeList;
	}


	//finding transaction by input date and customer

	public List<Trade> findCustomerByDate(String custId, java.util.Date date) throws DataNotFoundException
	{

		List<Trade> tradeList = new ArrayList<Trade>();
		List<Trade> tradeListOne = new ArrayList<Trade>();
		Customer customer = new  Customer();
		try
		{	
			/*showing transaction from specific date and customer id */
			
			TypedQuery<Trade> query = em.createQuery("select t from Trade t", Trade.class);
			tradeList=query.getResultList();
			for (Trade tradeOne : tradeList) {
				customer=tradeOne.getCustomer();
				if(tradeOne.getDate().equals(date) && customer.getCustId().equals(custId))
				{
					tradeListOne.add(tradeOne);
				}
			}
		}
		/*Handling exception*/
		catch(Exception e)
		{
			throw new DataNotFoundException("Data not found");

		}
		return tradeListOne;
	}

}