package com.cg.medlifejpa.dao;
import java.sql.Connection;


import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.dto.Medicine;
import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.dto.Trade;
import com.cg.medlifejpa.exceptions.DataNotFoundException;
import com.cg.medlifejpa.exceptions.DateNotFoundException;
import com.cg.medlifejpa.exceptions.TradeDataNotGettingException;
import com.cg.medlifejpa.exceptions.TradeNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;
public class TradeRepositoryImp implements TradeRepository{

	//saving transaction into database
	
	public Trade saveTrade(Trade trade) throws TradeNotSaveIntoDatabase {
		//Connection connection = DBUtil.getConnection();
		String query;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try
		
		{		
			int tradeId=0;
			Date mysql=convertUtilToSql(trade.getDate());
			query="insert into trade(total_price,trade_date,cust_id_f,shop_id_f) values(?,?,?,?)";
			//pstmt=connection.prepareStatement(query);
			pstmt.setDouble(1, trade.getTotalPrice());
			pstmt.setDate(2,mysql);
			pstmt.setString(3, trade.getCustomer().getCustId());
			pstmt.setInt(4, trade.getShop().getShopId());
			pstmt.executeUpdate();
			
			
			query="select max(trade_id) from trade";
			//pstmt=connection.prepareStatement(query);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				tradeId=rs.getInt(1);
			}

			query="update medicine set trade_id_f= ? where medicine_name=? and shop_id_f=?";
			for (Medicine medicine : trade.getMedicines()) 
			{
				//pstmt=connection.prepareStatement(query);
				pstmt.setInt(1, tradeId);
				pstmt.setString(2, medicine.getMedicineName());
				pstmt.setInt(3, trade.getShop().getShopId());
				pstmt.executeUpdate();
			}
			
			return trade;
			
		}
		catch(SQLException e)
		{
			throw new TradeNotSaveIntoDatabase("Enter Information is not save in trade");
			
		}
		
		//return  null;
	
	}


	//showing transaction
	
	public List<Trade> showAll() throws TradeDataNotGettingException 
	{
		Trade trade= new Trade();
		List <Trade> tradeList = new ArrayList<Trade>();
		int tradeId;
		//Connection connection = DBUtil.getConnection();
		String query;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try
		
		{	
			query="select * from trade";
		//	pstmt=connection.prepareStatement(query);
			rs= pstmt.executeQuery();
			System.out.println("Id   Price    Date      Customer Id  Shop Id\n");
			while(rs.next())
			{
				Customer custOne=new Customer();
				Shop shopOne=new Shop();
				tradeId=rs.getInt("trade_id");
				Double totalPrice=rs.getDouble("total_price");
				Date tradeDate=rs.getDate("trade_date");
				String custIdF=rs.getString("cust_id_f");
				int shopIdF=rs.getInt("shop_id_f");
				System.out.format("%s    %s     %s   %s     %s\n",tradeId,totalPrice,tradeDate,custIdF,shopIdF);
				trade.setId(tradeId);
				trade.setTotalPrice(totalPrice);
				trade.setDate(tradeDate);
				custOne.setCustId(custIdF);
				shopOne.setShopId(shopIdF);
				
				trade.setCustomer(custOne);
				trade.setShop(shopOne);
				
				tradeList.add(trade);
			}

		}
		catch(SQLException e)
		{
			throw new TradeDataNotGettingException("Trade Information is not getting from database");
			
		}
		
	
		return tradeList;
		
	}
	private static java.sql.Date convertUtilToSql(java.util.Date uDate) {
		java.sql.Date sDate = new java.sql.Date(uDate.getTime());
		return sDate;
	}


	//finding transaction by input date
	
	public List<Trade> findByDate(java.util.Date date) throws DateNotFoundException {
		//Connection connection = DBUtil.getConnection();
		String query;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		List<Trade> tradeList=null;
		
		try
		{

			query="select * from trade where trade_date =?";
			Date dateMy = convertUtilToSql(date);
			tradeList= new ArrayList<Trade>();
			//pstmt=connection.prepareStatement(query);
			pstmt.setDate(1,dateMy);
			rs= pstmt.executeQuery();
			
			while(rs.next())
			{
				
			Trade trade = new Trade();
			Customer custOne=new Customer();
			Shop shopOne=new Shop();
		
			trade.setId(rs.getInt("trade_id"));
			trade.setTotalPrice(rs.getDouble("total_price"));
			trade.setDate(rs.getDate("trade_date"));
			custOne.setCustId(rs.getString("cust_id_f"));
			shopOne.setShopId(rs.getInt("shop_id_f"));
			trade.setCustomer(custOne);
			trade.setShop(shopOne);
			tradeList.add(trade);

			/*int tradeId=rs.getInt("trade_id");
			Double totalPrice=rs.getDouble("total_price");
			Date tradeDate=rs.getDate("trade_date");
			String custIdF=rs.getString("cust_id_f");
			int shopIdF=rs.getInt("shop_id_f");
			System.out.format("%s    %s     %s   %s     %s\n",tradeId,totalPrice,tradeDate,custIdF,shopIdF);
			trade.setId(tradeId);
			trade.setTotalPrice(totalPrice);
			trade.setDate(tradeDate);
			custOne.setCustId(custIdF);
			shopOne.setShopId(shopIdF);
			
			trade.setCustomer(custOne);
			trade.setShop(shopOne);
			
			tradeList.add(trade);
			System.out.println();*/
		}
				
		}
		
		catch(SQLException e)
		{
			//e.printStackTrace();
			throw new DateNotFoundException("Date Not found exception");
			
		}
		return tradeList;
	}


	//finding transaction by input date and customer
	
	public List<Trade> findCustomerByDate(String custName, java.util.Date date) throws DataNotFoundException
	{
		//Connection connection = DBUtil.getConnection();
		String query;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		List<Trade> tradeList=null;
		
		try
		{
	
		query="select * from trade where trade_date =? and cust_id_f=?";
		Date dateMy = convertUtilToSql(date);
		tradeList= new ArrayList<Trade>();
		//pstmt=connection.prepareStatement(query);
		pstmt.setDate(1,dateMy);
		pstmt.setString(2,custName);
		rs= pstmt.executeQuery();
		
		while(rs.next())
		{
			
		Trade trade = new Trade();
		Customer custOne=new Customer();
		Shop shopOne=new Shop();
	
		trade.setId(rs.getInt("trade_id"));
		trade.setTotalPrice(rs.getDouble("total_price"));
		trade.setDate(rs.getDate("trade_date"));
		custOne.setCustId(rs.getString("cust_id_f"));
		shopOne.setShopId(rs.getInt("shop_id_f"));
		trade.setCustomer(custOne);
		trade.setShop(shopOne);
		tradeList.add(trade);
		}
		
		}
		
		catch(SQLException e)
		{
			throw new DataNotFoundException("Data not found");
			
		}
		
		return tradeList;
	}

}