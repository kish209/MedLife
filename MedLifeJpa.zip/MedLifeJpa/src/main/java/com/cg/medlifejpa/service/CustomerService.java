package com.cg.medlifejpa.service;


import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejpa.exceptions.CustomerNotSaveIntoDatabase;


public interface CustomerService{

	public Customer addCustomer(Customer customer) throws CustomerNotSaveIntoDatabase;
	public Customer searchById(String id) throws CustomerDetailsNotFoundException;
}