package com.cg.medlifejpa.dto;

import java.util.List;




import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="shop")
public class Shop 
{

	@Id
	@Column(name="shop_id")
	private int shopId;
	
	@Column(name="shop_name")
	private String shopName;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_id")
	private Address address;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="shop_id")
	private List<Medicine> medicines;
	
	//default constructor
	public Shop()
	{	}

	
	//parameterized constructor
	public Shop(int shopId, String shopName, Address address, List<Medicine> medicines) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.address = address;
		this.medicines = medicines;
	}

	public String toString() {
		return "Shop [shopId=" + shopId + ", shopName=" + shopName + ", address=" + address + ", medicines=" + medicines+ "]";
	}

	//getter setter
	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}					
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<Medicine> getMedicines() {
		return medicines;
	}
	public void setMedicines(List<Medicine> medicines) {
		this.medicines = medicines;
	}	
}