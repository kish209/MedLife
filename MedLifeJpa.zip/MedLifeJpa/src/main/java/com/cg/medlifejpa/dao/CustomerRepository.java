package com.cg.medlifejpa.dao;

import com.cg.medlifejpa.dto.Customer;

import com.cg.medlifejpa.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejpa.exceptions.CustomerNotSaveIntoDatabase;



public interface CustomerRepository {

	public Customer save(Customer customer) throws CustomerNotSaveIntoDatabase;
	public Customer findById(String id) throws CustomerDetailsNotFoundException;
}
