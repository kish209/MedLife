package com.cg.medlifejpa.dao;
import java.util.Date;
import java.util.List;

import com.cg.medlifejpa.dto.Trade;
import com.cg.medlifejpa.exceptions.DataNotFoundException;
import com.cg.medlifejpa.exceptions.DateNotFoundException;
import com.cg.medlifejpa.exceptions.TradeDataNotGettingException;
import com.cg.medlifejpa.exceptions.TradeNotSaveIntoDatabase;

public interface TradeRepository {

	public List<Trade> findByDate(Date date) throws DateNotFoundException;
	public List<Trade> findCustomerByDate(String custName, Date date) throws DataNotFoundException;
	public Trade saveTrade(Trade trade) throws TradeNotSaveIntoDatabase;
	public  List<Trade> showAll() throws TradeDataNotGettingException;
}