package com.cg.medlifejpa.service;


import com.cg.medlifejpa.dao.CustomerRepositoryImp;
import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejpa.exceptions.CustomerNotSaveIntoDatabase;

public class CustomerServiceImp implements CustomerService{

	Customer customerData;
	CustomerRepositoryImp customerrepository;
	public CustomerServiceImp(){
		customerrepository = new CustomerRepositoryImp();
	}

	public Customer addCustomer(Customer customer) throws CustomerNotSaveIntoDatabase{

		return customerrepository.save(customer);
	}

	public Customer searchById(String id) throws CustomerDetailsNotFoundException {
		if(customerrepository.findById(id)==null)
			throw new CustomerDetailsNotFoundException("Customer not found");
		return customerrepository.findById(id);
	}
}