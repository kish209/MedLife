package com.cg.medlifejpa.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import com.cg.medlifejpa.dto.Medicine;
import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.exceptions.MedicineNotFoundException;
import com.cg.medlifejpa.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;

public class ShopRepositoryImp implements ShopRepository{

	List<Medicine> medicineData;
	
	EntityManager em;
	Medicine medicine;
	public ShopRepositoryImp()
	{
		/*connection established*/
		em=DBUtil.em;
		medicineData = new ArrayList<Medicine>();
	}

	
	//saving shop into database
	
	public Shop save(Shop shop) throws ShopNotSaveIntoDatabase {
		try	
		{	
		
		em.getTransaction().begin();
		em.persist(shop);
		em.getTransaction().commit();
		return  shop;
		}
		
		/*Handling exception*/
		catch(Exception e)
		{
			throw new ShopNotSaveIntoDatabase("Shop not save into database");
		}
	
	}

	
	//finding medicine name
	
	public List<Shop> findByName(String medicineNameOne) throws MedicineNotFoundException {
		List <Medicine> medicineList = new ArrayList<Medicine>();
		List <Shop> shopListOne = new ArrayList<Shop>();
		List <Shop> shopList = new ArrayList<Shop>();
		try	
		{	
		
		
		/*showing shops with using specific medicine name*/
		TypedQuery<Shop> query = em.createQuery("select c from Shop c", Shop.class);
		shopList = query.getResultList();
		
		for (Shop shop : shopList) {
			medicineList=shop.getMedicines();
			for (Medicine medicineOne : medicineList) {
				if(medicineNameOne.equals(medicineOne.getMedicineName())) {
					shopListOne.add(shop);
					
				}
			}
		}
		}
		
		/*Handling exception*/
		catch(Exception e)
		{
			throw new MedicineNotFoundException("Medicine not found");
			
		}
		
		
		return shopListOne;
	}
}