package com.cg.medlifejpa.dao;
import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.medlifejpa.dto.Address;
import com.cg.medlifejpa.dto.Medicine;
import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.exceptions.MedicineNotFoundException;
import com.cg.medlifejpa.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;

public class ShopRepositoryImp implements ShopRepository{

	List<Medicine> medicineData;
	String query = null;
	Connection connection =null;
	PreparedStatement pstmt=null;
	ResultSet result=null;
	Medicine medicine;
	public ShopRepositoryImp()
	{

		medicineData = new ArrayList<Medicine>();
	}

	
	//saving shop into database
	
	public Shop save(Shop shop) throws ShopNotSaveIntoDatabase {
		connection = DBUtil.getConnection();
		try	
		{		
			query="insert into shop(shop_id,shop_name) values(?,?)";
			pstmt=connection.prepareStatement(query);
			pstmt.setInt(1, shop.getShopId());
			pstmt.setString(2, shop.getShopName());
			pstmt.executeUpdate();
	
			query="insert into address(house_no,house_area,city,pincode,shop_id_f) values(?,?,?,?,?)";
			pstmt=connection.prepareStatement(query);
			pstmt.setString(1, shop.getAddress().getHouseNumber());
			pstmt.setString(2, shop.getAddress().getArea());
			pstmt.setString(3, shop.getAddress().getCity());
			pstmt.setLong(4, shop.getAddress().getPincode());
			pstmt.setInt(5, shop.getShopId());
			pstmt.executeUpdate();
			
			query="insert into medicine(medicine_name,medicine_type,medicine_price,shop_id_f) values(?,?,?,?)";
			
			for (Medicine medicine : shop.getMedicines()) {
				pstmt=connection.prepareStatement(query);
				pstmt.setString(1, medicine.getMedicineName());
				pstmt.setString(2, medicine.getMedicineType());
				pstmt.setDouble(3, medicine.getMedicinePrice());
				pstmt.setInt(4, shop.getShopId());
				pstmt.executeUpdate();
			}
			return shop;
			
		}
		catch(SQLException e)
		{
			throw new ShopNotSaveIntoDatabase("Shop not save into database");
		}
		
		//return  null;
	}

	
	//finding medicine name
	
	public List<Shop> findByName(String medicineNameOne) throws MedicineNotFoundException {
		connection = DBUtil.getConnection();
		String query_select =null;
		try
		
		{		
			query_select="select shop_id_f from medicine where medicine_name=?";
			pstmt=connection.prepareStatement(query_select);
			pstmt.setString(1, medicineNameOne);
			result = pstmt.executeQuery();
			
			List<Shop> shopOne = new ArrayList<Shop>();
			while(result.next())
					{
			int shopId=result.getInt(1);
			Shop shop= new Shop();
			query_select="select shop_id,shop_name,house_no,house_area,city,pincode from shop inner join address on shop.shop_id=address.shop_id_f where shop_id =?";	
			pstmt=connection.prepareStatement(query_select);
			pstmt.setInt(1, shopId);
			ResultSet rs=pstmt.executeQuery();
			
			
			
			while(rs.next()) 
			{
				List<Medicine> medicines =  new ArrayList<Medicine>();
				
				query_select="select medicine_name,medicine_type,medicine_price from medicine inner join shop on medicine.shop_id_f=shop.shop_id where shop_id =?";
				pstmt=connection.prepareStatement(query_select);
				pstmt.setInt(1, shopId);
				ResultSet rss=pstmt.executeQuery();
				
				while(rss.next())
				{
			shop.setShopId(rs.getInt(1));	
			shop.setShopName(rs.getString(2));
			
			Address address=new Address(rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getLong(7));		
			Medicine medicineOne = new Medicine(rss.getString(1), rss.getString(2), rss.getDouble(3));
			
			shop.setAddress(address);
			medicines.add(medicineOne);
				}
			shop.setMedicines(medicines);
			
			shopOne.add(shop);	
			}	
			}return shopOne;	
		}
		catch(SQLException e)
		{
			throw new MedicineNotFoundException("Medicine not found");
			
		}
		
		
		//return null;
	}
}