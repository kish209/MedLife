package com.cg.medlifejpa.dao;
import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import com.cg.medlifejpa.dto.Address;
import com.cg.medlifejpa.dto.Medicine;
import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.exceptions.MedicineNotFoundException;
import com.cg.medlifejpa.exceptions.ShopNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;

public class ShopRepositoryImp implements ShopRepository{

	List<Medicine> medicineData;
	
	EntityManager em;
	Medicine medicine;
	public ShopRepositoryImp()
	{
		em=DBUtil.em;
		medicineData = new ArrayList<Medicine>();
	}

	
	//saving shop into database
	
	public Shop save(Shop shop) throws ShopNotSaveIntoDatabase {
		
		em.getTransaction().begin();
		em.persist(shop);
		em.getTransaction().commit();
		return  null;
	}

	
	//finding medicine name
	
	public List<Shop> findByName(String medicineNameOne) throws MedicineNotFoundException {
		//connection = DBUtil.getConnection();
	
		
		return null;
	}
}