package com.cg.medlifeangular.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifeangular.dao.TradeRepository;
import com.cg.medlifeangular.dto.Trade;
@Service
public class TradeServiceImp implements TradeService {

	public TradeServiceImp() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	TradeRepository repository;
	
	static final Logger logger = Logger.getLogger(TradeServiceImp.class); 

	public List<Trade> searchByDate(Date date) {

		return repository.findByDate(date);
	}

	public List<Trade> searchCustomerByDate(String custId, Date date) {

		return repository.findCustomerBydate(custId, date);
	}


	
	
	public List<Trade> showTrade()
	{
		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");
		

		return repository.findAll();
	}


	public Trade addTrade(Trade trade){
	
		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");
		Trade tradeO=repository.save(trade);
		
		return tradeO;
	}


	@Override
	public Trade searchById(int id) {
		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");
		
		// TODO Auto-generated method stub
		return repository.findByid(id);
	}


	@Override
	public int updateAddress(int mn, int sid, int tradeId) {
		// TODO Auto-generated method stub
		return repository.updateAddress(mn, sid, tradeId);
	}


	
}