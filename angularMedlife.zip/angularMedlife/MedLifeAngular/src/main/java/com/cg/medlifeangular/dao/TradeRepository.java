package com.cg.medlifeangular.dao;
import java.util.Date;
import java.util.List;

import org.hibernate.validator.constraints.ParameterScriptAssert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.medlifeangular.dto.Trade;


/*
 * TradeRepository interface Repository
 *@author: Kishor Nivalkar
 *@since: 2019-05-23
 */

public interface TradeRepository  extends JpaRepository<Trade, Integer>{

	@Modifying
	@Query("update Medicine c SET c.trade.id=:tradeId where c.medicineId=:mn and c.shop.shopId=:sid")
	public int updateAddress(@Param("mn") int mn, @Param("sid") int sid, @Param("tradeId") int tradeId);
	
	
	//@Query("FROM Trade WHERE date=:tdate")
	//@Query("SELECT date, id, totalPrice from Trade a JOIN a.customer WHERE date=:tdate")
	public List<Trade> findByDate(@Param("tdate") Date date) ;
	
	//@Query("select c from Customer c where c.custId=?1")
	//@Query("select c from Trade c where c.Customer.custId=?2 and date=?1")
/*	@Query("select c from Trade c where c.custId = :#{#customer.custId} and date=:date")
	public List<Trade> findCustomerBydate(@Param("customer") String custId,@Param("trade") Date date) ;
	*/
	
	@Query("SELECT at FROM  Trade at JOIN at.customer a WHERE a.custId=:customer AND at.date=:date")
	List<Trade> findCustomerBydate(@Param("customer") String custId,@Param("date") Date date);
	
	
/*
	@Query("SELECT at FROM  AccountTransaction at JOIN at.savingsAccount a WHERE a.accountNumber=:account AND at.transactionDate=:date")
	List<AccountTransaction> find(@Param("account") Integer accountNumber,@Param("date") Date startDate);
	*/
	
	/*
	 * findByid: for finding the trade id
	 * return: trade corresponding to the id
	 *@author: Kishor Nivalkar
	 *@since: 2019-05-23
	 */
	
	public Trade findByid(int id);
}