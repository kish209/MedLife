package com.cg.medlifeangular.exception;

public class ShopFoundException extends RuntimeException {
public ShopFoundException() {
	// TODO Auto-generated constructor stub
}

public ShopFoundException(String msg) {
	// TODO Auto-generated constructor stub
	super(msg);
}
}
