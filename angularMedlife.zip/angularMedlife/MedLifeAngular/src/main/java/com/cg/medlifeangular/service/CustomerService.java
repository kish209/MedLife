package com.cg.medlifeangular.service;


import java.util.List;

import com.cg.medlifeangular.dto.Customer;


public interface CustomerService{

	public Customer addCustomer(Customer customer);
	public Customer searchById(String id);
	public List<Customer> showAll();
}