package com.cg.medlifeangular.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.medlifeangular.dto.Medicine;
import com.cg.medlifeangular.dto.Shop;
import com.cg.medlifeangular.dto.Trade;

public interface MedicineRepository extends JpaRepository<Medicine, Integer> {

	/*
	 * findBymedicineId: for finding the Medicine id
	 * return: shop corresponding to the id
	 *@author: Kishor Nivalkar
	 *@since: 2019-05-23
	 */
	public Medicine findBymedicineId(int id);
}
