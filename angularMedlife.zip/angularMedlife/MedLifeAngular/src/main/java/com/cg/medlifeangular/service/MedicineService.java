package com.cg.medlifeangular.service;

import com.cg.medlifeangular.dto.Medicine;

public interface MedicineService {

	public Medicine searchByMedicineId(int id);
}
