package com.cg.medlifeangular.service;

import java.util.List;

import com.cg.medlifeangular.dto.Shop;

public interface ShopService {
public Shop addShop(Shop shop) ;
public Shop searchById(int id);
public List<Shop> searchByMedicine(String medicineName);
public List<Shop> showAll();
}