package com.cg.medlifeangular.service;


import java.util.List;



import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medlifeangular.dao.CustomerRepository;
import com.cg.medlifeangular.dto.Customer;
import com.cg.medlifeangular.exception.CustomerAlreadyExistsException;
import com.cg.medlifeangular.exception.CustomerNotFoundException;



/*
 * CustomerService Service class implemented
 *@author: Kishor Nivalkar
 *@since: 2019-05-23
 */

@Transactional
@Service
public class CustomerServiceImp implements CustomerService{

	@Autowired
	CustomerRepository customerrepository;
	
	static final Logger logger = Logger.getLogger(CustomerServiceImp.class); 
	
	//static int countAddress=200;
	public CustomerServiceImp(){
	
	}

	
	/*
	 * addid: for adding the customer
	 *@Exception: throws exception if already exist customer then pass already exist customer id
	 *@author: Kishor Nivalkar
	 *@since: 2019-05-23
	 */
	public Customer addCustomer(Customer customer) throws CustomerNotFoundException {
		Customer cust = customerrepository.save(customer);
		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");
		if(cust==null)
			throw new CustomerNotFoundException("Customer not added..");
		logger.info("Adding customer.!!!!");
		return cust;
	}



	/*
	 * searchById: for finding the id
	 * @Exception: throws exception if id not found to controller then pass id not found exception
	 *@author: Kishor Nivalkar
	 *@since: 2019-05-23
	 */
	public Customer searchById(String id) {

		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");
			Customer cust1 =customerrepository.findBycustId(id);
		
		logger.info("searching by customer Id.!!!!");
		return cust1;
	}

	
	
	/*
	 * showAll: for finding the id
	 *@author: Kishor Nivalkar
	 *@since: 2019-05-23
	 */
	
	@Override
	public List<Customer> showAll() {
		
		PropertyConfigurator.configure("D:\\javastsnew\\MedLifeSpringBoot\\src\\main\\resources\\log4j.properties");
		
		
		 logger.info("Show All..!!!!");
		// TODO Auto-generated method stub
		return customerrepository.findAll();
	}


}