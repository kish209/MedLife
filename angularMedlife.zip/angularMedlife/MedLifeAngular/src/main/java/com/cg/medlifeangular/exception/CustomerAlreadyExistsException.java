package com.cg.medlifeangular.exception;

public class CustomerAlreadyExistsException extends RuntimeException {
public CustomerAlreadyExistsException() {
	// TODO Auto-generated constructor stub
}
public CustomerAlreadyExistsException(String msg) {
	// TODO Auto-generated constructor stub
	super(msg);
}
}
