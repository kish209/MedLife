import {Component} from '@angular/core';

export class Medicine{

    medicinename:string;
    medicineprice:number;
    medicinetype:string;
    
} 
 
