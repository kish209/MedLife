package com.cg.medlifejpa.exceptions;
public class CustomerDetailsNotFoundException extends Exception{
	public CustomerDetailsNotFoundException() 
	{}
	
	public CustomerDetailsNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}