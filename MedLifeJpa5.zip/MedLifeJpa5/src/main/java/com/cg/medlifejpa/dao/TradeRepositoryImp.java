package com.cg.medlifejpa.dao;
import java.sql.Connection;



import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.dto.Medicine;
import com.cg.medlifejpa.dto.Shop;
import com.cg.medlifejpa.dto.Trade;
import com.cg.medlifejpa.exceptions.DataNotFoundException;
import com.cg.medlifejpa.exceptions.DateNotFoundException;
import com.cg.medlifejpa.exceptions.TradeDataNotGettingException;
import com.cg.medlifejpa.exceptions.TradeNotSaveIntoDatabase;
import com.cg.medlifejpa.util.DBUtil;

import javassist.expr.NewArray;
public class TradeRepositoryImp implements TradeRepository{

	/*connection established*/
	EntityManager em;

	/*saving transaction into database*/

	public Trade saveTrade(Trade trade) throws TradeNotSaveIntoDatabase {
		try	
		{
			em=DBUtil.em;
			em.getTransaction().begin();
			
			/*data adding into trade table*/
			em.persist(trade);	
			em.getTransaction().commit();
			return  trade;

		
			/*	TypedQuery<Trade> query = em.createQuery("select c id from trade c  where c.id=:?",Trade.class);
		System.out.println("before get");
		System.out.println(trade.getId());
		//query.setParameter(1, trade.getId());
		trade=query.getSingleResult();
		System.out.println("before");
			 */
			//em.merge(trade);
			/*TypedQuery<Medicine> queryOne = em.createQuery("update Medicine c SET c.id=:? where c.medicineName=:? and c.shopId=:?",Medicine.class);
		queryOne.executeUpdate();
		trade=query.getSingleResult();
		System.out.println("after");
		/*for (Medicine medicine : trade.getMedicines()) {
			queryOne.setParameter(1, medicine.getTrade().getId());
			queryOne.setParameter(2, medicine.getMedicineName());
			queryOne.setParameter(3, medicine.getShop().getShopId());
			queryOne.executeUpdate();
		}*/

			
		}
		
		/*Handling exception*/
		catch(Exception e)
		{
			throw new TradeNotSaveIntoDatabase("Enter Information is not save in trade");

		}

	}


	//showing transaction
	public List<Trade> showAll() throws TradeDataNotGettingException 
	{
		List<Trade> tradeList = new ArrayList<Trade>();
		try
		{	
			/*showing trade from trade*/
			TypedQuery<Trade> query = em.createQuery("select c from Trade c",Trade.class);
			tradeList=query.getResultList();
			
		}
		
		/*Handling exception*/
		catch(Exception e)
		{
			throw new TradeDataNotGettingException("Trade Information is not getting from database");
		}
		return tradeList;
		

	}
	


	//finding transaction by input date

	public List<Trade> findByDate(java.util.Date date) throws DateNotFoundException
	{
		List<Trade> tradeList = new ArrayList<Trade>();
		Customer customer = new  Customer();
		try
		{
			/*showing transaction from specific date*/
			
			TypedQuery<Trade> query = em.createQuery("select t from Trade t where date=?", Trade.class);
			query.setParameter(1, date);
			tradeList=query.getResultList();
		}
		/*Handling exception*/
		catch(Exception e)
		{
			throw new DateNotFoundException("Date Not found exception");	
		}
		return tradeList;
	}


	//finding transaction by input date and customer

	public List<Trade> findCustomerByDate(String custId, java.util.Date date) throws DataNotFoundException
	{
		List<Customer> customerListOne = new ArrayList<Customer>();
		List<Trade> tradeList = new ArrayList<Trade>();
		List<Trade> tradeListOne = new ArrayList<Trade>();
		Customer customer = new  Customer();
		try
		{	
			/*showing transaction from specific date and customer id */
			
			TypedQuery<Trade> query = em.createQuery("select t from Trade t", Trade.class);
			tradeList=query.getResultList();
			for (Trade tradeOne : tradeList) {
				customer=tradeOne.getCustomer();
				if(tradeOne.getDate().equals(date) && customer.getCustId().equals(custId))
				{
					tradeListOne.add(tradeOne);
				}
			}
		}
		/*Handling exception*/
		catch(Exception e)
		{
			throw new DataNotFoundException("Data not found");

		}
		return tradeListOne;
	}

}