package com.cg.medlifejpa.util;


import javax.persistence.EntityManager;
import javax.persistence.Persistence;


public class DBUtil 
{	
	public static EntityManager em =Persistence.createEntityManagerFactory("medlife").createEntityManager();
	
	
}
