package com.cg.medlifejpa.service;


import com.cg.medlifejpa.dao.CustomerRepositoryImp;
import com.cg.medlifejpa.dto.Customer;
import com.cg.medlifejpa.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejpa.exceptions.CustomerNotSaveIntoDatabase;

public class CustomerServiceImp implements CustomerService{

	Customer customerData;
	CustomerRepositoryImp customerrepository;
	//static int countAddress=200;
	public CustomerServiceImp(){
		customerrepository = new CustomerRepositoryImp();
	}

	public Customer addCustomer(Customer customer) throws CustomerNotSaveIntoDatabase{

	/*	customer.getAddress().setAddressId(countAddress);
		countAddress++;*/
		if(customerrepository.save(customer)==null)
			throw new CustomerNotSaveIntoDatabase("customer not save in database");
		return customerrepository.save(customer);
	}

	public Customer searchById(String id) throws CustomerDetailsNotFoundException {
		if(customerrepository.findById(id)==null)
			throw new CustomerDetailsNotFoundException("Customer not found");
		return customerrepository.findById(id);
	}
}