import { Component,OnInit} from "@angular/core";
import { MedlifeService } from "./app.medlifeservice";

@Component({
selector:'show-cust',
templateUrl:'app.showcustomer.html'



})




export class ShowCustomer implements OnInit{

    customers:ShowCustomer[];

model : any={};
constructor(private medlifeservice:MedlifeService){}
    

ngOnInit(){
    this.medlifeservice.getAllProduct().subscribe((data:ShowCustomer[])=>this.customers=data);
}
}