﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { Customer }  from './app.customer';
import { ShowCustomer }  from './app.showcustomer';
import { UpdateProduct }  from './app.updateproduct';
import { SearchProduct }  from './app.searchproduct';
import {FormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
import { AddCustomerComponent } from './app.addcustomercomponent';
import {HttpClientModule} from '@angular/common/http';
import { AddShopComponent } from './app.addshopcomponent';


const route:Routes=[
 
    
{path:'addcust',component:AddCustomerComponent},
{path:'show',component:ShowCustomer},
{path:'addshop',component:AddShopComponent},
{path:'update',component:UpdateProduct},
{path:'search',component:SearchProduct},
{path:'search/:id',component:SearchProduct}

];

@NgModule({
    imports: [
        BrowserModule,RouterModule.forRoot(route),HttpClientModule,
        FormsModule
        
    ],
    declarations: [
        AppComponent,AddCustomerComponent,ShowCustomer,AddShopComponent,UpdateProduct,SearchProduct
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }