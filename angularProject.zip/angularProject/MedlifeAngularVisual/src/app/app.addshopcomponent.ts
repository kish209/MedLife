import { Component,OnInit} from "@angular/core";
import { MedlifeService } from "./app.medlifeservice";
import { Shop } from "./app.shop";
import { FormsModule }  from '@angular/forms';



@Component({
selector:'cust-app',
templateUrl:'app.addcustomer.html'

})
export class AddShopComponent implements OnInit{

    shops:Shop[];

model : any={};
constructor(private medlifeservice:MedlifeService){}
    

ngOnInit(){
    this.medlifeservice.getAllProduct().subscribe((data:Shop[])=>this.shops=data);
}

addShop(){
    //console.log(this.model);
    this.medlifeservice.addAllShop(this.model).subscribe((data:any)=>console.log(data));
}


}