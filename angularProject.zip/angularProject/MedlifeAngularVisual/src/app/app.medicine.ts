import {Component} from '@angular/core';

export class Medicine{

    name:string;
    price:number;
    type:string;
    
} 
 
