package com.cg.medlifeangular.controller;

import java.text.ParseException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.cg.medlifeangular.dto.Address;
import com.cg.medlifeangular.dto.Customer;
import com.cg.medlifeangular.dto.Medicine;
import com.cg.medlifeangular.dto.SearchDetailsForCustomer;
import com.cg.medlifeangular.dto.Shop;
import com.cg.medlifeangular.dto.Trade;
import com.cg.medlifeangular.exception.CustomerNotFoundException;
import com.cg.medlifeangular.exception.ShopFoundException;
import com.cg.medlifeangular.service.CustomerService;
import com.cg.medlifeangular.service.ShopService;
import com.cg.medlifeangular.service.TradeService;

/*
 * RestController: It is the controller which tells us that this is the Restful web service and it controls all the request 
 * return: it returns the response according to the requested uri
 *@author: Kishor Nivalkar
 *@since: 2019-05-23
 */

/*
 * @RestController: it tells the despathcer servlet that this is the Restcontroller
 * @RequestMapping: it contains the '/' and name that is nothing but the uri to reach to the all Restcontroller's methods
 * return: it returns the response according to the requested uri
 *@since: 2019-05-23
 */

@RestController
@RequestMapping("/medlife")
@CrossOrigin(origins = "http://localhost:4200")  
public class MedLifeController {

	/*
	 * @Autowired: it is used to inject the class to get the properties services: we
	 * have included the list of Autowire classes return: it returns the 1service
	 * class of corresponding object
	 * 
	 * @since: 2019-05-23
	 */

	/*
	 * @Autowired: it is used to inject the CustomerService class, ShopService,
	 * TradeService to get its properties return: it returns the CustomerService
	 * class, ShopService, TradeService class of corresponding object
	 * 
	 * @since: 2019-05-23
	 */

	@Autowired
	CustomerService customerservice;
	@Autowired
	ShopService shopservice;
	@Autowired
	TradeService tradeservice;
	Date date1 = new Date();
	Customer customer;

	/*
	 * addcustomer mthod addowner: it is the uri though which we can reach to this
	 * method return: it returns the response of corresponding object
	 * 
	 * @since: 2019-05-23
	 */

	@RequestMapping(value = "/addcustomer", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Customer> addCustomer(@ModelAttribute Customer cust) {
		System.out.println(cust);
		// Customer customer = null;

		/*
		 * customerservice method Searchbyid: this method is to find the Customer object
		 * return: it returns the service object for checking the duplicate customer
		 * 
		 * @since: 2019-05-23
		 */

		Customer custOne = customerservice.searchById(cust.getCustId());
		System.out.println(custOne);
		if (custOne != null) {
			return new ResponseEntity("Customer Already Exist..", HttpStatus.NOT_FOUND);
		} else {

			/*
			 * customerservice method add mthod: once the object is ready and we are passing
			 * it into the parameterlist of add method for adding customer customer: we are
			 * saving the added data to customer
			 * 
			 * @since: 2019-05-23
			 */

			customer = customerservice.addCustomer(cust);
			if (customer == null) {
				return new ResponseEntity("Customer not added", HttpStatus.NOT_FOUND);
			}

		}

		/*
		 * @ResponseEntity: its giving response to corresponding to the Customer object
		 * 
		 * @since: 2019-05-23
		 */
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}

	@RequestMapping(value = "/showcustomer", method = RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Customer>> showAllCustomer() {

		List<Customer> myList = customerservice.showAll();
		if (myList.isEmpty()) {
			return new ResponseEntity("No Customer to show", HttpStatus.NOT_FOUND);
		}

		/*
		 * showcustomer mthod showcustomer: it is the uri though which we can reach to
		 * this method to show shop return: customer list
		 * 
		 * @since: 2019-05-23
		 */
		return new ResponseEntity<List<Customer>>(myList, HttpStatus.OK);
	}

	/*
	 * addshop mthod addshop: it is the uri though which we can reach to this method
	 * return: it returns the response of corresponding object
	 * 
	 * @since: 2019-05-23
	 */

	@RequestMapping(value = "/addshop", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Shop> addShop(@ModelAttribute("shop") Shop sh) {
		System.out.println(sh);
		Shop shop = null;

		/*
		 * shopservice method Searchbyid: this method is to find the Shop object return:
		 * it returns the service object for checking the duplicate shop
		 * 
		 * @since: 2019-05-23
		 */

		Shop shOne = shopservice.searchById(sh.getShopId());
		if (shOne != null) {
			return new ResponseEntity("Shop Already Exist..", HttpStatus.NOT_FOUND);
		} else {

			/*
			 * shopservice method add mthod: once the object is ready and we are passing it
			 * into the parameterlist of add method for adding shop shop: we are saving the
			 * added data to shop
			 * 
			 * @since: 2019-05-23
			 */
			shop = shopservice.addShop(sh);
			if (shop == null) {
				return new ResponseEntity("shop not added", HttpStatus.NOT_FOUND);
			}

		}

		/*
		 * @ResponseEntity: its giving response to corresponding to the Customer object
		 * 
		 * @since: 2019-05-23
		 */
		return new ResponseEntity<Shop>(shop, HttpStatus.OK);
	}

	/*
	 * showshop mthod showshop: it is the uri though which we can reach to this
	 * method to show shop return: shop list
	 * 
	 * @since: 2019-05-23
	 */
	@RequestMapping(value = "/showshop", method = RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Shop>> showAllShop() {

		List<Shop> myList = shopservice.showAll();
		if (myList.isEmpty()) {
			return new ResponseEntity("No Shop to show..", HttpStatus.NOT_FOUND);
		}

		/*
		 * @ResponseEntity: its giving response to corresponding to the shop object
		 * 
		 * @since: 2019-05-23
		 */
		return new ResponseEntity<List<Shop>>(myList, HttpStatus.OK);
	}

	/*
	 * @RequestMapping(value="/searchcust",method=RequestMethod.GET)
	 * 
	 * public ResponseEntity<Customer> searchcust(@ModelAttribute("customer")
	 * Customer custId){
	 * 
	 * Customer myList=customerservice.searchById(custId.getCustId());
	 * System.out.println(myList); if(myList==null) { return new
	 * ResponseEntity("No customer search to show..", HttpStatus.NOT_FOUND); }
	 * return new ResponseEntity<Customer> (myList, HttpStatus.OK); }
	 * 
	 * @RequestMapping(value="/searchcust/searchmed",method=RequestMethod.GET)
	 * 
	 * public ResponseEntity<List<Shop>> searchMed(@ModelAttribute("medicine")
	 * Medicine med){ Shop shop = new Shop(); List<Shop> myList; List<Medicine>
	 * myListM= new ArrayList<Medicine>(); Medicine medi = new Medicine();
	 * 
	 * myList=shopservice.searchByMedicine(med.getMedicineName());
	 * 
	 * 
	 * med.setMedicineId(medi.getMedicineId());
	 * med.setMedicineName(medi.getMedicineName());
	 * med.setMedicineType(medi.getMedicineType());
	 * med.setMedicinePrice(medi.getMedicinePrice());
	 * 
	 * shop.setMedicines(myListM);
	 * 
	 * 
	 * if(myList.isEmpty()) { return new ResponseEntity("No medicine to show",
	 * HttpStatus.NOT_FOUND); } return new ResponseEntity<List<Shop>> (myList,
	 * HttpStatus.OK); }
	 * 
	 * 
	 * @RequestMapping(value="/searchcust/searchmed/addtrade",method=RequestMethod.
	 * POST) public ResponseEntity<Trade> addTrade(@ModelAttribute Trade tr ) throws
	 * ParseException {
	 * 
	 * 
	 * System.out.println(tr); Trade trade = null; Customer c = new Customer();
	 * Address add = new Address(); Shop shop= new Shop(); Trade tradeOne =
	 * tradeservice.searchById(tr.getId()); if(tradeOne!=null) { return new
	 * ResponseEntity("Trade Already Exist..", HttpStatus.NOT_FOUND); } else { Shop
	 * shop1 = shopservice.searchById(shop.getShopId());
	 * 
	 * 
	 * 
	 * SimpleDateFormat formatDate = new SimpleDateFormat("dd-MM-yyyy"); String
	 * strDate= formatDate.format(date1); Date currentDate=
	 * formatDate.parse(strDate); //Date date1 = null; //date1=(Date)
	 * dateFormat.parse(date); tr.setDate(currentDate);
	 * c.setCustId(customer.getCustId()); c.setCustName(customer.getCustName());
	 * c.setContact(customer.getContact()); c.setContact(customer.getContact());
	 * add.setHouseNumber(customer.getAddress().getHouseNumber());
	 * add.setArea(customer.getAddress().getArea());
	 * add.setCity(customer.getAddress().getCity());
	 * add.setPincode(customer.getAddress().getPincode()); c.setAddress(add);
	 * tr.setCustomer(c);
	 * tr.setTotalPrice(shop1.getMedicines().get(0).getMedicinePrice());
	 * 
	 * tr.setShop(shop1);
	 * 
	 * tr.setCustomer(customer); trade=tradeservice.addTrade(tr); if(trade==null) {
	 * return new ResponseEntity("Trade not added", HttpStatus.NOT_FOUND); }
	 * 
	 * } return new ResponseEntity<Trade>(trade, HttpStatus.OK); }
	 */

	/*
	 * shopservice method searchmedi : is the uri Searchbyid: this method is to find
	 * the List of shop return: it returns the service object for checking the
	 * duplicate shop
	 * 
	 * @since: 2019-05-23
	 */

	@RequestMapping(value = "/searchmedi", method = RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Shop>> search(@RequestParam("customer") Customer customer,
			@RequestParam("medicine") String medicine) {
		/*
		 * customerservice method Searchbyid: this method is to find the Customer object
		 * return: it returns the service object for checking the duplicate customer
		 * 
		 * @since: 2019-05-23
		 */

		Customer custOne = customerservice.searchById(customer.getCustId());

		System.out.println(custOne.toString());
		if (custOne == null) {
			return new ResponseEntity("No customer search to show..", HttpStatus.NOT_FOUND);
		}

		// Shop shop = null;

		System.out.println(medicine);

		List<Shop> myList = new ArrayList<>();

		/*
		 * shopservice method searchByMedicine: this method is to find the Medicine
		 * object return: it return the list of shop
		 * 
		 * @since: 2019-05-23
		 */
		myList = shopservice.searchByMedicine(medicine);

		if (myList.isEmpty()) {
			return new ResponseEntity("No medicine to show", HttpStatus.NOT_FOUND);
		}

		/*
		 * @ResponseEntity: its giving response to corresponding to the Customer object
		 * 
		 * @since: 2019-05-23
		 */
		return new ResponseEntity<List<Shop>>(myList, HttpStatus.OK);
	}

	/*
	 * trade method trade: it is the uri though which we can reach to this method
	 * return: it returns the response of corresponding object
	 * 
	 * @since: 2019-05-23
	 */

	@RequestMapping(value = "/trade", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Trade> trade(@RequestParam("customer") String custId,
			@RequestParam("medicine") double totalPrice, @RequestParam("medicineOne") int medicineId,
			@RequestParam("shop") int shopId, @ModelAttribute("searchDetails") SearchDetailsForCustomer details) {
		Customer customer = new Customer();
		customer.setCustId(custId);

		/*
		 * Shop shop = new Shop(); shop.setShopId(shopId);
		 */
		Shop shop = shopservice.searchById(shopId);

		/*
		 * Medicine medicienOne = new Medicine(); medicienOne.setMedicineId(medicineId);
		 * medicienOne.setShop(shop);
		 */

		// List<Medicine> med=new ArrayList<>();
		// med.add(medicienOne);
		Trade tradeOne = new Trade();
		// tradeOne.setId(1009);
		// tradeOne.setShop(shop);
		tradeOne.setDate(new Date());
		tradeOne.setTotalPrice(totalPrice);
		tradeOne.setCustomer(customer);

		// tradeOne.setMedicine(med);
		tradeOne.setShop(shop);

		// List<Trade> tradeList=new ArrayList<Trade>();
		// tradeList.add(tradeOne);
		// Customer customer=new Customer();
		// customer.setCustId(custId);
		// customer.setTrade(tradeList);
		/*
		 * tradeservice method add method: once the object is ready and we are passing
		 * it into the parameterlist of add method for adding trade into trade reade: we
		 * are saving the added data to trade
		 * 
		 * @since: 2019-05-23
		 */
		// Trade t11 = new Trade();
		System.out.println(tradeOne);
		tradeservice.addTrade(tradeOne);
		// tradeservice.updateAddress(tradeOne.getShop().getMedicines().get(0).getMedicineId(),
		// shop.getShopId(), tradeOne.getId());

		/*
		 * @ResponseEntity: its giving response to corresponding to the trade object
		 * 
		 * @since: 2019-05-23
		 */
		return new ResponseEntity<Trade>(tradeOne, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchdate", method = RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Trade>> searchByDate(@RequestParam("date") String date) throws ParseException {
		/*
		 * searchByDate: this method is to find the trade object return: it returns
		 * trade List
		 * 
		 * @since: 2019-05-25
		 */

		SimpleDateFormat formatDate = new SimpleDateFormat("dd-MM-yyyy");
		Date currentDate = formatDate.parse(date);

		List<Trade> tradeOne = tradeservice.searchByDate(currentDate);

		if (tradeOne.isEmpty()) {
			return new ResponseEntity("No medicine to show", HttpStatus.NOT_FOUND);
		}

		/*
		 * @ResponseEntity: its giving response to corresponding to the Trade object
		 * 
		 * @since: 2019-05-23
		 */
		return new ResponseEntity<List<Trade>>(tradeOne, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchcustdate", method = RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Trade>> searchByCustDate(@RequestParam("customer") String custId,
			@RequestParam("date") String date) throws ParseException {
		/*
		 * searchByDate: this method is to find the trade object return: it returns
		 * trade List
		 * 
		 * @since: 2019-05-25
		 */

		SimpleDateFormat formatDate = new SimpleDateFormat("dd-MM-yyyy");
		Date currentDate = formatDate.parse(date);

		List<Trade> tradeOne = tradeservice.searchCustomerByDate(custId, currentDate);

		if (tradeOne.isEmpty()) {
			return new ResponseEntity("No Transaction to show", HttpStatus.NOT_FOUND);
		}

		/*
		 * @ResponseEntity: its giving response to corresponding to the Trade object
		 * 
		 * @since: 2019-05-23
		 */
		return new ResponseEntity<List<Trade>>(tradeOne, HttpStatus.OK);
	}

	@RequestMapping(value = "/particulardate", produces = "application/json", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public List<Trade> getTrade(@RequestParam("customer") String custId, @RequestParam("date") String date)
			throws ParseException {
		// String sDate1=date;
		// Date date1=null;

		SimpleDateFormat date1 = new SimpleDateFormat("dd/MM/yyyy");
		Date currentDate = date1.parse(date);
		// System.out.println(sDate1+"\t"+date1);
		return tradeservice.searchCustomerByDate(custId, currentDate);

	}

	@ExceptionHandler({ CustomerNotFoundException.class })
	public ResponseEntity CustomerNotFoundException(CustomerNotFoundException be) {

		return new ResponseEntity(be.getMessage(), HttpStatus.NOT_FOUND);
	}

	
	@ExceptionHandler({ ShopFoundException.class })
	public ResponseEntity ShopFoundException(ShopFoundException be) {

		return new ResponseEntity(be.getMessage(), HttpStatus.NOT_FOUND);
	}



}
