package com.cg.medlifeangular.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.medlifeangular.dto.Customer;
import com.cg.medlifeangular.dto.Shop;



/*
 * ShopRepository interface Repository
 *@author: Kishor Nivalkar
 *@since: 2019-05-23
 */
public interface ShopRepository extends JpaRepository<Shop, Integer> {

	@Query("FROM Shop s, IN (s.medicines) m WHERE m.medicineName=:name")
	public List<Shop> findBymedicineName(@Param("name") String name);

	
	/*
	 * findByshopId: for finding the shop id
	 * return: shop corresponding to the id
	 *@author: Kishor Nivalkar
	 *@since: 2019-05-23
	 */
	public Shop findByshopId(int id);

}
