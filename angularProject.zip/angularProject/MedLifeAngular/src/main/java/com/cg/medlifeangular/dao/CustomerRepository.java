package com.cg.medlifeangular.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.medlifeangular.dto.Customer;


/*
 * CustomerRepository interface Repository
 *@author: Kishor Nivalkar
 *@since: 2019-05-23
 */
public interface CustomerRepository extends JpaRepository<Customer, String>{

	
	/*
	 * findBycustId: for finding the customer id
	 * return: shop corresponding to the id
	 *@author: Kishor Nivalkar
	 *@since: 2019-05-23
	 */
	public Customer findBycustId(String id);
	

}
