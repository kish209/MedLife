import{Injectable} from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from "rxjs"
import { Customer } from './app.customer';
import { Shop } from './app.shop';
import { Medicine } from './app.medicine';
import { AddShopComponent } from './app.addshopcomponent';

@Injectable({
    providedIn:'root'
})
export class MedlifeService{
constructor(private http:HttpClient){}

getAllProduct(){
   return this.http.get("http://localhost:9098/medlife/showcustomer")
}

addAllProduct(cust:any){

    console.log(cust);
    let input = new FormData();
    input.append("custId",cust.id);
    input.append("custName",cust.name);
    input.append("contact",cust.contact);
    input.append("address.houseNumber",cust.addresshousenumber);
    input.append("address.area",cust.addressarea);
    input.append("address.city",cust.addresscity);
    input.append("address.pincode",cust.addresspincode);
    return this.http.post("http://localhost:9098/medlife/addcustomer",input)
}



addAllShop(shop:any){

    console.log("Shops ...."+shop.toString());
    let input = new FormData();
    input.append("shopId",shop.id);
    input.append("shopName",shop.name);
    input.append("address.houseNumber",shop.addresshousenumber);
    input.append("address.area",shop.addressarea);
    input.append("address.city",shop.addresscity);
    input.append("address.pincode",shop.addresspincode);
   
    //let fieldArray:any[];
    for (var i in shop.medicines)
    {
        console.log("Check"+i);
    input.append("medicines["+i+"].medicineName",shop.medicinesmedicinename);
    input.append("medicines["+i+"].medicineType",shop.medicinesmedicinetype);
    input.append("medicines["+i+"].medicinePrice",shop.medicinesmedicineprice);
    //console.log(fieldArray[i]);
    }
    
    return this.http.post("http://localhost:9098/medlife/addshop",input)
}



searchAllShop(shop:any)
{
    let input= new FormData();
    input.append("medicine",shop.medicinesmedicinename);
    return this.http.post("http://localhost:9098/medlife/searchmedi",input)
}

}