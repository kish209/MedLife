import { Component,OnInit} from "@angular/core";
import { MedlifeService } from "./app.medlifeservice";
import { Shop } from "./app.shop";
import { FormsModule }  from '@angular/forms';



@Component({
selector:'shop-app',
templateUrl:'app.addshop.html'

})
export class AddShopComponent implements OnInit{

    shops:Shop[];

model : any={};
constructor(private medlifeservice:MedlifeService){}
    

ngOnInit(){
    this.medlifeservice.getAllProduct().subscribe((data:Shop[])=>this.shops=data);
}

addShop(){
    console.log("Component....."+this.model.toString());
    this.medlifeservice.addAllShop(this.model).subscribe((data:any)=>console.log(data));
   
}

fieldArray: Array<any> = [];
newAttribute: any = {};

firstField = true;
firstFieldName = '';
isEditItems: boolean;

addFieldValue(index) {
  if (this.fieldArray.length <= 5) {
    this.fieldArray.push(this.newAttribute);
    this.newAttribute = {};
  } else {

  }
}

deleteFieldValue(index) {
  this.fieldArray.splice(index, 1);
}

onEditCloseItems() {
  this.isEditItems = !this.isEditItems;
}


}