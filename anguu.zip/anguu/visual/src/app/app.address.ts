export class Address{
    
    housenumber:string;
    area:string;
    city:string;
    pincode:number;
}