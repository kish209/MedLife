import {Component} from '@angular/core';
import {Address } from './app.address';


export class Customer{

    id:number;
    name:string;
    contact:number;
    address:Address;
} 
 
