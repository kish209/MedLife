import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router'; 
import { Shop } from './app.shop';
import { MedlifeService } from './app.medlifeservice';
 


@Component({
selector:'search-med',
templateUrl:'app.searchmedicine.html'



})


export class SearchMedicine implements OnInit{

    shops:Shop[];
    model:any={};
    constructor(private medlifeservice:MedlifeService){}
    ngOnInit(){}
    searchMedicine()
    {
       this.medlifeservice.searchAllShop(this.model).subscribe((data:Shop[])=>this.shops=data);
     
    }

}


