package com.cg.medlifeangular.service;

import java.util.Date;


import java.util.List;


import com.cg.medlifeangular.dto.Trade;

public interface TradeService{
	public List <Trade> searchByDate(Date date);
	public List <Trade> searchCustomerByDate(String custId, Date date) ;
	public List<Trade> showTrade() ;
	public Trade addTrade(Trade trade);
	public Trade searchById(int id);
	public int updateAddress(int mn,int sid,int tradeId);
}
