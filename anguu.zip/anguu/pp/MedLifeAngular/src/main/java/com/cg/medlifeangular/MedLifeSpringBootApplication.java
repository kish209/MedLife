package com.cg.medlifeangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/*
 * Main class of the Spring Application currently,Postman input outputs are taken
 * Main Parking Management System spring class
 *@author: Kishor Nivalkar
 *@version: 1.0
 *@since: 2019-05-23
 */



/*
 * Our Application starts and configures all the required libraries from here
 * @SpringBootApplication: Which configure all the beans and libraries which are required for the application
 * @ComponentScan: Which make sure that all the components getting added,currently we have added classes in different package
 * @since: 2019-05-23
 */


@SpringBootApplication
@ComponentScan("com.cg.medlifeangular")
public class MedLifeSpringBootApplication {

	/*
	 * main is the entry point of the application
	 * @since: 2019-05-23
	 */
	public static void main(String[] args) {
		

		/*
		 * SpringApplication.run: this method run our ParkingmanagementsysApplication class and with the help of @springBootApplication we configure the required dependancy
		 * @since: 2019-05-23
		 */

		SpringApplication.run(MedLifeSpringBootApplication.class, args);
		System.out.println("Welcome to MedLife");
	}

}
