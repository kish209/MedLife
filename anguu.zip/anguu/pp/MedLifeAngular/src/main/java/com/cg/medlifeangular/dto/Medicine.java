package com.cg.medlifeangular.dto;
import javax.persistence.CascadeType;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="medicine")
public class Medicine{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="medicine_id")
	private int medicineId;
	
	@Column(name="medicine_name")
	private String medicineName;
	
	@Column(name="medicine_type")
	private String medicineType;
	
	@Column(name="medicine_price")
	private double medicinePrice;
	
	@ManyToOne(cascade=CascadeType.ALL ,fetch=FetchType.EAGER)
	@JoinColumn(name="trade_id")
	private Trade trade;
	
	@ManyToOne(cascade=CascadeType.ALL)
	 @JoinColumn(name="shop_id")
	@JsonIgnore
	private Shop shop;
	



public Shop getShop() {
		return shop;
	}
	public void setShop(Shop shop) {
		this.shop = shop;
	}
public Medicine() {
	// TODO Auto-generated constructor stub
}
public Medicine(int medicineId, String medicineName, String medicineType, double medicinePrice) {
	super();
	this.medicineId = medicineId;
	this.medicineName = medicineName;
	this.medicineType = medicineType;
	this.medicinePrice = medicinePrice;

}
public int getMedicineId() {
	return medicineId;
}
public void setMedicineId(int medicineId) {
	this.medicineId = medicineId;
}
public String getMedicineName() {
	return medicineName;
}
public void setMedicineName(String medicineName) {
	this.medicineName = medicineName;
}
public String getMedicineType() {
	return medicineType;
}
public void setMedicineType(String medicineType) {
	this.medicineType = medicineType;
}
public double getMedicinePrice() {
	return medicinePrice;
}
public void setMedicinePrice(double medicinePrice) {
	this.medicinePrice = medicinePrice;
}
public Trade getTrade() {
	return trade;
}
public void setTrade(Trade trade) {
	this.trade = trade;
}
@Override
public String toString() {
	return "Medicine [medicineId=" + medicineId + ", medicineName=" + medicineName + ", medicineType=" + medicineType
			+ ", medicinePrice=" + medicinePrice + "]";
}



	
	

}