package com.cg.demowebapplication.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.demowebapplication.dto.Product;

public class ProductRepositoryImp implements ProductRepository {

	
	List<Product> myList= new LinkedList<>();
	
	@Override
	public void save(Product product) {
		// TODO Auto-generated method stub
		myList.add(product);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return myList;
	}

}
