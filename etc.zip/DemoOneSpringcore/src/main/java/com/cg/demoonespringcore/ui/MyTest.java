package com.cg.demoonespringcore.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demoonespringcore.dto.Item;
import com.cg.demoonespringcore.dto.Product;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");
		
		Product p = (Product) app.getBean("prod");
/*		p.setId(1);
		p.setName("TV");
		p.setPrice(15000.99);
		p.setDescription("Sony Tv");
		p.getAllData();*/
		
		p.getAllData();
	
	}

}
