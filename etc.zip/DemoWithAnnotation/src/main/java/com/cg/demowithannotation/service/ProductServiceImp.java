package com.cg.demowithannotation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demowithannotation.dao.ProductDao;
import com.cg.demowithannotation.dto.Product;

@Service("productService")
public class ProductServiceImp implements ProductService{

	@Autowired
	
	ProductDao productDao;
	public void addProduct(Product prod) {
		// TODO Auto-generated method stub
		productDao.save(prod);
	}

	public List<Product> showAllProduct() {
		// TODO Auto-generated method stub
		return productDao.showAllProduct();
	}

}
