package com.cg.demowithannotation.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.demowithannotation.dto.Product;

@Repository("productdao")
public class ProductDaoImp implements ProductDao {

	List<Product> productList= new ArrayList<Product>();
	public void save(Product Pro) {
		// TODO Auto-generated method stub
		productList.add(Pro);
	}

	public List<Product> showAllProduct() {
		// TODO Auto-generated method stub
		return productList;
	}

}
