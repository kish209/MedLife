package com.cg.demowithannotation.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demowithannotation.config.JavaConfig;
import com.cg.demowithannotation.dto.Product;
import com.cg.demowithannotation.dto.Transaction;
import com.cg.demowithannotation.service.ProductService;

public class MyTest {

	@Autowired
	static ProductService productService;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	AnnotationConfigApplicationContext app= new AnnotationConfigApplicationContext(JavaConfig.class);
	Product myProduct=(Product )app.getBean("prod");
	
	productService = (ProductService) app.getBean("productService");
	Transaction myTransaction = (Transaction) app.getBean("tran");
	
	
	myProduct.setId(13);
	myProduct.setName("ABCD");
	myProduct.setPrice(66.88);
	myProduct.setDescription("Good");
	
	myTransaction.setId(10);
	myTransaction.setAmount(77.80);
	myTransaction.setDescription("For product 13");
	
	System.out.println(myProduct);
	System.out.println(myTransaction);

	productService.addProduct(myProduct);
	productService.showAllProduct();
	}

}
