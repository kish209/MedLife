package com.cg.demowithannotation.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.demowithannotation.dto.Product;
@Component
public interface ProductService {
	public void addProduct(Product prod);
	public List<Product> showAllProduct();

}
