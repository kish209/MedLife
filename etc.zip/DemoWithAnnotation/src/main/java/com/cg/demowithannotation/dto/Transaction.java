package com.cg.demowithannotation.dto;

import org.springframework.stereotype.Component;

@Component("tran")
public class Transaction {

	private int id;
	private Double amount;
	private String description;
	
	
	public Transaction() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "Transaction [id=" + id + ", amount=" + amount + ", description=" + description + "]";
	}

	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
