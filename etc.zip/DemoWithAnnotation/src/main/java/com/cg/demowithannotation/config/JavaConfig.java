package com.cg.demowithannotation.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.cg.demowithannotation.dto.Product;
import com.cg.demowithannotation.dto.Transaction;

@Configuration
@ComponentScan("com.cg.demowithannotation")
public class JavaConfig {

/*	@Bean(name="prod", autowire=Autowire.BY_TYPE)
	public Product getProduct()
	{
		Product pro = new Product();
		pro.setId(100);
		pro.setName("TV");
		pro.setPrice(555.11);
		pro.setDescription("Good TV");
		return pro;
	}
	@Bean(name="tran")
	public Transaction getTransaction()
	{
		Transaction t= new Transaction();
		t.setId(10);
		t.setAmount(55.99);
		t.setDescription("paid");
		return t;
	}*/
}
