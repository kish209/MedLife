package com.cg.demowithannotation.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.demowithannotation.dto.Product;

@Component
public interface ProductDao {

	public void save(Product Pro);
	public List<Product> showAllProduct();
}
