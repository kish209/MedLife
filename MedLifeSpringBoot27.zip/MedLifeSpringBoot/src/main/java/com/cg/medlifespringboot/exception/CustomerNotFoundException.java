package com.cg.medlifespringboot.exception;

public class CustomerNotFoundException extends RuntimeException {
	
	public CustomerNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public CustomerNotFoundException(String msg) {
		
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
}
