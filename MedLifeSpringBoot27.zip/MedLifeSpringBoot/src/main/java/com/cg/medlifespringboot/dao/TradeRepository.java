package com.cg.medlifespringboot.dao;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.medlifespringboot.dto.Trade;


/*
 * TradeRepository interface Repository
 *@author: Kishor Nivalkar
 *@since: 2019-05-23
 */

public interface TradeRepository  extends JpaRepository<Trade, Integer>{

	@Modifying
	@Query("update Medicine c SET c.trade.id=:tradeId where c.medicineId=:mn and c.shop.shopId=:sid")
	public int updateAddress(@Param("mn") int mn, @Param("sid") int sid, @Param("tradeId") int tradeId);
	
	/*public List<Trade> findByDate(Date date) ;
	public List<Trade> findCustomerByDate(String custName, Date date) ;*/
	
	
	/*
	 * findByid: for finding the trade id
	 * return: trade corresponding to the id
	 *@author: Kishor Nivalkar
	 *@since: 2019-05-23
	 */
	
	public Trade findByid(int id);
}