package com.cg.medlifejdbc.service;

import java.util.List;

import com.cg.medlifejdbc.dto.Shop;
import com.cg.medlifejdbc.exceptions.MedicineNotFoundException;

public interface ShopService {
public Shop addShop(Shop shop);
public List<Shop> searchByMedicine(String medicineName) throws MedicineNotFoundException;
}