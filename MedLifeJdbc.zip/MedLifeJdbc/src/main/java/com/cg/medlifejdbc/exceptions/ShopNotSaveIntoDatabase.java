package com.cg.medlifejdbc.exceptions;

public class ShopNotSaveIntoDatabase extends Exception {
	public ShopNotSaveIntoDatabase()
	{
		
	}
	public ShopNotSaveIntoDatabase(String exceptionMessage) {
		super(exceptionMessage);
	}

}
