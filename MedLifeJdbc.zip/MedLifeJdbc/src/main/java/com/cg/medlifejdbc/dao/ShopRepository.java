package com.cg.medlifejdbc.dao;
import java.util.List;

import com.cg.medlifejdbc.dto.Shop;

public interface ShopRepository {

	public Shop save(Shop shop);
	public List<Shop> findByName(String medicineName);

}
