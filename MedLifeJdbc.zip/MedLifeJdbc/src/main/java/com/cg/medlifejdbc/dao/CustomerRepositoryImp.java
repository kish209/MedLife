package com.cg.medlifejdbc.dao;
import com.cg.medlifejdbc.dto.Customer;
import com.cg.medlifejdbc.util.DBUtil;
public class CustomerRepositoryImp implements CustomerRepository {
	public CustomerRepositoryImp()
	{}

	public Customer save(Customer customer) {
		DBUtil.customerData.add(customer);
		return  customer;
	}


	public Customer findById(String id) {
		for (Customer customer : DBUtil.customerData) {
			if(customer.getCustId().equalsIgnoreCase(id))
				return customer;
		}
		return null;
	}	
}