package com.cg.medlifejdbc.service;


import com.cg.medlifejdbc.dao.CustomerRepositoryImp;
import com.cg.medlifejdbc.dto.Customer;
import com.cg.medlifejdbc.exceptions.CustomerDetailsNotFoundException;


public class CustomerServiceImp implements CustomerService{

	Customer customerData;
	CustomerRepositoryImp customerrepository;
	public CustomerServiceImp(){
		customerrepository = new CustomerRepositoryImp();
	}

	public Customer addCustomer(Customer customer) {
		return customerrepository.save(customer);
	}

	public Customer searchById(String id) throws CustomerDetailsNotFoundException {
		if(customerrepository.findById(id)==null)
			throw new CustomerDetailsNotFoundException("Customer not found");
		return customerrepository.findById(id);
	}
}