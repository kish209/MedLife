package com.cg.medlifejdbc.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.cg.medlifejdbc.dto.Trade;
import com.cg.medlifejdbc.util.DBUtil;
public class TradeRepositoryImp implements TradeRepository{

	public List<Trade> findByDate(Date date) {/*
		List <Trade> trade1 = new ArrayList<Trade>();

		for (Trade trade : DBUtil.tradeData) {
			if(trade.getDate().equals(date))
				trade1.add(trade);
		}
		return trade1;*/
		return null;
	}

	public List<Trade> findCustomerByDate(String custId, Date date){/*
		List <Trade> trade2 = new ArrayList<Trade>();
		for (Trade tradeOne : DBUtil.tradeData) {
			if((tradeOne.getCustomer().getCustId().equals(custId)) && (tradeOne.getDate().equals(date)) )
				trade2.add(tradeOne);
		}
		return trade2;*/
		return null;
	}


	public Trade saveTrade(Trade trade) {
		Connection connection = DBUtil.getConnection();
		String query;
		PreparedStatement pstmt=null;
		try
		
		{		
			query="insert into trade(trade_id,total_price,trade_date) values(?,?,?)";
			pstmt=connection.prepareStatement(query);
			pstmt.setInt(1, trade.getId());
			pstmt.setDouble(2, trade.getTotalPrice());
			pstmt.setDate(3, (java.sql.Date) trade.getDate());
			pstmt.executeUpdate();
			
			return trade;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
		return  null;
	
	}


	public List<Trade> showAll() 
	{
		
	/*	
		return DBUtil.tradeData;*/
		return null;
	}
}