package com.cg.medlifejdbc.dto;


public class Address {
	private String houseNo;
	private String area;
	private String city;
	private long pincode; 
	
	public Address()
	{
		houseNo=null;
		area=null;
		city=null;
		pincode=0;	
	}
	
	public Address(String houseNo, String area, String city, long pincode) {
		super();
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
	}
	
	public String toString() {
		return " [House No=" + houseNo + ", Area=" + area + ", City=" + city + ", Pincode=" + pincode + "]";
	}

	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

}