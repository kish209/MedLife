package com.cg.medlifejdbc.exceptions;

public class MedicineNotFoundException extends Exception {
	public MedicineNotFoundException() {
	}
	
	public MedicineNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
}