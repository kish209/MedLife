package com.cg.medlifejdbc.dao;
import java.util.ArrayList;

import java.util.List;

import com.cg.medlifejdbc.dto.Medicine;
import com.cg.medlifejdbc.dto.Shop;
import com.cg.medlifejdbc.util.DBUtil;

public class ShopRepositoryImp implements ShopRepository{

	List<Medicine> medicineData;
	public ShopRepositoryImp()
	{

		medicineData = new ArrayList<Medicine>();
	}

	public Shop save(Shop shop) {
		DBUtil.shopData.add(shop);
		return shop;
	}

	public List<Shop> findByName(String medicineNameOne) {
		List<Shop> shop1=new ArrayList <Shop>();
		for(Shop shop : DBUtil.shopData) 
		{
			if( (!shop1.contains(shop)))
				for (Medicine medicine : shop.getMedicines()) {
					if(medicine.getMedicineName().toLowerCase().equals(medicineNameOne.toLowerCase()))
					{
						shop1.add(shop);
					}
				}
		}
		return shop1;
	}
}