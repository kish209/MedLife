package com.cg.medlifejdbc.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;

import com.cg.medlifejdbc.dto.Customer;
import com.cg.medlifejdbc.dto.Medicine;
import com.cg.medlifejdbc.dto.Shop;
import com.cg.medlifejdbc.util.DBUtil;

public class ShopRepositoryImp implements ShopRepository{

	List<Medicine> medicineData;
	String query = null;
	Connection connection =null;
	PreparedStatement pstmt=null;
	ResultSet result=null;
	Medicine medicine;
	public ShopRepositoryImp()
	{

		medicineData = new ArrayList<Medicine>();
	}

	public Shop save(Shop shop) {
		connection = DBUtil.getConnection();
		try
		
		{		
			query="insert into shop(shop_id,shop_name) values(?,?)";
			pstmt=connection.prepareStatement(query);
			pstmt.setInt(1, shop.getShopId());
			pstmt.setString(2, shop.getShopName());
			pstmt.executeUpdate();
	
			query="insert into address(house_no,house_area,city,pincode,shop_id_f) values(?,?,?,?,?)";
			pstmt=connection.prepareStatement(query);
			pstmt.setString(1, shop.getAddress().getHouseNo());
			pstmt.setString(2, shop.getAddress().getArea());
			pstmt.setString(3, shop.getAddress().getCity());
			pstmt.setLong(4, shop.getAddress().getPincode());
			pstmt.setInt(5, shop.getShopId());
			pstmt.executeUpdate();
			
			query="insert into medicine(medicine_name,medicine_type,medicine_price,shop_id_f) values(?,?,?,?)";
			
			for (Medicine medicine : shop.getMedicines()) {
				pstmt=connection.prepareStatement(query);
				pstmt.setString(1, medicine.getMedicineName());
				pstmt.setString(2, medicine.getMedicineType());
				pstmt.setDouble(3, medicine.getMedicinePrice());
				pstmt.setInt(4, shop.getShopId());
				pstmt.executeUpdate();
			}
			
		
			
			
			
			return shop;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
		return  null;
	}

	public List<Shop> findByName(String medicineNameOne) {
/*		List<Shop> shop1=new ArrayList <Shop>();
		for(Shop shop : DBUtil.shopData) 
		{
			if( (!shop1.contains(shop)))
				for (Medicine medicine : shop.getMedicines()) {
					if(medicine.getMedicineName().toLowerCase().equals(medicineNameOne.toLowerCase()))
					{
						shop1.add(shop);
					}
				}
		}
		return shop1;*/
		return null;
	}
}