package com.cg.medlifejdbc.service;


import com.cg.medlifejdbc.dto.Customer;

import com.cg.medlifejdbc.exceptions.CustomerDetailsNotFoundException;
import com.cg.medlifejdbc.exceptions.DataNotSaveException;

public interface CustomerService{

	public Customer addCustomer(Customer customer);
	public Customer searchById(String id) throws CustomerDetailsNotFoundException;
}