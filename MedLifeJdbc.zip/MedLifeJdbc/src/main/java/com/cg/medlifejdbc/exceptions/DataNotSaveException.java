package com.cg.medlifejdbc.exceptions;

public class DataNotSaveException extends Exception {
	public DataNotSaveException()
	{
		
	}
	
	public DataNotSaveException(String exceptionMessage)
	{
		super(exceptionMessage);
	}

}
